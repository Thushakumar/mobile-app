# backend/patients/models.py
from django.db import models
from django.conf import settings
from django.contrib.auth.hashers import make_password, check_password

class Patient(models.Model):
    GENDER_CHOICES = [
        ('Male', 'Male'),
        ('Female', 'Female'),
        ('Other', 'Other'),
    ]
    
    full_name = models.CharField(max_length=255)
    patient_id = models.CharField(max_length=50, unique=True)
    gender = models.CharField(max_length=10, choices=GENDER_CHOICES)
    doctor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='patients')
    first_clinic_date = models.DateField(auto_now_add=True)
    
    # Mobile app authentication
    password = models.CharField(max_length=128, blank=True, null=True)  # For mobile app login
    is_first_login = models.BooleanField(default=True)  # Track first login for password reset
    
    def set_password(self, raw_password):
        """Set password for mobile authentication"""
        self.password = make_password(raw_password)
        
    def check_password(self, raw_password):
        """Check password for mobile authentication"""
        if not self.password:
            return False
        return check_password(raw_password, self.password)
    
    def __str__(self):
        return f"{self.patient_id} - {self.full_name}"
    
    class Meta:
        ordering = ['patient_id']