# backend/users/views.py
from rest_framework import generics, permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth import get_user_model
from .serializers import UserRegisterSerializer, UserSerializer
from patients.models import Patient

User = get_user_model()

class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    permission_classes = (permissions.AllowAny,)
    serializer_class = UserRegisterSerializer  # Use the correct class name
    
    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        return Response({
            "user": UserSerializer(user, context=self.get_serializer_context()).data,
            "message": "User created successfully. Now login to get your token"
        }, status=status.HTTP_201_CREATED)

class UserProfileView(APIView):
    permission_classes = (permissions.IsAuthenticated,)
    
    def get(self, request):
        serializer = UserSerializer(request.user)
        return Response(serializer.data)

class PatientLoginView(APIView):
    """Mobile app login for patients"""
    permission_classes = (permissions.AllowAny,)
    
    def post(self, request):
        patient_id = request.data.get('patient_id')
        password = request.data.get('password')
        
        if not patient_id or not password:
            return Response({
                'error': 'Patient ID and password are required'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            patient = Patient.objects.get(patient_id=patient_id)
            
            # Check if patient has a password set
            if not patient.password:
                # Set default password for existing patients
                patient.set_password('password123')  # Default password
                patient.save()
            
            if patient.check_password(password):
                # Create JWT tokens for the patient
                # We'll use the doctor's user for JWT but return patient data
                refresh = RefreshToken.for_user(patient.doctor)
                
                # Add patient ID to token payload
                refresh['patient_id'] = patient.patient_id
                refresh['patient_name'] = patient.full_name
                
                return Response({
                    'success': True,
                    'access_token': str(refresh.access_token),
                    'refresh_token': str(refresh),
                    'patient': {
                        'id': patient.id,
                        'patient_id': patient.patient_id,
                        'full_name': patient.full_name,
                        'gender': patient.gender,
                        'first_clinic_date': patient.first_clinic_date,
                    }
                }, status=status.HTTP_200_OK)
            else:
                return Response({
                    'error': 'Invalid credentials'
                }, status=status.HTTP_401_UNAUTHORIZED)
                
        except Patient.DoesNotExist:
            return Response({
                'error': 'Patient not found'
            }, status=status.HTTP_404_NOT_FOUND)

class PatientProfileView(APIView):
    """Get patient profile for mobile app"""
    permission_classes = (permissions.IsAuthenticated,)
    
    def get(self, request):
        # Extract patient_id from token payload
        patient_id = request.auth.payload.get('patient_id')
        
        if not patient_id:
            return Response({
                'error': 'Patient ID not found in token'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            patient = Patient.objects.get(patient_id=patient_id)
            return Response({
                'id': patient.id,
                'patient_id': patient.patient_id,
                'full_name': patient.full_name,
                'gender': patient.gender,
                'first_clinic_date': patient.first_clinic_date,
            })
        except Patient.DoesNotExist:
            return Response({
                'error': 'Patient not found'
            }, status=status.HTTP_404_NOT_FOUND)