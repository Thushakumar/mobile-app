# mobile_therapy/views.py
from rest_framework import generics, status, viewsets
from rest_framework.decorators import api_view, permission_classes, action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.parsers import MultiPartParser, FormParser
from django.shortcuts import get_object_or_404
from django.utils import timezone
from django.db import transaction
import logging

from .authentication import PatientJWTAuthentication, PatientOrUserAuthenticated

from patients.models import Patient
from chapters.models import Chapter, Word
from progress.models import Progress
from .models import TherapySession, VideoSubmission, MobileProgress, MobileSessionHistory
from .serializers import (
    PatientSerializer, ChapterSerializer, ChapterDetailSerializer,
    TherapySessionSerializer,
    VideoSubmissionSerializer, VideoSubmissionCreateSerializer,
    MobileProgressSerializer, MobileSessionHistorySerializer
)
try:
    from ml_analysis.services import ml_service
except ImportError:
    ml_service = None

logger = logging.getLogger(__name__)

class PatientListView(generics.ListAPIView):
    """
    List all patients (for mobile app - usually patients will be pre-authenticated)
    """
    queryset = Patient.objects.all()
    serializer_class = PatientSerializer
    authentication_classes = [PatientJWTAuthentication]
    permission_classes = [PatientOrUserAuthenticated]

class PatientDetailView(generics.RetrieveAPIView):
    """
    Get patient details by patient_id
    """
    serializer_class = PatientSerializer
    authentication_classes = [PatientJWTAuthentication]
    permission_classes = [PatientOrUserAuthenticated]
    lookup_field = 'patient_id'
    
    def get_queryset(self):
        return Patient.objects.all()

class ChapterListView(generics.ListAPIView):
    """
    List all available chapters
    """
    queryset = Chapter.objects.all().order_by('chapter_number')
    serializer_class = ChapterSerializer
    authentication_classes = [PatientJWTAuthentication]
    permission_classes = [PatientOrUserAuthenticated]

class ChapterDetailView(generics.RetrieveAPIView):
    """
    Get chapter details with words
    """
    queryset = Chapter.objects.all()
    serializer_class = ChapterDetailSerializer
    authentication_classes = [PatientJWTAuthentication]
    permission_classes = [PatientOrUserAuthenticated]

class TherapySessionViewSet(viewsets.ModelViewSet):
    """
    ViewSet for therapy sessions
    """
    serializer_class = TherapySessionSerializer
    authentication_classes = [PatientJWTAuthentication]
    permission_classes = [PatientOrUserAuthenticated]
    
    def get_queryset(self):
        patient_id = self.request.query_params.get('patient_id', None)
        if patient_id:
            return TherapySession.objects.filter(patient__patient_id=patient_id)
        return TherapySession.objects.all()
    
    def get_serializer_class(self):
        if self.action == 'retrieve':
            return TherapySessionSerializer
        return TherapySessionSerializer
    
    def perform_create(self, serializer):
        # Set total_words based on chapter
        chapter = serializer.validated_data['chapter']
        total_words = chapter.words.count()
        serializer.save(total_words=total_words)
    
    @action(detail=True, methods=['get'])
    def current_word(self, request, pk=None):
        """
        Get the current word in the session
        """
        session = self.get_object()
        current_word = session.current_word
        if current_word:
            return Response({
                'word_id': current_word.id,
                'word': current_word.word,
                'order': current_word.order,
                'current_index': session.current_word_index,
                'total_words': session.total_words,
                'progress_percentage': session.progress_percentage
            })
        else:
            return Response({'error': 'No current word available'}, status=status.HTTP_404_NOT_FOUND)
    
    @action(detail=True, methods=['post'])
    def next_word(self, request, pk=None):
        """
        Move to next word in the session
        """
        session = self.get_object()
        if session.current_word_index < session.total_words - 1:
            session.current_word_index += 1
            session.save()
            current_word = session.current_word
            return Response({
                'current_word_index': session.current_word_index,
                'word_id': current_word.id if current_word else None,
                'word': current_word.word if current_word else None,
                'progress_percentage': session.progress_percentage
            })
        else:
            return Response({'error': 'Already at last word'}, status=status.HTTP_400_BAD_REQUEST)
    
    @action(detail=True, methods=['post'])
    def previous_word(self, request, pk=None):
        """
        Move to previous word in the session
        """
        session = self.get_object()
        if session.current_word_index > 0:
            session.current_word_index -= 1
            session.save()
            current_word = session.current_word
            return Response({
                'current_word_index': session.current_word_index,
                'word_id': current_word.id if current_word else None,
                'word': current_word.word if current_word else None,
                'progress_percentage': session.progress_percentage
            })
        else:
            return Response({'error': 'Already at first word'}, status=status.HTTP_400_BAD_REQUEST)
    
    @action(detail=True, methods=['post'])
    def complete_session(self, request, pk=None):
        """
        Mark session as completed and calculate final score
        """
        session = self.get_object()
        
        # Calculate session score based on video submissions
        video_submissions = session.video_submissions.filter(is_analyzed=True)
        if video_submissions.exists():
            total_score = sum([v.accuracy_score for v in video_submissions if v.accuracy_score])
            session.session_score = total_score / video_submissions.count()
        else:
            session.session_score = 0.0
        
        session.words_completed = session.current_word_index + 1
        session.is_completed = True
        session.completed_at = timezone.now()
        session.save()
        
        return Response({
            'message': 'Session completed successfully',
            'final_score': session.session_score,
            'words_completed': session.words_completed,
            'total_words': session.total_words
        })

class VideoSubmissionCreateView(generics.CreateAPIView):
    """
    Create a new video submission
    """
    queryset = VideoSubmission.objects.all()
    serializer_class = VideoSubmissionCreateSerializer
    permission_classes = [IsAuthenticated]
    parser_classes = [MultiPartParser, FormParser]
    
    def create(self, request, *args, **kwargs):
        """
        Custom create method to handle mobile app format
        """
        try:
            # Debug logging
            logger.info(f"Received video submission request")
            logger.info(f"Request data: {request.data}")
            logger.info(f"Request files: {request.FILES}")
            
            # Get data from request
            patient_id = request.data.get('patient_id')
            chapter_id = request.data.get('chapter_id')
            word_text = request.data.get('word_text')
            video_file = request.FILES.get('video_file')
            
            logger.info(f"Extracted values - patient_id: {patient_id}, chapter_id: {chapter_id}, word_text: {word_text}, video_file: {video_file}")
            
            if not all([patient_id, chapter_id, word_text, video_file]):
                missing_fields = []
                if not patient_id:
                    missing_fields.append('patient_id')
                if not chapter_id:
                    missing_fields.append('chapter_id')
                if not word_text:
                    missing_fields.append('word_text')
                if not video_file:
                    missing_fields.append('video_file')
                    
                logger.error(f"Missing fields: {missing_fields}")
                return Response({
                    'error': f'Missing required fields: {", ".join(missing_fields)}'
                }, status=status.HTTP_400_BAD_REQUEST)
            
            # Find patient
            try:
                patient = Patient.objects.get(patient_id=patient_id)
            except Patient.DoesNotExist:
                return Response({
                    'error': f'Patient with ID {patient_id} not found'
                }, status=status.HTTP_404_NOT_FOUND)
            
            # Find chapter
            try:
                chapter = Chapter.objects.get(id=chapter_id)
            except Chapter.DoesNotExist:
                return Response({
                    'error': f'Chapter with ID {chapter_id} not found'
                }, status=status.HTTP_404_NOT_FOUND)
            
            # Find word
            try:
                word = Word.objects.get(word=word_text, chapter=chapter)
            except Word.DoesNotExist:
                return Response({
                    'error': f'Word "{word_text}" not found in chapter {chapter.name}'
                }, status=status.HTTP_404_NOT_FOUND)
            
            # Create or get session
            session, created = TherapySession.objects.get_or_create(
                patient=patient,
                chapter=chapter,
                defaults={
                    'started_at': timezone.now(),
                    'is_completed': False,
                    'current_word_index': 0,
                    'total_words': chapter.words.count(),
                    'words_completed': 0
                }
            )
            
            # Count existing attempts for this word
            attempt_number = VideoSubmission.objects.filter(
                session=session, 
                word=word
            ).count() + 1
            
            # Create video submission
            video_submission = VideoSubmission.objects.create(
                session=session,
                word=word,
                video_file=video_file,
                attempt_number=attempt_number
            )
            
            # Trigger ML analysis asynchronously
            try:
                if 'ml_service' in globals() and ml_service is not None:
                    result = ml_service.analyze_video(video_submission.id)
                    logger.info(f"ML analysis result: {result}")
            except Exception as e:
                logger.error(f"Error triggering ML analysis: {e}")
            
            return Response({
                'id': video_submission.id,
                'session_id': session.id,
                'word_text': word.word,
                'attempt_number': attempt_number,
                'created_at': video_submission.submitted_at
            }, status=status.HTTP_201_CREATED)
            
        except Exception as e:
            logger.error(f"Error creating video submission: {e}")
            return Response({
                'error': f'Failed to create video submission: {str(e)}'
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class VideoSubmissionListView(generics.ListAPIView):
    """
    List video submissions for a session
    """
    serializer_class = VideoSubmissionSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        session_id = self.request.query_params.get('session_id', None)
        if session_id:
            return VideoSubmission.objects.filter(session_id=session_id)
        return VideoSubmission.objects.all()

class VideoSubmissionDetailView(generics.RetrieveAPIView):
    """
    Get video submission details
    """
    queryset = VideoSubmission.objects.all()
    serializer_class = VideoSubmissionSerializer
    permission_classes = [IsAuthenticated]

class ProgressListView(generics.ListAPIView):
    """
    List progress records for a patient
    """
    serializer_class = MobileProgressSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        patient_id = self.request.query_params.get('patient_id', None)
        if patient_id:
            return Progress.objects.filter(patient__patient_id=patient_id)
        return Progress.objects.all()

class SessionHistoryListView(generics.ListAPIView):
    """
    List session history for a patient
    """
    serializer_class = MobileSessionHistorySerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        patient_id = self.request.query_params.get('patient_id', None)
        if patient_id:
            return MobileSessionHistory.objects.filter(patient__patient_id=patient_id)
        return MobileSessionHistory.objects.all()

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_current_word(request, session_id):
    """
    Get the current word for a therapy session
    """
    try:
        session = get_object_or_404(TherapySession, id=session_id)
        words = session.chapter.mobile_words.all()
        
        if session.current_word_index < len(words):
            current_word = words[session.current_word_index]
            return Response({
                'word_id': current_word.id,
                'word': current_word.word,
                'order': current_word.order,
                'current_index': session.current_word_index,
                'total_words': session.total_words
            })
        else:
            return Response({'error': 'Session completed'}, status=status.HTTP_400_BAD_REQUEST)
    except Exception as e:
        return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def analyze_video(request, video_submission_id):
    """
    Manually trigger video analysis (for testing)
    """
    if ml_service is None:
        return Response(
            {'error': 'ML analysis service not available'}, 
            status=status.HTTP_503_SERVICE_UNAVAILABLE
        )
    
    try:
        result = ml_service.analyze_video(video_submission_id)
        return Response(result)
    except Exception as e:
        return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
