# mobile_therapy/admin.py
from django.contrib import admin
from .models import Patient, Chapter, Word, TherapySession, VideoSubmission, Progress, SessionHistory

@admin.register(Patient)
class PatientAdmin(admin.ModelAdmin):
    list_display = ['patient_id', 'full_name', 'gender', 'doctor', 'first_clinic_date']
    list_filter = ['user__gender', 'first_clinic_date', 'doctor']
    search_fields = ['user__patient_id', 'user__first_name', 'user__last_name']
    readonly_fields = ['first_clinic_date']
    
    def patient_id(self, obj):
        return obj.user.patient_id
    patient_id.short_description = 'Patient ID'
    
    def full_name(self, obj):
        return obj.user.get_full_name()
    full_name.short_description = 'Full Name'
    
    def gender(self, obj):
        return obj.user.gender
    gender.short_description = 'Gender'

@admin.register(Chapter)
class ChapterAdmin(admin.ModelAdmin):
    list_display = ['chapter_number', 'name']
    ordering = ['chapter_number']

@admin.register(Word)
class WordAdmin(admin.ModelAdmin):
    list_display = ['word', 'chapter', 'order']
    list_filter = ['chapter']
    ordering = ['chapter', 'order']

@admin.register(TherapySession)
class TherapySessionAdmin(admin.ModelAdmin):
    list_display = ['patient', 'chapter', 'started_at', 'is_completed', 'current_word_index', 'total_words']
    list_filter = ['is_completed', 'started_at', 'chapter']
    search_fields = ['patient__user__patient_id', 'patient__user__first_name', 'patient__user__last_name']
    readonly_fields = ['started_at']

@admin.register(VideoSubmission)
class VideoSubmissionAdmin(admin.ModelAdmin):
    list_display = ['session', 'word', 'status', 'uploaded_at', 'accuracy_score', 'predicted_word']
    list_filter = ['status', 'uploaded_at']
    search_fields = ['session__patient__patient_id', 'word__word']
    readonly_fields = ['uploaded_at', 'processed_at']

@admin.register(Progress)
class ProgressAdmin(admin.ModelAdmin):
    list_display = ['patient', 'word', 'trial_number', 'accuracy', 'date', 'time']
    list_filter = ['date', 'word__chapter']
    search_fields = ['patient__patient_id', 'patient__full_name', 'word__word']

@admin.register(SessionHistory)
class SessionHistoryAdmin(admin.ModelAdmin):
    list_display = ['patient', 'date', 'duration', 'score']
    list_filter = ['date']
    search_fields = ['patient__patient_id', 'patient__full_name']
