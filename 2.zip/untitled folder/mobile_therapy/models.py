# mobile_therapy/models.py
from django.db import models
from django.conf import settings
from django.contrib.auth import get_user_model
from patients.models import Patient
from chapters.models import Chapter, Word
import os

# Use our custom User model
User = get_user_model()

class TherapySession(models.Model):
    """
    Mobile therapy session model
    Tracks individual therapy sessions for patients
    """
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE, related_name='mobile_sessions')
    chapter = models.ForeignKey(Chapter, on_delete=models.CASCADE, related_name='mobile_sessions')
    started_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    is_completed = models.BooleanField(default=False)
    current_word_index = models.IntegerField(default=0)
    total_words = models.IntegerField(default=0)
    session_score = models.FloatField(default=0.0)  # Overall session score
    words_completed = models.IntegerField(default=0)  # Number of words completed
    
    class Meta:
        ordering = ['-started_at']
    
    def __str__(self):
        return f"Session - {self.patient.patient_id} - {self.chapter.name}"
    
    @property
    def progress_percentage(self):
        """Calculate session progress percentage"""
        if self.total_words == 0:
            return 0
        return (self.current_word_index / self.total_words) * 100
    
    @property
    def current_word(self):
        """Get the current word in the session"""
        words = self.chapter.words.all().order_by('order')
        if self.current_word_index < len(words):
            return words[self.current_word_index]
        return None

class VideoSubmission(models.Model):
    """
    Video submission model for patient therapy videos
    """
    session = models.ForeignKey(TherapySession, on_delete=models.CASCADE, related_name='video_submissions')
    word = models.ForeignKey(Word, on_delete=models.CASCADE)
    video_file = models.FileField(upload_to='videos/%Y/%m/')
    submitted_at = models.DateTimeField(auto_now_add=True)
    
    # ML Analysis results
    is_analyzed = models.BooleanField(default=False)
    ml_predicted_class = models.CharField(max_length=100, null=True, blank=True)  # Predicted word/class
    confidence_score = models.FloatField(null=True, blank=True)  # Confidence of prediction
    accuracy_score = models.FloatField(null=True, blank=True)
    ml_analysis_result = models.JSONField(null=True, blank=True)  # Full ML analysis result
    analysis_completed_at = models.DateTimeField(null=True, blank=True)
    status = models.CharField(max_length=20, default='pending', choices=[
        ('pending', 'Pending'),
        ('processing', 'Processing'),
        ('completed', 'Completed'),
        ('failed', 'Failed')
    ])
    processed_at = models.DateTimeField(null=True, blank=True)
    
    # Feedback and retry management
    feedback_text = models.TextField(blank=True)  # AI-generated feedback
    needs_improvement = models.BooleanField(default=False)
    attempt_number = models.IntegerField(default=1)  # Track retry attempts
    
    class Meta:
        ordering = ['-submitted_at']
        
    def __str__(self):
        return f"Video - {self.session.patient.patient_id} - {self.word.word} (Attempt {self.attempt_number})"

class MobileProgress(models.Model):
    """
    Mobile-specific patient progress tracking model
    This extends the web app's progress model with mobile-specific data
    """
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE, related_name='mobile_progress')
    chapter = models.ForeignKey(Chapter, on_delete=models.CASCADE)
    word = models.ForeignKey(Word, on_delete=models.CASCADE)
    attempts = models.IntegerField(default=0)
    best_score = models.FloatField(default=0.0)
    last_attempt_date = models.DateTimeField(auto_now=True)
    
    class Meta:
        unique_together = ['patient', 'word']
        ordering = ['-last_attempt_date']
        
    def __str__(self):
        return f"Mobile Progress - {self.patient.patient_id} - {self.word.word}"

class MobileSessionHistory(models.Model):
    """
    Mobile session history model
    """
    session = models.OneToOneField(TherapySession, on_delete=models.CASCADE, related_name='mobile_history')
    total_time_spent = models.DurationField(null=True, blank=True)
    words_completed = models.IntegerField(default=0)
    average_accuracy = models.FloatField(default=0.0)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['-created_at']
        
    def __str__(self):
        return f"Mobile History - {self.session.patient.patient_id} - {self.session.chapter.name}"
