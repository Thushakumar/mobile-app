# mobile_therapy/serializers.py
from rest_framework import serializers
from .models import TherapySession, VideoSubmission, MobileProgress, MobileSessionHistory
from patients.models import Patient
from chapters.models import Chapter, Word

class PatientSerializer(serializers.ModelSerializer):
    class Meta:
        model = Patient
        fields = ['id', 'full_name', 'patient_id', 'gender', 'first_clinic_date']
        read_only_fields = ['id', 'first_clinic_date']

class ChapterSerializer(serializers.ModelSerializer):
    class Meta:
        model = Chapter
        fields = ['id', 'chapter_number', 'name']

class WordSerializer(serializers.ModelSerializer):
    class Meta:
        model = Word
        fields = ['id', 'word', 'order']

class ChapterDetailSerializer(serializers.ModelSerializer):
    words = WordSerializer(many=True, read_only=True)
    
    class Meta:
        model = Chapter
        fields = ['id', 'chapter_number', 'name', 'words']

class TherapySessionSerializer(serializers.ModelSerializer):
    patient_name = serializers.CharField(source='patient.full_name', read_only=True)
    chapter_name = serializers.CharField(source='chapter.name', read_only=True)
    
    class Meta:
        model = TherapySession
        fields = [
            'id', 'patient', 'chapter', 'started_at', 'completed_at', 
            'is_completed', 'current_word_index', 'total_words',
            'patient_name', 'chapter_name'
        ]
        read_only_fields = ['id', 'started_at']

class VideoSubmissionSerializer(serializers.ModelSerializer):
    session_info = serializers.SerializerMethodField()
    word_text = serializers.CharField(source='word.word', read_only=True)
    
    class Meta:
        model = VideoSubmission
        fields = [
            'id', 'session', 'word', 'video_file', 'submitted_at',
            'is_analyzed', 'accuracy_score', 'analysis_result',
            'analysis_completed_at', 'session_info', 'word_text'
        ]
        read_only_fields = ['id', 'submitted_at', 'is_analyzed', 'accuracy_score', 'analysis_result', 'analysis_completed_at']
    
    def get_session_info(self, obj):
        return {
            'patient_id': obj.session.patient.patient_id,
            'chapter_name': obj.session.chapter.name
        }

class VideoSubmissionCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = VideoSubmission
        fields = ['session', 'word', 'video_file']

class MobileProgressSerializer(serializers.ModelSerializer):
    patient_name = serializers.CharField(source='patient.full_name', read_only=True)
    word_text = serializers.CharField(source='word.word', read_only=True)
    chapter_name = serializers.CharField(source='chapter.name', read_only=True)
    
    class Meta:
        model = MobileProgress
        fields = [
            'id', 'patient', 'chapter', 'word', 'attempts', 'best_score',
            'last_attempt_date', 'patient_name', 'word_text', 'chapter_name'
        ]
        read_only_fields = ['id', 'last_attempt_date']

class MobileSessionHistorySerializer(serializers.ModelSerializer):
    session_details = TherapySessionSerializer(source='session', read_only=True)
    
    class Meta:
        model = MobileSessionHistory
        fields = [
            'id', 'session', 'total_time_spent', 'words_completed',
            'average_accuracy', 'notes', 'created_at', 'session_details'
        ]
        read_only_fields = ['id', 'created_at']
