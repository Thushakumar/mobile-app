from django.apps import AppConfig


class MobileTherapyConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mobile_therapy'
