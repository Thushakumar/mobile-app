# mobile_therapy/authentication.py
from rest_framework.permissions import BasePermission
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework_simplejwt.exceptions import InvalidToken, TokenError
from patients.models import Patient
import jwt
from django.conf import settings


class PatientJWTAuthentication(JWTAuthentication):
    """
    Custom JWT authentication for patients
    """
    def get_user(self, validated_token):
        """
        Get patient from JWT token that contains patient_id
        """
        try:
            # Try to get patient_id from token
            patient_id = validated_token.get('patient_id')
            if patient_id:
                try:
                    patient = Patient.objects.get(patient_id=patient_id)
                    # Return the patient object instead of the user
                    return patient
                except Patient.DoesNotExist:
                    pass
            
            # Fall back to standard user authentication
            return super().get_user(validated_token)
            
        except Exception:
            # Fall back to standard user authentication
            return super().get_user(validated_token)


class IsPatientAuthenticated(BasePermission):
    """
    Permission that allows access to authenticated patients
    """
    def has_permission(self, request, view):
        # Check if user is authenticated (could be User or Patient)
        if not request.user or not hasattr(request.user, 'is_authenticated'):
            return False
            
        # If it's a Patient object, check if it exists
        if isinstance(request.user, Patient):
            return True
            
        # If it's a Django User, check standard authentication
        return request.user.is_authenticated


class PatientOrUserAuthenticated(BasePermission):
    """
    Permission that allows access to both authenticated patients and users
    """
    def has_permission(self, request, view):
        # Check if user is authenticated
        if not request.user:
            return False
            
        # If it's a Patient object, it's authenticated
        if isinstance(request.user, Patient):
            return True
            
        # If it's a Django User, check standard authentication
        if hasattr(request.user, 'is_authenticated'):
            return request.user.is_authenticated
            
        return False
