# mobile_therapy/management/commands/init_mobile_data.py
from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from mobile_therapy.models import Patient, Chapter, Word

User = get_user_model()

class Command(BaseCommand):
    help = 'Initialize test data for mobile therapy app'

    def handle(self, *args, **options):
        self.stdout.write("Initializing mobile therapy data...")
        
        # Create a test user if it doesn't exist
        if not User.objects.filter(username='doctor1').exists():
            doctor = User.objects.create_user(
                username='doctor1',
                email='doctor1@example.com',
                password='testpass123',
                first_name='Dr. John',
                last_name='Smith',
                is_doctor=True
            )
            self.stdout.write(f"Created doctor user: {doctor}")
        else:
            doctor = User.objects.get(username='doctor1')
            self.stdout.write(f"Using existing doctor: {doctor}")
        
        # Create test chapters if they don't exist
        chapters_data = [
            {'chapter_number': 1, 'name': 'Basic Words'},
            {'chapter_number': 2, 'name': 'Colors'},
            {'chapter_number': 3, 'name': 'Numbers'},
        ]
        
        for chapter_data in chapters_data:
            chapter, created = Chapter.objects.get_or_create(
                chapter_number=chapter_data['chapter_number'],
                defaults={'name': chapter_data['name']}
            )
            if created:
                self.stdout.write(f"Created chapter: {chapter}")
            else:
                self.stdout.write(f"Chapter already exists: {chapter}")
        
        # Create test words
        words_data = [
            {'chapter_number': 1, 'words': [
                {'word': 'hello', 'order': 1},
                {'word': 'goodbye', 'order': 2},
                {'word': 'please', 'order': 3},
                {'word': 'thank you', 'order': 4},
            ]},
            {'chapter_number': 2, 'words': [
                {'word': 'red', 'order': 1},
                {'word': 'blue', 'order': 2},
                {'word': 'green', 'order': 3},
                {'word': 'yellow', 'order': 4},
            ]},
            {'chapter_number': 3, 'words': [
                {'word': 'one', 'order': 1},
                {'word': 'two', 'order': 2},
                {'word': 'three', 'order': 3},
                {'word': 'four', 'order': 4},
                {'word': 'five', 'order': 5},
            ]},
        ]
        
        for chapter_data in words_data:
            chapter = Chapter.objects.get(chapter_number=chapter_data['chapter_number'])
            for word_data in chapter_data['words']:
                word, created = Word.objects.get_or_create(
                    chapter=chapter,
                    word=word_data['word'],
                    defaults={'order': word_data['order']}
                )
                if created:
                    self.stdout.write(f"Created word: {word}")
        
        # Create test patient
        if not Patient.objects.filter(patient_id='TEST001').exists():
            patient = Patient.objects.create(
                full_name='John Doe',
                patient_id='TEST001',
                gender='Male',
                doctor=doctor
            )
            self.stdout.write(f"Created test patient: {patient}")
        else:
            self.stdout.write("Test patient already exists")
        
        self.stdout.write(self.style.SUCCESS('Successfully initialized mobile therapy data!'))
