from rest_framework import status, serializers
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.response import Response
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth.hashers import check_password
from patients.models import Patient
from patients.serializers import PatientProfileSerializer
import logging

logger = logging.getLogger(__name__)

class LoginSerializer(serializers.Serializer):
    patient_id = serializers.CharField()
    password = serializers.CharField()

    def validate(self, data):
        patient_id = data.get('patient_id')
        password = data.get('password')
        
        if not patient_id or not password:
            raise serializers.ValidationError("Both patient_id and password are required.")
        
        try:
            patient = Patient.objects.get(patient_id=patient_id)
        except Patient.DoesNotExist:
            raise serializers.ValidationError("Invalid patient ID or password.")
        
        # Check if patient has a password set
        if not patient.password:
            raise serializers.ValidationError("Patient account not properly configured.")
        
        # Verify password
        if not patient.check_password(password):
            raise serializers.ValidationError("Invalid patient ID or password.")
        
        data['patient'] = patient
        return data

@api_view(['POST'])
@permission_classes([AllowAny])
def mobile_login(request):
    """
    Mobile patient login endpoint
    """
    try:
        serializer = LoginSerializer(data=request.data)
        if serializer.is_valid():
            patient = serializer.validated_data['patient']
            
            # Create JWT tokens using the patient's doctor as the user
            # This allows the JWT authentication to work with Django's auth system
            refresh = RefreshToken.for_user(patient.doctor)
            
            # Add custom claims for patient identification
            refresh['patient_id'] = patient.patient_id
            refresh['is_patient'] = True
            refresh['patient_name'] = patient.full_name
            
            response_data = {
                'success': True,
                'message': 'Login successful',
                'patient_id': patient.patient_id,
                'access_token': str(refresh.access_token),
                'refresh_token': str(refresh),
                'is_first_login': patient.is_first_login,
                'patient': PatientProfileSerializer(patient).data
            }
            
            logger.info(f"Successful login for patient: {patient.patient_id}")
            return Response(response_data, status=status.HTTP_200_OK)
        else:
            logger.warning(f"Login failed with errors: {serializer.errors}")
            return Response({
                'success': False,
                'message': 'Login failed',
                'errors': serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)
            
    except Exception as e:
        logger.error(f"Login error: {str(e)}")
        return Response({
            'success': False,
            'message': 'An error occurred during login',
            'error': str(e)
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def profile_view(request):
    """
    Get patient profile information
    """
    try:
        # Check if this is a patient token by looking for patient_id in the JWT payload
        if hasattr(request.auth, 'payload') and 'patient_id' in request.auth.payload:
            patient_id = request.auth.payload.get('patient_id')
            patient = Patient.objects.get(patient_id=patient_id)
        else:
            # Fallback: try to find patient by the authenticated user (doctor)
            patient = Patient.objects.filter(doctor=request.user).first()
            if not patient:
                return Response({
                    'success': False,
                    'message': 'No patient found for this user'
                }, status=status.HTTP_404_NOT_FOUND)
        
        serializer = PatientProfileSerializer(patient)
        
        return Response({
            'success': True,
            'patient': serializer.data
        }, status=status.HTTP_200_OK)
        
    except Patient.DoesNotExist:
        return Response({
            'success': False,
            'message': 'Patient profile not found'
        }, status=status.HTTP_404_NOT_FOUND)
    except Exception as e:
        logger.error(f"Profile view error: {str(e)}")
        return Response({
            'success': False,
            'message': 'An error occurred',
            'error': str(e)
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def mobile_logout(request):
    """
    Mobile patient logout endpoint
    """
    try:
        # Get the refresh token from request data
        refresh_token = request.data.get('refresh_token')
        if refresh_token:
            token = RefreshToken(refresh_token)
            token.blacklist()
        
        return Response({
            'success': True,
            'message': 'Logout successful'
        }, status=status.HTTP_200_OK)
        
    except Exception as e:
        logger.error(f"Logout error: {str(e)}")
        return Response({
            'success': False,
            'message': 'Logout failed',
            'error': str(e)
        }, status=status.HTTP_400_BAD_REQUEST)

@api_view(['POST'])
@permission_classes([AllowAny])
def reset_password(request):
    """
    Password reset endpoint for first-time login
    """
    try:
        patient_id = request.data.get('patient_id')
        new_password = request.data.get('new_password')
        
        if not patient_id or not new_password:
            return Response({
                'success': False,
                'message': 'Patient ID and new password are required'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            patient = Patient.objects.get(patient_id=patient_id)
        except Patient.DoesNotExist:
            return Response({
                'success': False,
                'message': 'Patient not found'
            }, status=status.HTTP_404_NOT_FOUND)
        
        # Update password and mark as not first login
        patient.set_password(new_password)
        patient.is_first_login = False
        patient.save()
        
        return Response({
            'success': True,
            'message': 'Password reset successful'
        }, status=status.HTTP_200_OK)
        
    except Exception as e:
        logger.error(f"Password reset error: {str(e)}")
        return Response({
            'success': False,
            'message': 'An error occurred during password reset',
            'error': str(e)
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['POST'])
@permission_classes([AllowAny])
def refresh_token_view(request):
    """
    Refresh JWT token endpoint (placeholder)
    """
    return Response({
        'success': False,
        'message': 'Token refresh not implemented yet'
    }, status=status.HTTP_501_NOT_IMPLEMENTED)

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def logout_view(request):
    """
    Logout endpoint (same as mobile_logout)
    """
    return mobile_logout(request)
