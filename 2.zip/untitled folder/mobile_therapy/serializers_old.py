# mobile_therapy/serializers.py
from rest_framework import serializers
from .models import Patient, Chapter, Word, TherapySession, VideoSubmission, Progress, SessionHistory

class PatientSerializer(serializers.ModelSerializer):
    full_name = serializers.CharField(read_only=True)
    patient_id = serializers.CharField(read_only=True)
    gender = serializers.CharField(read_only=True)
    
    class Meta:
        model = Patient
        fields = ['id', 'full_name', 'patient_id', 'gender', 'first_clinic_date', 'notes']
        read_only_fields = ['id', 'first_clinic_date']

class ChapterSerializer(serializers.ModelSerializer):
    class Meta:
        model = Chapter
        fields = ['id', 'chapter_number', 'name']

class WordSerializer(serializers.ModelSerializer):
    class Meta:
        model = Word
        fields = ['id', 'word', 'order']

class ChapterDetailSerializer(serializers.ModelSerializer):
    mobile_words = WordSerializer(many=True, read_only=True)
    
    class Meta:
        model = Chapter
        fields = ['id', 'chapter_number', 'name', 'mobile_words']

class TherapySessionSerializer(serializers.ModelSerializer):
    patient_name = serializers.CharField(source='patient.full_name', read_only=True)
    chapter_name = serializers.CharField(source='chapter.name', read_only=True)
    
    class Meta:
        model = TherapySession
        fields = [
            'id', 'patient', 'patient_name', 'chapter', 'chapter_name',
            'started_at', 'completed_at', 'is_completed', 
            'total_words', 'current_word_index'
        ]
        read_only_fields = ['id', 'started_at']

class VideoSubmissionSerializer(serializers.ModelSerializer):
    word_text = serializers.CharField(source='word.word', read_only=True)
    patient_id = serializers.CharField(source='session.patient.patient_id', read_only=True)
    
    class Meta:
        model = VideoSubmission
        fields = [
            'id', 'session', 'word', 'word_text', 'patient_id',
            'video_file', 'uploaded_at', 'processed_at', 'status',
            'predicted_word', 'accuracy_score', 'confidence_scores',
            'analysis_data'
        ]
        read_only_fields = [
            'id', 'uploaded_at', 'processed_at', 'status',
            'predicted_word', 'accuracy_score', 'confidence_scores',
            'analysis_data'
        ]

class VideoSubmissionCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = VideoSubmission
        fields = ['session', 'word', 'video_file']

class ProgressSerializer(serializers.ModelSerializer):
    patient_name = serializers.CharField(source='patient.full_name', read_only=True)
    word_text = serializers.CharField(source='word.word', read_only=True)
    
    class Meta:
        model = Progress
        fields = [
            'id', 'patient', 'patient_name', 'word', 'word_text',
            'trial_number', 'accuracy', 'date', 'time'
        ]

class SessionHistorySerializer(serializers.ModelSerializer):
    patient_name = serializers.CharField(source='patient.full_name', read_only=True)
    
    class Meta:
        model = SessionHistory
        fields = ['id', 'patient', 'patient_name', 'date', 'duration', 'score']

class TherapySessionDetailSerializer(serializers.ModelSerializer):
    patient = PatientSerializer(read_only=True)
    chapter = ChapterDetailSerializer(read_only=True)
    video_submissions = VideoSubmissionSerializer(many=True, read_only=True)
    
    class Meta:
        model = TherapySession
        fields = [
            'id', 'patient', 'chapter', 'started_at', 'completed_at', 
            'is_completed', 'total_words', 'current_word_index',
            'video_submissions'
        ]
