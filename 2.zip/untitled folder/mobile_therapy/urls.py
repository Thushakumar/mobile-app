# mobile_therapy/urls.py
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views, auth_views

router = DefaultRouter()
router.register(r'sessions', views.TherapySessionViewSet, basename='session')

urlpatterns = [
    # Authentication endpoints
    path('auth/login/', auth_views.mobile_login, name='mobile_login'),
    path('auth/reset-password/', auth_views.reset_password, name='mobile_reset_password'),
    path('auth/profile/', auth_views.profile_view, name='mobile_profile'),
    path('auth/refresh/', auth_views.refresh_token_view, name='mobile_refresh_token'),
    path('auth/logout/', auth_views.logout_view, name='mobile_logout'),
    
    # Router URLs
    path('', include(router.urls)),
    
    # Patient endpoints
    path('patients/', views.PatientListView.as_view(), name='patient-list'),
    path('patients/<str:patient_id>/', views.PatientDetailView.as_view(), name='patient-detail'),
    
    # Chapter endpoints
    path('chapters/', views.ChapterListView.as_view(), name='chapter-list'),
    path('chapters/<int:pk>/', views.ChapterDetailView.as_view(), name='chapter-detail'),
    
    # Video submission endpoints
    path('video-submissions/', views.VideoSubmissionCreateView.as_view(), name='video-submission-create'),
    path('video-submissions/list/', views.VideoSubmissionListView.as_view(), name='video-submission-list'),
    path('video-submissions/<int:pk>/', views.VideoSubmissionDetailView.as_view(), name='video-submission-detail'),
    
    # Progress endpoints
    path('progress/', views.ProgressListView.as_view(), name='progress-list'),
    path('session-history/', views.SessionHistoryListView.as_view(), name='session-history-list'),
    
    # Utility endpoints
    path('sessions/<int:session_id>/current-word/', views.get_current_word, name='get-current-word'),
    path('video-submissions/<int:video_submission_id>/analyze/', views.analyze_video, name='analyze-video'),
]
