# mobile_therapy/admin.py
from django.contrib import admin
from .models import TherapySession, VideoSubmission, MobileProgress, MobileSessionHistory

@admin.register(TherapySession)
class TherapySessionAdmin(admin.ModelAdmin):
    list_display = ['patient', 'chapter', 'started_at', 'is_completed', 'current_word_index', 'total_words']
    list_filter = ['is_completed', 'started_at', 'chapter']
    search_fields = ['patient__patient_id', 'patient__full_name']
    readonly_fields = ['started_at']

@admin.register(VideoSubmission)
class VideoSubmissionAdmin(admin.ModelAdmin):
    list_display = ['session', 'word', 'submitted_at', 'is_analyzed', 'accuracy_score']
    list_filter = ['is_analyzed', 'submitted_at', 'word__chapter']
    search_fields = ['session__patient__patient_id', 'word__word']
    readonly_fields = ['submitted_at', 'analysis_completed_at']

@admin.register(MobileProgress)
class MobileProgressAdmin(admin.ModelAdmin):
    list_display = ['patient', 'word', 'attempts', 'best_score', 'last_attempt_date']
    list_filter = ['last_attempt_date', 'word__chapter']
    search_fields = ['patient__patient_id', 'word__word']
    readonly_fields = ['last_attempt_date']

@admin.register(MobileSessionHistory)
class MobileSessionHistoryAdmin(admin.ModelAdmin):
    list_display = ['session', 'words_completed', 'average_accuracy', 'created_at']
    list_filter = ['created_at']
    search_fields = ['session__patient__patient_id']
    readonly_fields = ['created_at']
