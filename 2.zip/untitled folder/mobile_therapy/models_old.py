# mobile_therapy/models.py
from django.db import models
from django.conf import settings
from django.contrib.auth import get_user_model
import os

# Use our custom MobileUser model
User = get_user_model()

class Patient(models.Model):
    """
    Patient model - references mobile users with patient type
    This model provides additional patient-specific information
    beyond what's stored in the MobileUser model
    """
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='patient_profile', 
                               limit_choices_to={'user_type': 'patient'})
    doctor = models.ForeignKey(User, on_delete=models.CASCADE, related_name='mobile_patients',
                              limit_choices_to={'user_type': 'doctor'})
    first_clinic_date = models.DateField(auto_now_add=True)
    notes = models.TextField(blank=True, null=True)
    
    @property
    def full_name(self):
        return self.user.get_full_name()
    
    @property
    def patient_id(self):
        return self.user.patient_id
    
    @property
    def gender(self):
        return self.user.gender
    
    class Meta:
        ordering = ['user__patient_id']
    
    def __str__(self):
        return f"{self.patient_id} - {self.full_name}"

class Chapter(models.Model):
    """
    Chapter model - references the existing chapters in the web app database
    """
    chapter_number = models.IntegerField(unique=True)
    name = models.CharField(max_length=100)
    
    class Meta:
        # Use regular Django table management for now
        ordering = ['chapter_number']
    
    def __str__(self):
        return f"Chapter {self.chapter_number}"

class Word(models.Model):
    """
    Word model - references the existing words in the web app database
    """
    chapter = models.ForeignKey(Chapter, on_delete=models.CASCADE, related_name='mobile_words')
    word = models.CharField(max_length=100)
    order = models.IntegerField()
    
    class Meta:
        ordering = ['order']
    
    def __str__(self):
        return self.word

class TherapySession(models.Model):
    """
    Mobile therapy session model
    Tracks individual therapy sessions for patients
    """
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE, related_name='mobile_sessions')
    chapter = models.ForeignKey(Chapter, on_delete=models.CASCADE)
    started_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    is_completed = models.BooleanField(default=False)
    total_words = models.IntegerField(default=0)
    current_word_index = models.IntegerField(default=0)
    
    class Meta:
        ordering = ['-started_at']
    
    def __str__(self):
        return f"{self.patient.patient_id} - {self.chapter.name} - {self.started_at.date()}"

class VideoSubmission(models.Model):
    """
    Model to store patient video submissions
    """
    STATUS_CHOICES = [
        ('pending', 'Pending Analysis'),
        ('processing', 'Processing'),
        ('completed', 'Analysis Completed'),
        ('failed', 'Analysis Failed'),
    ]
    
    session = models.ForeignKey(TherapySession, on_delete=models.CASCADE, related_name='video_submissions')
    word = models.ForeignKey(Word, on_delete=models.CASCADE)
    video_file = models.FileField(upload_to='videos/%Y/%m/%d/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    processed_at = models.DateTimeField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    
    # ML Analysis Results
    predicted_word = models.CharField(max_length=100, null=True, blank=True)
    accuracy_score = models.FloatField(null=True, blank=True)
    confidence_scores = models.JSONField(null=True, blank=True)  # Store all class probabilities
    
    # Analysis data for web app
    analysis_data = models.JSONField(null=True, blank=True)  # Store detailed analysis results
    
    def __str__(self):
        return f"{self.session.patient.patient_id} - {self.word.word} - {self.uploaded_at.date()}"

class Progress(models.Model):
    """
    Progress model - references the existing progress in the web app database
    """
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE)
    word = models.ForeignKey(Word, on_delete=models.CASCADE)
    trial_number = models.IntegerField()
    accuracy = models.FloatField()
    date = models.DateField()
    time = models.TimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['-date', '-time']
    
    def __str__(self):
        return f"{self.patient.full_name} - {self.word.word} - Trial {self.trial_number}"

class SessionHistory(models.Model):
    """
    SessionHistory model - references the existing session history in the web app database
    """
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE)
    date = models.DateField()
    duration = models.CharField(max_length=20)
    score = models.FloatField()
    
    class Meta:
        ordering = ['-date']
