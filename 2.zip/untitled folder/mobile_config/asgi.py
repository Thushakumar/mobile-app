# mobile_config/asgi.py
import os
from django.core.asgi import get_asgi_application
from channels.routing import ProtocolTypeRouter, URLRouter
from channels.auth import AuthMiddlewareStack
from channels.security.websocket import AllowedHostsOriginValidator
from django.urls import path
from sync_manager.websockets import RealTimeUpdateConsumer, NotificationConsumer

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'mobile_config.settings')

django_asgi_app = get_asgi_application()

websocket_urlpatterns = [
    path('ws/updates/<str:patient_id>/', RealTimeUpdateConsumer.as_asgi()),
    path('ws/updates/<str:patient_id>/<str:client_type>/', RealTimeUpdateConsumer.as_asgi()),
    path('ws/notifications/', NotificationConsumer.as_asgi()),
]

application = ProtocolTypeRouter({
    'http': django_asgi_app,
    'websocket': AllowedHostsOriginValidator(
        AuthMiddlewareStack(
            URLRouter(websocket_urlpatterns)
        )
    ),
})
