"""
Integrated ML Processor for Mobile Backend
Uses the existing ML pipeline from recent_final_project directory
"""

import os
import sys
import numpy as np
import tensorflow as tf
import pickle
import logging
import shutil
import librosa
import ffmpeg
import subprocess
import soundfile as sf
import time
from django.conf import settings

logger = logging.getLogger(__name__)

# Add the recent_final_project directory to Python path to import modules
sys.path.append(settings.ML_MODELS_DIR)

try:
    # Import the ML processing functions from recent_final_project
    from Trimming_Video_Audio_Extraction import trim_video_to_speech
    from Audio_Feature_Extraction import extract_features as extract_audio_features
    from Video_Feature_Extraction import process_video
    from overall_2 import (
        MAX_T, NUM_FRAMES, EXPECTED_VIDEO_FEATURE_DIM, EXPECTED_AUDIO_FEATURES,
        load_pca_and_scaler, load_reference_landmarks, get_frame_count
    )
except ImportError as e:
    logger.error(f"Failed to import ML modules: {e}")
    # Fallback constants if import fails
    MAX_T = 422
    NUM_FRAMES = 30
    EXPECTED_VIDEO_FEATURE_DIM = 54
    EXPECTED_AUDIO_FEATURES = 1080

class IntegratedMLProcessor:
    """
    ML processor that uses the existing pipeline from recent_final_project
    """
    
    def __init__(self):
        # Initialize all attributes to None first
        self.fusion_model = None
        self.class_names = None
        self.landmark_scaler = None
        self.landmark_pca = None
        self.visual_scaler = None
        self.visual_pca = None
        
        try:
            self.setup_paths()
            self.load_models()
            self.setup_temp_directories()
        except Exception as e:
            logger.error(f"Error initializing IntegratedMLProcessor: {e}")
            # Ensure attributes are still None if initialization fails
    
    def setup_paths(self):
        """Setup paths using the original ML project structure"""
        self.ml_models_dir = settings.ML_MODELS_DIR
        self.audio_model_path = settings.AUDIO_MODEL_PATH
        self.video_model_path = settings.VIDEO_MODEL_PATH
        self.fusion_model_path = settings.FUSION_MODEL_PATH
        self.class_names_path = settings.CLASS_NAMES_PATH
        self.landmark_pca_path = settings.LANDMARK_PCA_PATH
        self.landmark_scaler_path = settings.LANDMARK_SCALER_PATH
        self.visual_pca_path = settings.VISUAL_PCA_PATH
        self.visual_scaler_path = settings.VISUAL_SCALER_PATH
        self.reference_landmarks_path = settings.REFERENCE_LANDMARKS_PATH
        self.reference_inter_eye_distance_path = settings.REFERENCE_INTER_EYE_DISTANCE_PATH
        
    def setup_temp_directories(self):
        """Create temporary directories for processing"""
        self.temp_base_dir = os.path.join(settings.MEDIA_ROOT, 'temp_ml_processing')
        self.temp_video_dir = os.path.join(self.temp_base_dir, 'videos')
        self.temp_audio_dir = os.path.join(self.temp_base_dir, 'audio')
        self.temp_features_dir = os.path.join(self.temp_base_dir, 'features')
        self.temp_video_features_dir = os.path.join(self.temp_base_dir, 'video_features')
        self.temp_visual_features_dir = os.path.join(self.temp_base_dir, 'visual_features')
        
        # Create all directories
        for directory in [
            self.temp_base_dir, self.temp_video_dir, self.temp_audio_dir,
            self.temp_features_dir, self.temp_video_features_dir, self.temp_visual_features_dir
        ]:
            os.makedirs(directory, exist_ok=True)
    
    def load_models(self):
        """Load all ML models and preprocessors"""
        try:
            # Load fusion model
            if os.path.exists(self.fusion_model_path):
                self.fusion_model = tf.keras.models.load_model(self.fusion_model_path)
                logger.info(f"Loaded fusion model from: {self.fusion_model_path}")
            else:
                logger.error(f"Fusion model not found at: {self.fusion_model_path}")
                self.fusion_model = None
                
            # Load class names
            if os.path.exists(self.class_names_path):
                self.class_names = np.load(self.class_names_path, allow_pickle=True)
                logger.info(f"Loaded {len(self.class_names)} class names")
            else:
                logger.error(f"Class names not found at: {self.class_names_path}")
                self.class_names = None
                
            # Load PCA and scalers
            self.load_preprocessors()
            
        except Exception as e:
            logger.error(f"Error loading models: {e}")
            self.fusion_model = None
            self.class_names = None
    
    def load_preprocessors(self):
        """Load PCA and scaler objects"""
        try:
            # Load landmark preprocessors
            with open(self.landmark_scaler_path, 'rb') as f:
                self.landmark_scaler = pickle.load(f)
            with open(self.landmark_pca_path, 'rb') as f:
                self.landmark_pca = pickle.load(f)
                
            # Load visual preprocessors
            with open(self.visual_scaler_path, 'rb') as f:
                self.visual_scaler = pickle.load(f)
            with open(self.visual_pca_path, 'rb') as f:
                self.visual_pca = pickle.load(f)
                
            logger.info("Successfully loaded all preprocessors")
            
        except Exception as e:
            logger.error(f"Error loading preprocessors: {e}")
            self.landmark_scaler = None
            self.landmark_pca = None
            self.visual_scaler = None
            self.visual_pca = None
    
    def process_video(self, video_file_path, patient_id, chapter_id):
        """
        Process a video file through the complete ML pipeline
        
        Args:
            video_file_path (str): Path to the uploaded video file
            patient_id (int): ID of the patient
            chapter_id (int): ID of the chapter
            
        Returns:
            dict: Analysis results including predicted class and confidence scores
        """
        try:
            logger.info(f"Starting ML processing for patient {patient_id}, chapter {chapter_id}")
            
            # Step 1: Setup temporary file paths
            video_name = f"patient_{patient_id}_chapter_{chapter_id}_{int(time.time())}"
            temp_video_path = os.path.join(self.temp_video_dir, f"{video_name}.mp4")
            
            # Copy uploaded file to temp location
            shutil.copy2(video_file_path, temp_video_path)
            logger.info(f"Copied video to: {temp_video_path}")
            
            # Step 2: Load reference landmarks (required for video processing)
            self.load_reference_landmarks()
            
            # Step 3: Trim video and extract audio using the original function
            logger.info("Trimming video to speech segments...")
            trimmed_video_path = self.trim_video_to_speech_adapted(temp_video_path)
            if not trimmed_video_path:
                raise Exception("Failed to trim video to speech")
            
            # Step 4: Extract audio features
            logger.info("Extracting audio features...")
            audio_features = self.extract_audio_features_adapted(trimmed_video_path, video_name)
            if audio_features is None:
                raise Exception("Failed to extract audio features")
            
            # Step 5: Extract video features
            logger.info("Extracting video features...")
            video_features = self.extract_video_features_adapted(trimmed_video_path, video_name)
            if video_features is None:
                raise Exception("Failed to extract video features")
            
            # Step 6: Make prediction using fusion model
            logger.info("Making prediction...")
            prediction_result = self.make_prediction(audio_features, video_features)
            
            # Step 7: Cleanup temporary files
            self.cleanup_temp_files(video_name)
            
            logger.info(f"ML processing completed successfully")
            return prediction_result
            
        except Exception as e:
            logger.error(f"Error in ML processing: {e}")
            # Cleanup on error
            try:
                self.cleanup_temp_files(video_name)
            except:
                pass
            return {
                'success': False,
                'error': str(e),
                'predicted_class': None,
                'confidence_scores': None
            }
    
    def load_reference_landmarks(self):
        """Load reference landmarks for video processing"""
        try:
            # Load reference landmarks and inter-eye distance
            global REFERENCE_LANDMARKS, REFERENCE_INTER_EYE_DISTANCE, REFERENCE_SET
            REFERENCE_LANDMARKS = np.load(self.reference_landmarks_path)
            REFERENCE_INTER_EYE_DISTANCE = np.load(self.reference_inter_eye_distance_path)[0]
            REFERENCE_SET = True
            logger.info("Loaded reference landmarks successfully")
        except Exception as e:
            logger.error(f"Error loading reference landmarks: {e}")
    
    def trim_video_to_speech_adapted(self, video_path):
        """Adapt the trim_video_to_speech function for Django use"""
        try:
            # Use the original function but with our temp directory
            output_dir = self.temp_video_dir
            trimmed_path = trim_video_to_speech(video_path, output_dir)
            return trimmed_path
        except Exception as e:
            logger.error(f"Error trimming video: {e}")
            return None
    
    def extract_audio_features_adapted(self, video_path, video_name):
        """Extract audio features from trimmed video"""
        try:
            # Extract audio from video
            audio_path = os.path.join(self.temp_audio_dir, f"{video_name}_audio.wav")
            
            # Extract audio using ffmpeg
            stream = ffmpeg.input(video_path)
            stream = ffmpeg.output(stream, audio_path, format='wav', ar=16000, ac=1, vn=None, loglevel='error')
            ffmpeg.run(stream, overwrite_output=True, capture_stderr=True)
            
            # Extract features using the original function
            audio_features = extract_audio_features(audio_path)
            
            if audio_features is not None:
                # Save features
                feature_path = os.path.join(self.temp_features_dir, f"{video_name}_audio_features.npy")
                np.save(feature_path, audio_features)
                logger.info(f"Audio features shape: {audio_features.shape}")
                return audio_features
            else:
                return None
                
        except Exception as e:
            logger.error(f"Error extracting audio features: {e}")
            return None
    
    def extract_video_features_adapted(self, video_path, video_name):
        """Extract video features from trimmed video"""
        try:
            # Use the original process_video function
            video_output_dir = os.path.join(self.temp_video_dir, video_name)
            os.makedirs(video_output_dir, exist_ok=True)
            
            landmark_features = process_video(
                video_path,
                video_output_dir,
                self.temp_video_features_dir,
                self.temp_visual_features_dir,
                is_first_video=True,
                plot=False
            )
            
            if landmark_features is not None:
                logger.info(f"Video features shape: {landmark_features.shape}")
                return landmark_features
            else:
                # Try loading existing features
                trimmed_video_name = os.path.splitext(os.path.basename(video_path))[0]
                video_feature_path = os.path.join(self.temp_video_features_dir, f"{trimmed_video_name}_features.npy")
                visual_feature_path = os.path.join(self.temp_visual_features_dir, f"{trimmed_video_name}_features.npy")
                
                if os.path.exists(video_feature_path) and os.path.exists(visual_feature_path):
                    video_features = np.load(video_feature_path)
                    return video_features
                else:
                    return None
                    
        except Exception as e:
            logger.error(f"Error extracting video features: {e}")
            return None
    
    def make_prediction(self, audio_features, video_features):
        """Make prediction using the fusion model"""
        try:
            # Preprocess audio features
            if audio_features.shape[0] != EXPECTED_AUDIO_FEATURES:
                logger.warning(f"Audio features shape mismatch: {audio_features.shape}")
                return None
                
            current_T = audio_features.shape[1]
            if current_T < MAX_T:
                pad_width = MAX_T - current_T
                audio_features = np.pad(audio_features, ((0, 0), (0, pad_width)), mode='constant', constant_values=0)
            elif current_T > MAX_T:
                audio_features = audio_features[:, :MAX_T]
                
            audio_features = audio_features[np.newaxis, :, :]  # Add batch dimension
            audio_features = np.transpose(audio_features, (0, 2, 1))  # (batch, time, features)
            
            # Preprocess video features using PCA and scalers
            if video_features.shape != (NUM_FRAMES, 276):
                logger.warning(f"Video features shape mismatch: {video_features.shape}")
                return None
            
            # Apply PCA transformation as in original pipeline
            n_samples, n_timesteps, n_features = 1, video_features.shape[0], video_features.shape[1]
            video_features_reshaped = video_features.reshape(-1, n_features)
            video_features_normalized = self.landmark_scaler.transform(video_features_reshaped)
            video_features_pca = self.landmark_pca.transform(video_features_normalized)
            processed_video_features = video_features_pca.reshape(n_samples, n_timesteps, -1)[0]
            
            # Make prediction
            prediction = self.fusion_model.predict([audio_features, processed_video_features[np.newaxis, :, :]], verbose=0)
            predicted_class_idx = np.argmax(prediction, axis=1)[0]
            predicted_class = self.class_names[predicted_class_idx]
            
            # Create confidence scores dictionary
            confidence_scores = {}
            for idx, prob in enumerate(prediction[0]):
                confidence_scores[self.class_names[idx]] = float(prob)
            
            return {
                'success': True,
                'predicted_class': predicted_class,
                'confidence_scores': confidence_scores,
                'raw_prediction': prediction[0].tolist()
            }
            
        except Exception as e:
            logger.error(f"Error making prediction: {e}")
            return {
                'success': False,
                'error': str(e),
                'predicted_class': None,
                'confidence_scores': None
            }
    
    def cleanup_temp_files(self, video_name):
        """Clean up temporary files after processing"""
        try:
            # Remove temporary files
            patterns = [
                os.path.join(self.temp_video_dir, f"{video_name}*"),
                os.path.join(self.temp_audio_dir, f"{video_name}*"),
                os.path.join(self.temp_features_dir, f"{video_name}*"),
                os.path.join(self.temp_video_features_dir, f"{video_name}*"),
                os.path.join(self.temp_visual_features_dir, f"{video_name}*"),
            ]
            
            import glob
            for pattern in patterns:
                for file_path in glob.glob(pattern):
                    try:
                        if os.path.isfile(file_path):
                            os.remove(file_path)
                        elif os.path.isdir(file_path):
                            shutil.rmtree(file_path)
                    except Exception as e:
                        logger.warning(f"Could not remove {file_path}: {e}")
                        
            logger.info(f"Cleaned up temporary files for {video_name}")
            
        except Exception as e:
            logger.warning(f"Error during cleanup: {e}")

# Global processor instance
_processor = None

def get_ml_processor():
    """Get or create the ML processor instance"""
    global _processor
    if _processor is None:
        _processor = IntegratedMLProcessor()
    return _processor
