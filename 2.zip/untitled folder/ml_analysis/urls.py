# ml_analysis/urls.py
from django.urls import path
from . import views

app_name = 'ml_analysis'

urlpatterns = [
    # ML analysis endpoints
    path('analyze/<int:video_submission_id>/', views.analyze_video_submission, name='analyze_video'),
    path('batch-analyze/<int:session_id>/', views.batch_analyze_session, name='batch_analyze_session'),
    path('status/<int:video_submission_id>/', views.get_analysis_status, name='analysis_status'),
    path('task-status/<str:task_id>/', views.get_task_status, name='task_status'),
    path('health/', views.health_check, name='health_check'),
]
