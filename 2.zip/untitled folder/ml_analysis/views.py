# ml_analysis/views.py
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
import logging

from .services import ml_service
from mobile_therapy.models import VideoSubmission, TherapySession

logger = logging.getLogger(__name__)

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def analyze_video_submission(request, video_submission_id):
    """
    Trigger ML analysis for a specific video submission
    Supports both sync and async processing
    """
    try:
        # Get async preference from request
        async_processing = request.data.get('async', True)  # Default to async
        
        result = ml_service.analyze_video(video_submission_id, async_processing=async_processing)
        
        if result.get('success', False):
            return Response(result, status=status.HTTP_200_OK)
        else:
            return Response(result, status=status.HTTP_400_BAD_REQUEST)
            
    except Exception as e:
        logger.error(f"Error in analyze_video_submission: {e}")
        return Response(
            {'success': False, 'error': str(e)}, 
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def batch_analyze_session(request, session_id):
    """
    Analyze all video submissions in a therapy session
    """
    try:
        async_processing = request.data.get('async', True)
        
        if async_processing:
            from .tasks import batch_analyze_session_async
            task = batch_analyze_session_async.delay(session_id)
            
            return Response({
                'success': True,
                'async': True,
                'task_id': task.id,
                'session_id': session_id,
                'message': 'Batch analysis queued for processing'
            }, status=status.HTTP_200_OK)
        else:
            # Synchronous batch processing (not recommended for large batches)
            session = TherapySession.objects.get(id=session_id)
            video_submissions = session.video_submissions.filter(is_analyzed=False)
            
            results = []
            for video_submission in video_submissions:
                result = ml_service.analyze_video(video_submission.id, async_processing=False)
                results.append(result)
            
            successful_analyses = [r for r in results if r.get('success', False)]
            
            return Response({
                'success': True,
                'session_id': session_id,
                'total_submissions': len(results),
                'successful_analyses': len(successful_analyses),
                'results': results
            }, status=status.HTTP_200_OK)
            
    except Exception as e:
        logger.error(f"Error in batch_analyze_session: {e}")
        return Response(
            {'success': False, 'error': str(e)}, 
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_task_status(request, task_id):
    """
    Get the status of a Celery task
    """
    try:
        from celery.result import AsyncResult
        
        task_result = AsyncResult(task_id)
        
        return Response({
            'task_id': task_id,
            'status': task_result.status,
            'result': task_result.result if task_result.ready() else None,
            'ready': task_result.ready(),
            'successful': task_result.successful() if task_result.ready() else None
        }, status=status.HTTP_200_OK)
        
    except Exception as e:
        logger.error(f"Error getting task status: {e}")
        return Response(
            {'error': str(e)}, 
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_analysis_status(request, video_submission_id):
    """
    Get the analysis status of a video submission
    """
    try:
        video_submission = VideoSubmission.objects.get(id=video_submission_id)
        
        return Response({
            'video_submission_id': video_submission_id,
            'is_analyzed': video_submission.is_analyzed,
            'predicted_class': getattr(video_submission, 'ml_predicted_class', None),
            'confidence_score': getattr(video_submission, 'confidence_score', None),
            'accuracy_score': getattr(video_submission, 'accuracy_score', None),
            'analysis_result': getattr(video_submission, 'ml_analysis_result', None),
            'status': getattr(video_submission, 'status', 'unknown'),
            'processed_at': video_submission.processed_at.isoformat() if hasattr(video_submission, 'processed_at') and video_submission.processed_at else None
        }, status=status.HTTP_200_OK)
            
    except VideoSubmission.DoesNotExist:
        return Response(
            {'error': f'Video submission {video_submission_id} not found'}, 
            status=status.HTTP_404_NOT_FOUND
        )
    except Exception as e:
        logger.error(f"Error in get_analysis_status: {e}")
        return Response(
            {'error': str(e)}, 
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def health_check(request):
    """
    Check if ML analysis service is working
    """
    try:
        # Import and check ML processor
        from .integrated_ml_processor import get_ml_processor
        processor = get_ml_processor()
        
        # Check if models are loaded
        models_loaded = {
            'fusion_model': processor.fusion_model is not None,
            'class_names': processor.class_names is not None,
            'preprocessors': all([
                processor.landmark_scaler is not None,
                processor.landmark_pca is not None,
                processor.visual_scaler is not None,
                processor.visual_pca is not None
            ])
        }
        
        all_loaded = all(models_loaded.values())
        
        return Response({
            'status': 'healthy' if all_loaded else 'partial',
            'models_loaded': models_loaded,
            'ml_models_dir': processor.ml_models_dir,
        }, status=status.HTTP_200_OK)
        
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return Response({
            'status': 'unhealthy',
            'error': str(e)
        }, status=status.HTTP_503_SERVICE_UNAVAILABLE)
