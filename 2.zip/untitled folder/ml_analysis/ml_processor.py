# ml_analysis/ml_processor.py
import os
import numpy as np
import tensorflow as tf
import pickle
import logging
import shutil
import librosa
import ffmpeg
import subprocess
import soundfile as sf
import time
from django.conf import settings

logger = logging.getLogger(__name__)

# Constants from the original ML script
MAX_T = 422
NUM_FRAMES = 30
EXPECTED_VIDEO_FEATURE_DIM = 54
EXPECTED_AUDIO_FEATURES = 1080

class MLVideoProcessor:
    """
    Adapted ML processor for Django integration
    """
    
    def __init__(self):
        self.setup_paths()
        self.load_models()
        self.load_preprocessors()
    
    def setup_paths(self):
        """Setup paths for models and temporary files"""
        self.ml_models_dir = settings.ML_MODELS_DIR
        self.audio_model_path = settings.AUDIO_MODEL_PATH
        self.video_model_path = settings.VIDEO_MODEL_PATH
        self.fusion_model_path = settings.FUSION_MODEL_PATH
        self.class_names_path = settings.CLASS_NAMES_PATH
        self.landmark_pca_path = settings.LANDMARK_PCA_PATH
        self.landmark_scaler_path = settings.LANDMARK_SCALER_PATH
        self.visual_pca_path = settings.VISUAL_PCA_PATH
        self.visual_scaler_path = settings.VISUAL_SCALER_PATH
        
        # Create temporary directories
        self.temp_dir = os.path.join(settings.MEDIA_ROOT, 'temp_ml_processing')
        os.makedirs(self.temp_dir, exist_ok=True)
        
    def load_models(self):
        """Load pre-trained models"""
        try:
            if os.path.exists(self.fusion_model_path):
                self.fusion_model = tf.keras.models.load_model(self.fusion_model_path)
                logger.info(f"Loaded fusion model from: {self.fusion_model_path}")
            else:
                logger.error(f"Fusion model not found at: {self.fusion_model_path}")
                self.fusion_model = None
                
            # Load class names
            if os.path.exists(self.class_names_path):
                self.class_names = np.load(self.class_names_path, allow_pickle=True)
                logger.info(f"Loaded {len(self.class_names)} class names")
            else:
                logger.error(f"Class names not found at: {self.class_names_path}")
                self.class_names = None
                
        except Exception as e:
            logger.error(f"Error loading models: {e}")
            self.fusion_model = None
            self.class_names = None
    
    def load_preprocessors(self):
        """Load PCA and scaler objects"""
        try:
            # Load landmark preprocessors
            if os.path.exists(self.landmark_scaler_path):
                with open(self.landmark_scaler_path, 'rb') as f:
                    self.landmark_scaler = pickle.load(f)
            else:
                self.landmark_scaler = None
                
            if os.path.exists(self.landmark_pca_path):
                with open(self.landmark_pca_path, 'rb') as f:
                    self.landmark_pca = pickle.load(f)
            else:
                self.landmark_pca = None
                
            # Load visual preprocessors
            if os.path.exists(self.visual_scaler_path):
                with open(self.visual_scaler_path, 'rb') as f:
                    self.visual_scaler = pickle.load(f)
            else:
                self.visual_scaler = None
                
            if os.path.exists(self.visual_pca_path):
                with open(self.visual_pca_path, 'rb') as f:
                    self.visual_pca = pickle.load(f)
            else:
                self.visual_pca = None
                
            logger.info("Preprocessors loaded successfully")
            
        except Exception as e:
            logger.error(f"Error loading preprocessors: {e}")
            self.landmark_scaler = None
            self.landmark_pca = None
            self.visual_scaler = None
            self.visual_pca = None
    
    def extract_audio_features_simple(self, audio_path):
        """
        Simplified audio feature extraction
        """
        try:
            # Load audio
            audio_data, sr = librosa.load(audio_path, sr=16000, mono=True)
            
            # Extract MFCC features (simplified version)
            mfccs = librosa.feature.mfcc(y=audio_data, sr=sr, n_mfcc=13, n_fft=512, hop_length=160)
            
            # Pad or truncate to expected size
            target_frames = MAX_T
            if mfccs.shape[1] < target_frames:
                # Pad with zeros
                padding = target_frames - mfccs.shape[1]
                mfccs = np.pad(mfccs, ((0, 0), (0, padding)), mode='constant')
            elif mfccs.shape[1] > target_frames:
                # Truncate
                mfccs = mfccs[:, :target_frames]
            
            return mfccs
            
        except Exception as e:
            logger.error(f"Error extracting audio features: {e}")
            return None
    
    def extract_video_features_simple(self, video_path):
        """
        Simplified video feature extraction (placeholder)
        In a real implementation, this would process facial landmarks
        """
        try:
            # For now, return dummy features with correct shape
            # In production, implement actual facial landmark detection
            video_features = np.random.rand(NUM_FRAMES, 276)
            visual_features = np.random.rand(NUM_FRAMES, 512)
            
            return video_features, visual_features
            
        except Exception as e:
            logger.error(f"Error extracting video features: {e}")
            return None, None
    
    def preprocess_features(self, video_features, visual_features):
        """
        Preprocess video and visual features using PCA and scalers
        """
        try:
            if self.landmark_scaler is None or self.landmark_pca is None:
                logger.warning("Landmark preprocessors not available, using raw features")
                processed_video = video_features
            else:
                # Process video features
                video_reshaped = video_features.reshape(-1, video_features.shape[1])
                video_normalized = self.landmark_scaler.transform(video_reshaped)
                video_pca = self.landmark_pca.transform(video_normalized)
                processed_video = video_pca.reshape(1, NUM_FRAMES, -1)[0]
            
            if self.visual_scaler is None or self.visual_pca is None:
                logger.warning("Visual preprocessors not available, using raw features")
                processed_visual = visual_features
            else:
                # Process visual features
                visual_reshaped = visual_features.reshape(-1, visual_features.shape[1])
                visual_normalized = self.visual_scaler.transform(visual_reshaped)
                visual_pca = self.visual_pca.transform(visual_normalized)
                processed_visual = visual_pca.reshape(1, NUM_FRAMES, -1)[0]
            
            # Combine features
            combined_features = np.concatenate([processed_video, processed_visual], axis=-1)
            
            # Ensure correct dimensions
            if combined_features.shape[-1] != EXPECTED_VIDEO_FEATURE_DIM:
                # Adjust dimensions if needed
                if combined_features.shape[-1] > EXPECTED_VIDEO_FEATURE_DIM:
                    combined_features = combined_features[:, :EXPECTED_VIDEO_FEATURE_DIM]
                else:
                    # Pad with zeros
                    padding = EXPECTED_VIDEO_FEATURE_DIM - combined_features.shape[-1]
                    combined_features = np.pad(combined_features, ((0, 0), (0, padding)), mode='constant')
            
            return combined_features
            
        except Exception as e:
            logger.error(f"Error preprocessing features: {e}")
            return None
    
    def predict_video_class(self, video_path):
        """
        Main prediction function
        """
        try:
            logger.info(f"Starting prediction for video: {video_path}")
            
            if not self.fusion_model or not self.class_names:
                raise Exception("Models not properly loaded")
            
            # Extract audio from video
            audio_path = os.path.join(self.temp_dir, f"temp_audio_{int(time.time())}.wav")
            
            try:
                # Extract audio using ffmpeg
                stream = ffmpeg.input(video_path)
                stream = ffmpeg.output(stream, audio_path, format='wav', ar=16000, ac=1, vn=None)
                ffmpeg.run(stream, overwrite_output=True, capture_stderr=True, quiet=True)
                
                if not os.path.exists(audio_path):
                    raise Exception("Audio extraction failed")
                
                # Extract audio features
                audio_features = self.extract_audio_features_simple(audio_path)
                if audio_features is None:
                    raise Exception("Audio feature extraction failed")
                
                # Prepare audio features for model
                audio_features = audio_features[np.newaxis, :, :]  # Add batch dimension
                audio_features = np.transpose(audio_features, (0, 2, 1))  # (batch, time, features)
                
                # Extract video features
                video_features, visual_features = self.extract_video_features_simple(video_path)
                if video_features is None or visual_features is None:
                    raise Exception("Video feature extraction failed")
                
                # Preprocess features
                combined_features = self.preprocess_features(video_features, visual_features)
                if combined_features is None:
                    raise Exception("Feature preprocessing failed")
                
                # Add batch dimension
                combined_features = combined_features[np.newaxis, :, :]
                
                # Make prediction
                logger.info(f"Making prediction with shapes - Audio: {audio_features.shape}, Video: {combined_features.shape}")
                prediction = self.fusion_model.predict([audio_features, combined_features], verbose=0)
                
                # Get predicted class
                predicted_class_idx = np.argmax(prediction, axis=1)[0]
                predicted_class = self.class_names[predicted_class_idx]
                
                # Get confidence scores
                confidence_scores = {}
                for idx, prob in enumerate(prediction[0]):
                    confidence_scores[self.class_names[idx]] = float(prob)
                
                logger.info(f"Prediction completed: {predicted_class}")
                
                return {
                    'predicted_class': predicted_class,
                    'confidence_scores': confidence_scores,
                    'predicted_index': int(predicted_class_idx)
                }
                
            finally:
                # Clean up temporary audio file
                if os.path.exists(audio_path):
                    os.remove(audio_path)
            
        except Exception as e:
            logger.error(f"Error in video prediction: {e}")
            return None

# Global processor instance
ml_processor = MLVideoProcessor()
