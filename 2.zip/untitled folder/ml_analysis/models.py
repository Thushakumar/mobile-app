# ml_analysis/models.py
from django.db import models
from mobile_therapy.models import VideoSubmission

class MLAnalysisResult(models.Model):
    """
    Detailed ML analysis results
    """
    video_submission = models.OneToOneField(VideoSubmission, on_delete=models.CASCADE, related_name='ml_result')
    
    # Audio features
    audio_features_shape = models.CharField(max_length=100, null=True, blank=True)
    audio_processing_time = models.FloatField(null=True, blank=True)
    
    # Video features  
    video_features_shape = models.CharField(max_length=100, null=True, blank=True)
    visual_features_shape = models.CharField(max_length=100, null=True, blank=True)
    video_processing_time = models.FloatField(null=True, blank=True)
    
    # Model prediction
    predicted_class_index = models.IntegerField(null=True, blank=True)
    prediction_confidence = models.FloatField(null=True, blank=True)
    all_class_probabilities = models.JSONField(null=True, blank=True)
    
    # Processing metadata
    model_version = models.CharField(max_length=50, default='v1.0')
    processing_errors = models.TextField(null=True, blank=True)
    total_processing_time = models.FloatField(null=True, blank=True)
    
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"Analysis for {self.video_submission}"
