# ml_analysis/services.py
import os
import logging
import time
from django.conf import settings
from django.utils import timezone
from .models import MLAnalysisResult
from .integrated_ml_processor import get_ml_processor
from mobile_therapy.models import VideoSubmission

logger = logging.getLogger(__name__)

class MLAnalysisService:
    """
    Service class to handle ML analysis of video submissions
    Supports both synchronous and asynchronous processing
    """
    
    def __init__(self):
        self.use_async = getattr(settings, 'USE_ASYNC_ML_ANALYSIS', True)
    
    def analyze_video(self, video_submission_id, async_processing=None):
        """
        Analyze a video submission using ML model
        
        Args:
            video_submission_id (int): ID of the video submission
            async_processing (bool): Override async setting. If None, uses settings default
            
        Returns:
            dict: Analysis result or task info if async
        """
        use_async = async_processing if async_processing is not None else self.use_async
        
        if use_async:
            return self._analyze_video_async(video_submission_id)
        else:
            return self._analyze_video_sync(video_submission_id)
    
    def _analyze_video_async(self, video_submission_id):
        """
        Queue video for asynchronous analysis
        """
        try:
            from .tasks import analyze_video_async
            
            # Update video submission status
            video_submission = VideoSubmission.objects.get(id=video_submission_id)
            video_submission.status = 'queued'
            video_submission.save()
            
            # Queue the task
            task = analyze_video_async.delay(video_submission_id)
            
            logger.info(f"Queued async analysis for video {video_submission_id}, task ID: {task.id}")
            
            return {
                'success': True,
                'async': True,
                'task_id': task.id,
                'video_submission_id': video_submission_id,
                'status': 'queued',
                'message': 'Video analysis queued for processing'
            }
            
        except Exception as e:
            logger.error(f"Error queuing async analysis for video {video_submission_id}: {e}")
            return {
                'success': False,
                'error': f'Failed to queue analysis: {str(e)}',
                'video_submission_id': video_submission_id
            }
    
    def _analyze_video_sync(self, video_submission_id):
        """
        Analyze a video submission synchronously (original implementation)
        """
        start_time = time.time()
        
        try:
            # Get video submission
            video_submission = VideoSubmission.objects.get(id=video_submission_id)
            video_submission.status = 'processing'
            video_submission.save()
            
            logger.info(f"Starting sync analysis for video submission {video_submission_id}")
            
            # Extract video path
            video_path = video_submission.video_file.path
            if not os.path.exists(video_path):
                raise Exception(f"Video file not found: {video_path}")
            
            # Initialize integrated ML processor
            ml_processor = get_ml_processor()
            
            # Get patient and chapter info
            patient_id = video_submission.session.patient.patient_id
            chapter_id = video_submission.session.chapter.id
            
            # Run the ML analysis using the integrated pipeline
            result = ml_processor.process_video(
                video_file_path=video_path,
                patient_id=patient_id,
                chapter_id=chapter_id
            )
            
            if not result.get('success', False):
                raise Exception(f"ML prediction failed: {result.get('error', 'Unknown error')}")
            
            predicted_word = result.get('predicted_class', 'unknown')
            confidence_scores = result.get('confidence_scores', {})
            
            # Calculate accuracy (simple comparison)
            target_word = video_submission.word.word.lower() if hasattr(video_submission, 'word') and video_submission.word else 'unknown'
            predicted_word_lower = predicted_word.lower() if predicted_word else ''
            accuracy_score = 1.0 if target_word == predicted_word_lower else 0.0
            
            # Update video submission
            video_submission.predicted_word = predicted_word
            video_submission.accuracy_score = accuracy_score
            video_submission.confidence_scores = confidence_scores
            video_submission.status = 'completed'
            video_submission.processed_at = timezone.now()
            
            # Create analysis data for web app
            analysis_data = {
                'predicted_class': predicted_word,
                'target_word': target_word,
                'accuracy': accuracy_score,
                'confidence_scores': confidence_scores,
                'processing_time': time.time() - start_time,
                'timestamp': timezone.now().isoformat()
            }
            video_submission.analysis_data = analysis_data
            video_submission.save()
            
            # Create detailed ML analysis result
            ml_result = MLAnalysisResult.objects.create(
                video_submission=video_submission,
                predicted_class_index=0,  # Default since we don't have index from new processor
                prediction_confidence=confidence_scores.get(predicted_word, 0.0),
                all_class_probabilities=confidence_scores,
                model_version='v1.0',
                total_processing_time=time.time() - start_time
            )
            
            logger.info(f"Analysis completed for video submission {video_submission_id}")
            logger.info(f"Predicted: {predicted_word}, Target: {target_word}, Accuracy: {accuracy_score}")
            
            return {
                'success': True,
                'predicted_word': predicted_word,
                'accuracy_score': accuracy_score,
                'confidence_scores': confidence_scores,
                'processing_time': time.time() - start_time
            }
            
        except Exception as e:
            logger.error(f"Error analyzing video submission {video_submission_id}: {e}")
            
            # Update video submission status
            try:
                video_submission = VideoSubmission.objects.get(id=video_submission_id)
                video_submission.status = 'failed'
                video_submission.processed_at = timezone.now()
                video_submission.save()
                
                # Create failed analysis result
                MLAnalysisResult.objects.create(
                    video_submission=video_submission,
                    processing_errors=str(e),
                    total_processing_time=time.time() - start_time
                )
            except:
                pass
            
            return {
                'success': False,
                'error': str(e),
                'processing_time': time.time() - start_time
            }

# Global instance
ml_service = MLAnalysisService()
