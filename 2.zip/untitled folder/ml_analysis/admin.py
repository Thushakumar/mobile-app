# ml_analysis/admin.py
from django.contrib import admin
from .models import MLAnalysisResult

@admin.register(MLAnalysisResult)
class MLAnalysisResultAdmin(admin.ModelAdmin):
    list_display = ['video_submission', 'predicted_class_index', 'prediction_confidence', 'model_version', 'created_at']
    list_filter = ['model_version', 'created_at']
    search_fields = ['video_submission__session__patient__patient_id']
    readonly_fields = ['created_at']
