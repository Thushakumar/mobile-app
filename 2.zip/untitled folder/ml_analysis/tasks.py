# ml_analysis/tasks.py
from celery import shared_task
import logging
from django.utils import timezone
from .integrated_ml_processor import get_ml_processor
from mobile_therapy.models import VideoSubmission

logger = logging.getLogger(__name__)

@shared_task(bind=True, max_retries=2)
def analyze_video_async(self, video_submission_id):
    """
    Asynchronous task for ML video analysis
    """
    try:
        logger.info(f"Starting async ML analysis for video submission {video_submission_id}")
        
        # Get video submission
        try:
            video_submission = VideoSubmission.objects.get(id=video_submission_id)
        except VideoSubmission.DoesNotExist:
            logger.error(f"Video submission {video_submission_id} not found")
            return {
                'success': False,
                'error': 'Video submission not found',
                'video_submission_id': video_submission_id
            }
        
        # Update status to processing
        video_submission.status = 'processing'
        video_submission.save()
        
        # Get ML processor
        processor = get_ml_processor()
        
        # Get video file path
        video_file_path = video_submission.video_file.path
        
        # Get patient and chapter info
        patient_id = video_submission.session.patient.patient_id
        chapter_id = video_submission.session.chapter.id
        
        # Process video through ML pipeline
        result = processor.process_video(
            video_file_path=video_file_path,
            patient_id=patient_id,
            chapter_id=chapter_id
        )
        
        # Update video submission with results
        if result.get('success', False):
            predicted_class = result.get('predicted_class')
            confidence_scores = result.get('confidence_scores', {})
            
            # Calculate accuracy score (you can modify this logic based on your needs)
            max_confidence = max(confidence_scores.values()) if confidence_scores else 0.0
            
            video_submission.ml_predicted_class = predicted_class
            video_submission.confidence_score = max_confidence
            video_submission.accuracy_score = max_confidence  # Simplified scoring
            video_submission.ml_analysis_result = result
            video_submission.is_analyzed = True
            video_submission.status = 'completed'
            video_submission.processed_at = timezone.now()
            
            logger.info(f"Async analysis completed for video {video_submission_id}: {predicted_class} ({max_confidence:.3f})")
            
        else:
            error_msg = result.get('error', 'Unknown error')
            logger.error(f"Async analysis failed for video {video_submission_id}: {error_msg}")
            
            video_submission.ml_analysis_result = result
            video_submission.is_analyzed = False
            video_submission.status = 'failed'
            video_submission.processed_at = timezone.now()
        
        video_submission.save()
        
        return {
            'success': result.get('success', False),
            'video_submission_id': video_submission_id,
            'predicted_class': result.get('predicted_class'),
            'confidence_score': max_confidence if result.get('success', False) else None,
            'error': result.get('error') if not result.get('success', False) else None
        }
        
    except Exception as e:
        logger.error(f"Error in async ML analysis for video {video_submission_id}: {e}")
        
        # Update video submission status on error
        try:
            video_submission = VideoSubmission.objects.get(id=video_submission_id)
            video_submission.status = 'failed'
            video_submission.processed_at = timezone.now()
            video_submission.ml_analysis_result = {
                'success': False,
                'error': str(e)
            }
            video_submission.save()
        except:
            pass
        
        # Retry if we haven't exceeded max retries
        if self.request.retries < self.max_retries:
            logger.info(f"Retrying ML analysis for video {video_submission_id} (attempt {self.request.retries + 1})")
            raise self.retry(countdown=60, exc=e)  # Retry after 60 seconds
        
        return {
            'success': False,
            'error': str(e),
            'video_submission_id': video_submission_id
        }

@shared_task
def batch_analyze_session_async(session_id):
    """
    Asynchronous task for batch analyzing all videos in a session
    """
    try:
        from mobile_therapy.models import TherapySession
        
        logger.info(f"Starting batch async analysis for session {session_id}")
        
        session = TherapySession.objects.get(id=session_id)
        video_submissions = session.video_submissions.filter(is_analyzed=False)
        
        # Queue individual analysis tasks
        task_results = []
        for video_submission in video_submissions:
            task = analyze_video_async.delay(video_submission.id)
            task_results.append({
                'video_submission_id': video_submission.id,
                'task_id': task.id
            })
        
        return {
            'success': True,
            'session_id': session_id,
            'total_submissions': len(task_results),
            'queued_tasks': task_results
        }
        
    except Exception as e:
        logger.error(f"Error in batch async analysis for session {session_id}: {e}")
        return {
            'success': False,
            'error': str(e),
            'session_id': session_id
        }

@shared_task
def cleanup_temp_files():
    """
    Periodic task to cleanup temporary ML processing files
    """
    try:
        import os
        import shutil
        from django.conf import settings
        
        temp_dir = os.path.join(settings.MEDIA_ROOT, 'temp_ml_processing')
        if os.path.exists(temp_dir):
            # Remove files older than 1 hour
            import time
            current_time = time.time()
            
            for root, dirs, files in os.walk(temp_dir):
                for file in files:
                    file_path = os.path.join(root, file)
                    if os.path.isfile(file_path):
                        file_age = current_time - os.path.getmtime(file_path)
                        if file_age > 3600:  # 1 hour in seconds
                            os.remove(file_path)
                            logger.info(f"Cleaned up temp file: {file_path}")
            
            logger.info("Temp files cleanup completed")
            return {'success': True, 'message': 'Temp files cleaned up'}
        else:
            return {'success': True, 'message': 'No temp directory found'}
            
    except Exception as e:
        logger.error(f"Error in temp files cleanup: {e}")
        return {'success': False, 'error': str(e)}
