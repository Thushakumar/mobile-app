from django.db import models
from patients.models import Patient
from chapters.models import Word, Chapter

class Progress(models.Model):
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE)
    word = models.ForeignKey(Word, on_delete=models.CASCADE)
    trial_number = models.IntegerField()
    accuracy = models.FloatField()
    date = models.DateField()
    time = models.TimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['-date', '-time']
    
    def __str__(self):
        return f"{self.patient.full_name} - {self.word.word} - Trial {self.trial_number}"

class TherapySession(models.Model):
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE)
    chapter = models.ForeignKey(Chapter, on_delete=models.CASCADE)
    current_word_index = models.IntegerField(default=0)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.patient.full_name} - Chapter {self.chapter.chapter_number}"

    @property
    def current_word(self):
        words = self.chapter.words.all()
        if self.current_word_index < len(words):
            return words[self.current_word_index]
        return None

class SessionHistory(models.Model):
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE)
    date = models.DateField()
    duration = models.CharField(max_length=20)
    score = models.FloatField()
    
    class Meta:
        ordering = ['-date']