# backend/progress/serializers.py
from rest_framework import serializers
from .models import Progress, SessionHistory, TherapySession
from patients.serializers import PatientSerializer
from chapters.serializers import WordSerializer, ChapterSerializer

class ProgressSerializer(serializers.ModelSerializer):
    patient_detail = PatientSerializer(source='patient', read_only=True)
    word_detail = WordSerializer(source='word', read_only=True)
    
    class Meta:
        model = Progress
        fields = ['id', 'patient', 'patient_detail', 'word', 'word_detail', 
                  'trial_number', 'accuracy', 'date', 'time']
        read_only_fields = ['time']

class TherapySessionSerializer(serializers.ModelSerializer):
    patient_detail = PatientSerializer(source='patient', read_only=True)
    chapter_detail = ChapterSerializer(source='chapter', read_only=True)
    current_word_detail = serializers.SerializerMethodField()
    
    class Meta:
        model = TherapySession
        fields = ['id', 'patient', 'patient_detail', 'chapter', 'chapter_detail', 
                  'current_word_index', 'current_word_detail', 'is_active', 
                  'created_at', 'completed_at']
    
    def get_current_word_detail(self, obj):
        current_word = obj.current_word
        if current_word:
            return WordSerializer(current_word).data
        return None

class SessionHistorySerializer(serializers.ModelSerializer):
    patient_detail = PatientSerializer(source='patient', read_only=True)
    
    class Meta:
        model = SessionHistory
        fields = ['id', 'patient', 'patient_detail', 'date', 'duration', 'score']