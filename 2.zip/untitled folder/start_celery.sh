#!/bin/bash
# Start Redis server (required for Celery)
echo "Starting Redis server..."
redis-server --daemonize yes

# Start Celery worker for ML analysis
echo "Starting Celery worker for ML analysis..."
cd "$(dirname "$0")"
/Users/shageethpratheepvaratharajan/projects/sivanu/.venv/bin/celery -A mobile_config worker --loglevel=info --concurrency=2 -Q default,ml_analysis

# Note: Use concurrency=2 to limit resource usage during ML processing
