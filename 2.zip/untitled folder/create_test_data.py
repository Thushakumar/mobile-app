#!/usr/bin/env python
"""
Script to create test data for the mobile backend
"""
import os
import sys
import django

# Add the project root to the Python path
sys.path.append('/Users/shageethpratheepvaratharajan/projects/sivanu/neuro-speak-mobile-backend')

# Set the Django settings module
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'mobile_config.settings_minimal')

# Setup Django
django.setup()

from django.contrib.auth.hashers import make_password
from users.models import User
from patients.models import Patient
from chapters.models import Chapter, Word

def create_test_data():
    print("Creating test data...")
    
    # Create a test doctor user
    doctor, created = User.objects.get_or_create(
        username='doctor1',
        defaults={
            'email': 'doctor1@example.com',
            'first_name': 'Dr. John',
            'last_name': 'Smith',
            'is_doctor': True,
            'password': make_password('doctor123')
        }
    )
    if created:
        print(f"Created doctor: {doctor.username}")
    else:
        print(f"Doctor already exists: {doctor.username}")
    
    # Create a test patient
    patient, created = Patient.objects.get_or_create(
        patient_id='PAT001',
        defaults={
            'full_name': 'Alice Johnson',
            'gender': 'Female',
            'doctor': doctor
        }
    )
    if created:
        print(f"Created patient: {patient.patient_id}")
    else:
        print(f"Patient already exists: {patient.patient_id}")
    
    # Set patient password
    patient.password = make_password('patient123')
    patient.save()
    print(f"Set password for patient: {patient.patient_id}")
    
    # Create test chapters and words
    chapters_data = [
        {
            'chapter_number': 1,
            'name': 'Basic Sounds',
            'words': ['hello', 'world', 'apple', 'banana', 'cat']
        },
        {
            'chapter_number': 2,
            'name': 'Common Words',
            'words': ['water', 'food', 'house', 'family', 'friend']
        },
        {
            'chapter_number': 3,
            'name': 'Daily Activities',
            'words': ['eat', 'sleep', 'walk', 'read', 'write']
        }
    ]
    
    for chapter_data in chapters_data:
        chapter, created = Chapter.objects.get_or_create(
            chapter_number=chapter_data['chapter_number'],
            defaults={'name': chapter_data['name']}
        )
        if created:
            print(f"Created chapter: {chapter.name}")
        else:
            print(f"Chapter already exists: {chapter.name}")
        
        # Create words for this chapter
        for i, word_text in enumerate(chapter_data['words'], 1):
            word, created = Word.objects.get_or_create(
                chapter=chapter,
                order=i,
                defaults={'word': word_text}
            )
            if created:
                print(f"  Created word: {word.word}")
    
    print("\nTest data creation completed!")
    print(f"Test patient login: PAT001 / patient123")
    print(f"Test doctor login: doctor1 / doctor123")

if __name__ == '__main__':
    create_test_data()
