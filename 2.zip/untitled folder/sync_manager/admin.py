# sync_manager/admin.py
from django.contrib import admin
from .models import SyncStatus, DataSync, DoctorFeedback, RealTimeUpdate

@admin.register(SyncStatus)
class SyncStatusAdmin(admin.ModelAdmin):
    list_display = ['sync_id', 'sync_type', 'patient', 'status', 'source_backend', 'target_backend', 'created_at', 'synced_at']
    list_filter = ['sync_type', 'status', 'source_backend', 'target_backend', 'created_at']
    search_fields = ['sync_id', 'patient__patient_id', 'patient__full_name']
    readonly_fields = ['sync_id', 'created_at', 'synced_at']
    ordering = ['-created_at']

@admin.register(DataSync)
class DataSyncAdmin(admin.ModelAdmin):
    list_display = ['id', 'sync_status', 'checksum', 'created_at']
    list_filter = ['created_at']
    search_fields = ['sync_status__sync_id', 'checksum']
    readonly_fields = ['checksum', 'created_at']
    ordering = ['-created_at']

@admin.register(DoctorFeedback)
class DoctorFeedbackAdmin(admin.ModelAdmin):
    list_display = ['feedback_id', 'patient', 'doctor', 'feedback_type', 'priority', 'title', 'is_read_by_patient', 'created_at']
    list_filter = ['feedback_type', 'priority', 'is_read_by_patient', 'action_required', 'created_at']
    search_fields = ['feedback_id', 'patient__patient_id', 'patient__full_name', 'doctor__username', 'title']
    readonly_fields = ['feedback_id', 'created_at', 'updated_at', 'synced_at']
    ordering = ['-created_at']
    
    fieldsets = (
        ('Basic Information', {
            'fields': ('feedback_id', 'patient', 'doctor', 'feedback_type', 'priority')
        }),
        ('Content', {
            'fields': ('title', 'message', 'action_required', 'due_date')
        }),
        ('Status', {
            'fields': ('is_read_by_patient', 'read_at', 'is_synced_to_mobile', 'synced_at')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        })
    )

@admin.register(RealTimeUpdate)
class RealTimeUpdateAdmin(admin.ModelAdmin):
    list_display = ['update_id', 'patient', 'update_type', 'web_delivered', 'mobile_delivered', 'created_at', 'expires_at']
    list_filter = ['update_type', 'web_delivered', 'mobile_delivered', 'created_at']
    search_fields = ['update_id', 'patient__patient_id', 'patient__full_name']
    readonly_fields = ['update_id', 'created_at', 'web_delivered_at', 'mobile_delivered_at', 'is_fully_delivered']
    ordering = ['-created_at']
    
    fieldsets = (
        ('Basic Information', {
            'fields': ('update_id', 'patient', 'update_type', 'data')
        }),
        ('Target Clients', {
            'fields': ('notify_web', 'notify_mobile')
        }),
        ('Delivery Status', {
            'fields': ('web_delivered', 'web_delivered_at', 'mobile_delivered', 'mobile_delivered_at', 'is_fully_delivered')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'expires_at')
        })
    )
