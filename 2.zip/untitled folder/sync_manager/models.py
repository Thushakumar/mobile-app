# sync_manager/models.py
from django.db import models
from django.contrib.contenttypes.models import ContentType
from django.contrib.contenttypes.fields import GenericForeignKey
from patients.models import Patient
import uuid

class SyncStatus(models.Model):
    """Track synchronization status between mobile and web backends"""
    SYNC_TYPES = [
        ('progress', 'Progress Data'),
        ('session', 'Session History'),
        ('ml_results', 'ML Analysis Results'),
        ('feedback', 'Doctor Feedback'),
    ]
    
    STATUS_CHOICES = [
        ('pending', 'Pending Sync'),
        ('syncing', 'Syncing'),
        ('completed', 'Completed'),
        ('failed', 'Failed'),
    ]
    
    sync_id = models.UUIDField(default=uuid.uuid4, unique=True)
    sync_type = models.CharField(max_length=20, choices=SYNC_TYPES)
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE, related_name='sync_status')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    source_backend = models.CharField(max_length=20, choices=[('web', 'Web'), ('mobile', 'Mobile')])
    target_backend = models.CharField(max_length=20, choices=[('web', 'Web'), ('mobile', 'Mobile')])
    
    # Generic relation to any model
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    object_id = models.PositiveIntegerField()
    content_object = GenericForeignKey('content_type', 'object_id')
    
    created_at = models.DateTimeField(auto_now_add=True)
    synced_at = models.DateTimeField(null=True, blank=True)
    error_message = models.TextField(blank=True)
    retry_count = models.IntegerField(default=0)
    
    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['patient', 'sync_type', 'status']),
            models.Index(fields=['created_at']),
        ]
    
    def __str__(self):
        return f"Sync {self.sync_type} - {self.patient.patient_id} - {self.status}"

class DataSync(models.Model):
    """Store synchronized data for conflict resolution"""
    sync_status = models.ForeignKey(SyncStatus, on_delete=models.CASCADE, related_name='data_sync')
    original_data = models.JSONField()  # Original data from source
    transformed_data = models.JSONField()  # Transformed data for target
    checksum = models.CharField(max_length=64)  # For data integrity
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"DataSync - {self.sync_status.sync_id}"

class DoctorFeedback(models.Model):
    """Doctor feedback for patients that needs to be synced"""
    FEEDBACK_TYPES = [
        ('progress', 'Progress Comment'),
        ('recommendation', 'Exercise Recommendation'),
        ('goal', 'Goal Setting'),
        ('note', 'General Note'),
    ]
    
    PRIORITY_LEVELS = [
        ('low', 'Low Priority'),
        ('medium', 'Medium Priority'),
        ('high', 'High Priority'),
        ('urgent', 'Urgent'),
    ]
    
    feedback_id = models.UUIDField(default=uuid.uuid4, unique=True)
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE, related_name='doctor_feedback')
    doctor = models.ForeignKey('users.User', on_delete=models.CASCADE, related_name='given_feedback')
    feedback_type = models.CharField(max_length=20, choices=FEEDBACK_TYPES)
    priority = models.CharField(max_length=20, choices=PRIORITY_LEVELS, default='medium')
    title = models.CharField(max_length=200)
    message = models.TextField()
    action_required = models.BooleanField(default=False)
    due_date = models.DateField(null=True, blank=True)
    
    # Metadata
    is_read_by_patient = models.BooleanField(default=False)
    read_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    # Sync tracking
    is_synced_to_mobile = models.BooleanField(default=False)
    synced_at = models.DateTimeField(null=True, blank=True)
    
    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['patient', 'is_read_by_patient']),
            models.Index(fields=['doctor', 'feedback_type']),
            models.Index(fields=['created_at']),
        ]
    
    def __str__(self):
        return f"Feedback: {self.title} - {self.patient.patient_id}"

class RealTimeUpdate(models.Model):
    """Track real-time updates that need to be pushed to clients"""
    UPDATE_TYPES = [
        ('progress_update', 'Progress Update'),
        ('session_complete', 'Session Completed'),
        ('ml_result', 'ML Analysis Result'),
        ('feedback_new', 'New Feedback'),
        ('feedback_read', 'Feedback Read'),
        ('sync_status', 'Sync Status Change'),
    ]
    
    update_id = models.UUIDField(default=uuid.uuid4, unique=True)
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE, related_name='realtime_updates')
    update_type = models.CharField(max_length=30, choices=UPDATE_TYPES)
    data = models.JSONField()  # Update payload
    
    # Target clients
    notify_web = models.BooleanField(default=True)
    notify_mobile = models.BooleanField(default=True)
    
    # Delivery status
    web_delivered = models.BooleanField(default=False)
    web_delivered_at = models.DateTimeField(null=True, blank=True)
    mobile_delivered = models.BooleanField(default=False)
    mobile_delivered_at = models.DateTimeField(null=True, blank=True)
    
    created_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField()  # Updates expire after some time
    
    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['patient', 'update_type']),
            models.Index(fields=['created_at', 'expires_at']),
        ]
    
    def __str__(self):
        return f"Update: {self.update_type} - {self.patient.patient_id}"
    
    @property
    def is_fully_delivered(self):
        """Check if update has been delivered to all required targets"""
        web_ok = not self.notify_web or self.web_delivered
        mobile_ok = not self.notify_mobile or self.mobile_delivered
        return web_ok and mobile_ok
