# sync_manager/services.py
import requests
import json
import hashlib
import logging
from typing import Dict, Any, Optional, List
from django.conf import settings
from django.utils import timezone
from django.db import transaction
from django.core.serializers import serialize
from rest_framework import serializers

from .models import SyncStatus, DataSync, DoctorFeedback, RealTimeUpdate
from patients.models import Patient
from progress.models import Progress, SessionHistory
from mobile_therapy.models import MobileProgress, MobileSessionHistory, TherapySession

logger = logging.getLogger(__name__)

class SyncService:
    """Main synchronization service for data sync between backends"""
    
    def __init__(self):
        self.web_backend_url = getattr(settings, 'WEB_BACKEND_URL', 'http://localhost:8000')
        self.mobile_backend_url = getattr(settings, 'MOBILE_BACKEND_URL', 'http://localhost:8001')
        self.sync_timeout = getattr(settings, 'SYNC_TIMEOUT', 30)
    
    def create_checksum(self, data: Dict[str, Any]) -> str:
        """Create checksum for data integrity"""
        data_str = json.dumps(data, sort_keys=True, default=str)
        return hashlib.sha256(data_str.encode()).hexdigest()
    
    def sync_progress_to_web(self, patient_id: str, mobile_progress_id: int):
        """Sync mobile progress data to web backend"""
        try:
            patient = Patient.objects.get(patient_id=patient_id)
            mobile_progress = MobileProgress.objects.get(id=mobile_progress_id, patient=patient)
            
            # Create sync status
            sync_status = SyncStatus.objects.create(
                sync_type='progress',
                patient=patient,
                source_backend='mobile',
                target_backend='web',
                content_object=mobile_progress
            )
            
            # Prepare data for web backend format
            sync_data = {
                'patient_id': patient.patient_id,
                'word_id': mobile_progress.word.id,
                'chapter_id': mobile_progress.chapter.id,
                'trial_number': mobile_progress.attempts,
                'accuracy': mobile_progress.best_score,
                'date': mobile_progress.last_attempt_date.date().isoformat(),
                'time': mobile_progress.last_attempt_date.time().isoformat(),
                'source': 'mobile_app'
            }
            
            # Create DataSync record
            DataSync.objects.create(
                sync_status=sync_status,
                original_data=self._serialize_mobile_progress(mobile_progress),
                transformed_data=sync_data,
                checksum=self.create_checksum(sync_data)
            )
            
            # Send to web backend
            success = self._send_to_web_backend('/api/progress/sync/', sync_data)
            
            if success:
                sync_status.status = 'completed'
                sync_status.synced_at = timezone.now()
                self._create_realtime_update(patient, 'progress_update', sync_data)
            else:
                sync_status.status = 'failed'
                sync_status.error_message = 'Failed to sync to web backend'
                sync_status.retry_count += 1
            
            sync_status.save()
            return success
            
        except Exception as e:
            logger.error(f"Error syncing progress to web: {str(e)}")
            if 'sync_status' in locals():
                sync_status.status = 'failed'
                sync_status.error_message = str(e)
                sync_status.save()
            return False
    
    def sync_session_to_web(self, patient_id: str, session_id: int):
        """Sync mobile session history to web backend"""
        try:
            patient = Patient.objects.get(patient_id=patient_id)
            mobile_session = MobileSessionHistory.objects.get(id=session_id)
            
            # Create sync status
            sync_status = SyncStatus.objects.create(
                sync_type='session',
                patient=patient,
                source_backend='mobile',
                target_backend='web',
                content_object=mobile_session
            )
            
            # Prepare data for web backend format
            sync_data = {
                'patient_id': patient.patient_id,
                'date': mobile_session.created_at.date().isoformat(),
                'duration': str(mobile_session.total_time_spent) if mobile_session.total_time_spent else '00:00:00',
                'score': mobile_session.average_accuracy,
                'words_completed': mobile_session.words_completed,
                'notes': mobile_session.notes,
                'source': 'mobile_app'
            }
            
            # Create DataSync record
            DataSync.objects.create(
                sync_status=sync_status,
                original_data=self._serialize_mobile_session(mobile_session),
                transformed_data=sync_data,
                checksum=self.create_checksum(sync_data)
            )
            
            # Send to web backend
            success = self._send_to_web_backend('/api/progress/session-history/sync/', sync_data)
            
            if success:
                sync_status.status = 'completed'
                sync_status.synced_at = timezone.now()
                self._create_realtime_update(patient, 'session_complete', sync_data)
            else:
                sync_status.status = 'failed'
                sync_status.error_message = 'Failed to sync to web backend'
                sync_status.retry_count += 1
            
            sync_status.save()
            return success
            
        except Exception as e:
            logger.error(f"Error syncing session to web: {str(e)}")
            if 'sync_status' in locals():
                sync_status.status = 'failed'
                sync_status.error_message = str(e)
                sync_status.save()
            return False
    
    def sync_feedback_to_mobile(self, feedback_id: str):
        """Sync doctor feedback from web to mobile"""
        try:
            feedback = DoctorFeedback.objects.get(feedback_id=feedback_id)
            
            # Create sync status
            sync_status = SyncStatus.objects.create(
                sync_type='feedback',
                patient=feedback.patient,
                source_backend='web',
                target_backend='mobile',
                content_object=feedback
            )
            
            # Prepare data for mobile format
            sync_data = {
                'feedback_id': str(feedback.feedback_id),
                'patient_id': feedback.patient.patient_id,
                'doctor_name': feedback.doctor.get_full_name(),
                'doctor_email': feedback.doctor.email,
                'feedback_type': feedback.feedback_type,
                'priority': feedback.priority,
                'title': feedback.title,
                'message': feedback.message,
                'action_required': feedback.action_required,
                'due_date': feedback.due_date.isoformat() if feedback.due_date else None,
                'created_at': feedback.created_at.isoformat(),
                'is_read': feedback.is_read_by_patient
            }
            
            # Create DataSync record
            DataSync.objects.create(
                sync_status=sync_status,
                original_data=self._serialize_feedback(feedback),
                transformed_data=sync_data,
                checksum=self.create_checksum(sync_data)
            )
            
            # Mark as synced (since we're the mobile backend, we don't need to send it anywhere)
            sync_status.status = 'completed'
            sync_status.synced_at = timezone.now()
            sync_status.save()
            
            feedback.is_synced_to_mobile = True
            feedback.synced_at = timezone.now()
            feedback.save()
            
            # Create real-time update
            self._create_realtime_update(feedback.patient, 'feedback_new', sync_data)
            
            return True
            
        except Exception as e:
            logger.error(f"Error syncing feedback to mobile: {str(e)}")
            if 'sync_status' in locals():
                sync_status.status = 'failed'
                sync_status.error_message = str(e)
                sync_status.save()
            return False
    
    def sync_ml_results(self, patient_id: str, video_submission_id: int, ml_results: Dict[str, Any]):
        """Sync ML analysis results to web backend"""
        try:
            patient = Patient.objects.get(patient_id=patient_id)
            
            # Create sync status
            sync_status = SyncStatus.objects.create(
                sync_type='ml_results',
                patient=patient,
                source_backend='mobile',
                target_backend='web',
                object_id=video_submission_id,
                content_type_id=1  # VideoSubmission content type
            )
            
            # Prepare data for web backend
            sync_data = {
                'patient_id': patient.patient_id,
                'video_submission_id': video_submission_id,
                'ml_results': ml_results,
                'analysis_date': timezone.now().isoformat(),
                'source': 'mobile_ml_analysis'
            }
            
            # Create DataSync record
            DataSync.objects.create(
                sync_status=sync_status,
                original_data={'ml_results': ml_results},
                transformed_data=sync_data,
                checksum=self.create_checksum(sync_data)
            )
            
            # Send to web backend
            success = self._send_to_web_backend('/api/ml/results/sync/', sync_data)
            
            if success:
                sync_status.status = 'completed'
                sync_status.synced_at = timezone.now()
                self._create_realtime_update(patient, 'ml_result', sync_data)
            else:
                sync_status.status = 'failed'
                sync_status.error_message = 'Failed to sync ML results to web backend'
                sync_status.retry_count += 1
            
            sync_status.save()
            return success
            
        except Exception as e:
            logger.error(f"Error syncing ML results: {str(e)}")
            if 'sync_status' in locals():
                sync_status.status = 'failed'
                sync_status.error_message = str(e)
                sync_status.save()
            return False
    
    def retry_failed_syncs(self, max_retries: int = 3):
        """Retry failed synchronizations"""
        failed_syncs = SyncStatus.objects.filter(
            status='failed',
            retry_count__lt=max_retries
        ).order_by('created_at')
        
        results = {'success': 0, 'failed': 0}
        
        for sync_status in failed_syncs:
            try:
                success = False
                
                if sync_status.sync_type == 'progress':
                    success = self.sync_progress_to_web(
                        sync_status.patient.patient_id,
                        sync_status.object_id
                    )
                elif sync_status.sync_type == 'session':
                    success = self.sync_session_to_web(
                        sync_status.patient.patient_id,
                        sync_status.object_id
                    )
                elif sync_status.sync_type == 'feedback':
                    success = self.sync_feedback_to_mobile(str(sync_status.content_object.feedback_id))
                
                if success:
                    results['success'] += 1
                else:
                    results['failed'] += 1
                    
            except Exception as e:
                logger.error(f"Error retrying sync {sync_status.id}: {str(e)}")
                results['failed'] += 1
        
        return results
    
    def get_sync_status(self, patient_id: str, sync_type: Optional[str] = None) -> List[Dict]:
        """Get synchronization status for a patient"""
        patient = Patient.objects.get(patient_id=patient_id)
        query = SyncStatus.objects.filter(patient=patient)
        
        if sync_type:
            query = query.filter(sync_type=sync_type)
        
        return [
            {
                'sync_id': str(status.sync_id),
                'sync_type': status.sync_type,
                'status': status.status,
                'source_backend': status.source_backend,
                'target_backend': status.target_backend,
                'created_at': status.created_at.isoformat(),
                'synced_at': status.synced_at.isoformat() if status.synced_at else None,
                'error_message': status.error_message,
                'retry_count': status.retry_count
            }
            for status in query[:50]  # Limit to last 50 syncs
        ]
    
    def _send_to_web_backend(self, endpoint: str, data: Dict[str, Any]) -> bool:
        """Send data to web backend"""
        try:
            url = f"{self.web_backend_url}{endpoint}"
            response = requests.post(
                url,
                json=data,
                timeout=self.sync_timeout,
                headers={'Content-Type': 'application/json'}
            )
            return response.status_code in [200, 201]
        except Exception as e:
            logger.error(f"Error sending to web backend: {str(e)}")
            return False
    
    def _create_realtime_update(self, patient: Patient, update_type: str, data: Dict[str, Any]):
        """Create real-time update notification"""
        expires_at = timezone.now() + timezone.timedelta(hours=24)  # Updates expire in 24 hours
        
        RealTimeUpdate.objects.create(
            patient=patient,
            update_type=update_type,
            data=data,
            expires_at=expires_at
        )
    
    def _serialize_mobile_progress(self, progress: MobileProgress) -> Dict[str, Any]:
        """Serialize mobile progress for sync"""
        return {
            'id': progress.id,
            'patient_id': progress.patient.patient_id,
            'chapter_id': progress.chapter.id,
            'word_id': progress.word.id,
            'attempts': progress.attempts,
            'best_score': progress.best_score,
            'last_attempt_date': progress.last_attempt_date.isoformat()
        }
    
    def _serialize_mobile_session(self, session: MobileSessionHistory) -> Dict[str, Any]:
        """Serialize mobile session for sync"""
        return {
            'id': session.id,
            'session_id': session.session.id,
            'patient_id': session.session.patient.patient_id,
            'total_time_spent': str(session.total_time_spent) if session.total_time_spent else None,
            'words_completed': session.words_completed,
            'average_accuracy': session.average_accuracy,
            'notes': session.notes,
            'created_at': session.created_at.isoformat()
        }
    
    def _serialize_feedback(self, feedback: DoctorFeedback) -> Dict[str, Any]:
        """Serialize feedback for sync"""
        return {
            'feedback_id': str(feedback.feedback_id),
            'patient_id': feedback.patient.patient_id,
            'doctor_id': feedback.doctor.id,
            'feedback_type': feedback.feedback_type,
            'priority': feedback.priority,
            'title': feedback.title,
            'message': feedback.message,
            'action_required': feedback.action_required,
            'due_date': feedback.due_date.isoformat() if feedback.due_date else None,
            'is_read_by_patient': feedback.is_read_by_patient,
            'read_at': feedback.read_at.isoformat() if feedback.read_at else None,
            'created_at': feedback.created_at.isoformat(),
            'updated_at': feedback.updated_at.isoformat()
        }

# Global sync service instance
sync_service = SyncService()
