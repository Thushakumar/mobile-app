# sync_manager/views.py
from rest_framework import generics, status, permissions
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from rest_framework.views import APIView
from django.shortcuts import get_object_or_404
from django.utils import timezone
from django.db import transaction
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync
import logging

from .models import SyncStatus, DataSync, DoctorFeedback, RealTimeUpdate
from .serializers import (
    SyncStatusSerializer, DataSyncSerializer, DoctorFeedbackSerializer,
    DoctorFeedbackCreateSerializer, RealTimeUpdateSerializer,
    FeedbackReadUpdateSerializer, SyncTriggerSerializer
)
from .services import sync_service
from .visualization import visualization_service
from patients.models import Patient
from mobile_therapy.authentication import PatientJWTAuthentication, PatientOrUserAuthenticated

logger = logging.getLogger(__name__)
channel_layer = get_channel_layer()

class SyncStatusListView(generics.ListAPIView):
    """List synchronization status for a patient"""
    serializer_class = SyncStatusSerializer
    authentication_classes = [PatientJWTAuthentication]
    permission_classes = [PatientOrUserAuthenticated]
    
    def get_queryset(self):
        patient_id = self.request.query_params.get('patient_id')
        sync_type = self.request.query_params.get('sync_type')
        
        queryset = SyncStatus.objects.all()
        
        if patient_id:
            queryset = queryset.filter(patient__patient_id=patient_id)
        
        if sync_type:
            queryset = queryset.filter(sync_type=sync_type)
        
        return queryset.order_by('-created_at')[:50]

class DoctorFeedbackListView(generics.ListCreateAPIView):
    """List and create doctor feedback"""
    authentication_classes = [PatientJWTAuthentication]
    permission_classes = [PatientOrUserAuthenticated]
    
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return DoctorFeedbackCreateSerializer
        return DoctorFeedbackSerializer
    
    def get_queryset(self):
        patient_id = self.request.query_params.get('patient_id')
        feedback_type = self.request.query_params.get('type')
        unread_only = self.request.query_params.get('unread_only', 'false').lower() == 'true'
        
        queryset = DoctorFeedback.objects.all()
        
        if patient_id:
            queryset = queryset.filter(patient__patient_id=patient_id)
        
        if feedback_type:
            queryset = queryset.filter(feedback_type=feedback_type)
        
        if unread_only:
            queryset = queryset.filter(is_read_by_patient=False)
        
        return queryset.order_by('-created_at')
    
    def perform_create(self, serializer):
        # Set doctor from request user (if authenticated as doctor)
        if hasattr(self.request.user, 'id') and not self.request.user.is_anonymous:
            serializer.save(doctor=self.request.user)
        else:
            # If authenticated as patient, we shouldn't allow creating feedback
            raise permissions.PermissionDenied("Only doctors can create feedback")

class DoctorFeedbackDetailView(generics.RetrieveUpdateDestroyAPIView):
    """Retrieve, update, or delete doctor feedback"""
    serializer_class = DoctorFeedbackSerializer
    authentication_classes = [PatientJWTAuthentication]
    permission_classes = [PatientOrUserAuthenticated]
    lookup_field = 'feedback_id'
    
    def get_queryset(self):
        return DoctorFeedback.objects.all()

class RealTimeUpdateListView(generics.ListAPIView):
    """List real-time updates for a patient"""
    serializer_class = RealTimeUpdateSerializer
    authentication_classes = [PatientJWTAuthentication]
    permission_classes = [PatientOrUserAuthenticated]
    
    def get_queryset(self):
        patient_id = self.request.query_params.get('patient_id')
        client_type = self.request.query_params.get('client_type', 'mobile')
        
        if not patient_id:
            return RealTimeUpdate.objects.none()
        
        queryset = RealTimeUpdate.objects.filter(
            patient__patient_id=patient_id,
            expires_at__gt=timezone.now()
        )
        
        # Filter by delivery status based on client type
        if client_type == 'web':
            queryset = queryset.filter(notify_web=True)
        else:  # mobile
            queryset = queryset.filter(notify_mobile=True)
        
        return queryset.order_by('-created_at')[:50]

class SyncTriggerView(APIView):
    """Manually trigger synchronization"""
    authentication_classes = [PatientJWTAuthentication]
    permission_classes = [PatientOrUserAuthenticated]
    
    def post(self, request):
        serializer = SyncTriggerSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        data = serializer.validated_data
        sync_type = data['sync_type']
        patient_id = data['patient_id']
        object_id = data.get('object_id')
        force_resync = data.get('force_resync', False)
        
        try:
            # Verify patient exists
            patient = get_object_or_404(Patient, patient_id=patient_id)
            
            # Check if sync already in progress
            if not force_resync:
                existing_sync = SyncStatus.objects.filter(
                    patient=patient,
                    sync_type=sync_type,
                    status__in=['pending', 'syncing']
                ).first()
                
                if existing_sync:
                    return Response(
                        {'error': 'Sync already in progress', 'sync_id': str(existing_sync.sync_id)},
                        status=status.HTTP_409_CONFLICT
                    )
            
            # Trigger sync based on type
            success = False
            sync_id = None
            
            if sync_type == 'progress' and object_id:
                success = sync_service.sync_progress_to_web(patient_id, object_id)
            elif sync_type == 'session' and object_id:
                success = sync_service.sync_session_to_web(patient_id, object_id)
            elif sync_type == 'feedback' and object_id:
                feedback = get_object_or_404(DoctorFeedback, id=object_id)
                success = sync_service.sync_feedback_to_mobile(str(feedback.feedback_id))
            else:
                return Response(
                    {'error': 'Invalid sync type or missing object_id'},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            if success:
                # Get the latest sync status
                latest_sync = SyncStatus.objects.filter(
                    patient=patient,
                    sync_type=sync_type
                ).order_by('-created_at').first()
                
                return Response({
                    'success': True,
                    'message': f'{sync_type} sync completed successfully',
                    'sync_id': str(latest_sync.sync_id) if latest_sync else None
                })
            else:
                return Response(
                    {'error': f'Failed to sync {sync_type}'},
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR
                )
        
        except Exception as e:
            logger.error(f"Error triggering sync: {str(e)}")
            return Response(
                {'error': str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

class FeedbackReadView(APIView):
    """Mark feedback as read by patient"""
    authentication_classes = [PatientJWTAuthentication]
    permission_classes = [PatientOrUserAuthenticated]
    
    def post(self, request):
        serializer = FeedbackReadUpdateSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        data = serializer.validated_data
        feedback_id = data['feedback_id']
        read_at = data.get('read_at', timezone.now())
        
        try:
            feedback = get_object_or_404(DoctorFeedback, feedback_id=feedback_id)
            
            with transaction.atomic():
                feedback.is_read_by_patient = True
                feedback.read_at = read_at
                feedback.save()
                
                # Create real-time update for doctor
                self._create_feedback_read_notification(feedback)
            
            return Response({
                'success': True,
                'message': 'Feedback marked as read',
                'read_at': read_at.isoformat()
            })
        
        except Exception as e:
            logger.error(f"Error marking feedback as read: {str(e)}")
            return Response(
                {'error': str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
    
    def _create_feedback_read_notification(self, feedback):
        """Create notification for doctor when patient reads feedback"""
        update_data = {
            'feedback_id': str(feedback.feedback_id),
            'patient_id': feedback.patient.patient_id,
            'patient_name': feedback.patient.full_name,
            'feedback_title': feedback.title,
            'read_at': feedback.read_at.isoformat()
        }
        
        RealTimeUpdate.objects.create(
            patient=feedback.patient,
            update_type='feedback_read',
            data=update_data,
            notify_web=True,
            notify_mobile=False,  # Don't notify mobile (patient already read it there)
            expires_at=timezone.now() + timezone.timedelta(hours=48)
        )
        
        # Send WebSocket notification to doctor
        if channel_layer:
            async_to_sync(channel_layer.group_send)(
                f'user_{feedback.doctor.id}_notifications',
                {
                    'type': 'send_notification',
                    'data': {
                        'type': 'feedback_read',
                        'message': f'Patient {feedback.patient.full_name} read your feedback: {feedback.title}',
                        'data': update_data,
                        'timestamp': timezone.now().isoformat()
                    }
                }
            )

@api_view(['GET'])
@permission_classes([PatientOrUserAuthenticated])
def sync_stats(request):
    """Get synchronization statistics"""
    patient_id = request.GET.get('patient_id')
    
    if patient_id:
        patient = get_object_or_404(Patient, patient_id=patient_id)
        base_query = SyncStatus.objects.filter(patient=patient)
    else:
        base_query = SyncStatus.objects.all()
    
    # Get stats for last 30 days
    thirty_days_ago = timezone.now() - timezone.timedelta(days=30)
    recent_query = base_query.filter(created_at__gte=thirty_days_ago)
    
    stats = {
        'total_syncs': base_query.count(),
        'recent_syncs': recent_query.count(),
        'completed_syncs': recent_query.filter(status='completed').count(),
        'failed_syncs': recent_query.filter(status='failed').count(),
        'pending_syncs': recent_query.filter(status='pending').count(),
        'sync_types': {
            'progress': recent_query.filter(sync_type='progress').count(),
            'session': recent_query.filter(sync_type='session').count(),
            'ml_results': recent_query.filter(sync_type='ml_results').count(),
            'feedback': recent_query.filter(sync_type='feedback').count(),
        }
    }
    
    # Calculate success rate
    total_recent = stats['recent_syncs']
    if total_recent > 0:
        stats['success_rate'] = (stats['completed_syncs'] / total_recent) * 100
    else:
        stats['success_rate'] = 0.0
    
    return Response(stats)

@api_view(['POST'])
@permission_classes([PatientOrUserAuthenticated])
def retry_failed_syncs(request):
    """Retry failed synchronizations"""
    max_retries = int(request.data.get('max_retries', 3))
    
    try:
        results = sync_service.retry_failed_syncs(max_retries)
        
        return Response({
            'success': True,
            'message': 'Failed syncs retry completed',
            'results': results
        })
    
    except Exception as e:
        logger.error(f"Error retrying failed syncs: {str(e)}")
        return Response(
            {'error': str(e)},
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

@api_view(['POST'])
@permission_classes([PatientOrUserAuthenticated])
def mark_update_delivered(request):
    """Mark real-time update as delivered"""
    update_id = request.data.get('update_id')
    client_type = request.data.get('client_type', 'mobile')
    
    if not update_id:
        return Response(
            {'error': 'update_id is required'},
            status=status.HTTP_400_BAD_REQUEST
        )
    
    try:
        update = get_object_or_404(RealTimeUpdate, update_id=update_id)
        now = timezone.now()
        
        if client_type == 'web':
            update.web_delivered = True
            update.web_delivered_at = now
        else:  # mobile
            update.mobile_delivered = True
            update.mobile_delivered_at = now
        
        update.save()
        
        return Response({
            'success': True,
            'message': 'Update marked as delivered',
            'delivered_at': now.isoformat()
        })
    
    except Exception as e:
        logger.error(f"Error marking update as delivered: {str(e)}")
        return Response(
            {'error': str(e)},
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

# Visualization Views

class ProgressVisualizationView(APIView):
    """Get progress visualization data"""
    authentication_classes = [PatientJWTAuthentication]
    permission_classes = [PatientOrUserAuthenticated]
    
    def get(self, request):
        patient_id = request.query_params.get('patient_id')
        timeframe = request.query_params.get('timeframe', '30d')
        
        if not patient_id:
            return Response(
                {'error': 'patient_id is required'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            data = visualization_service.get_progress_chart_data(patient_id, timeframe)
            
            if 'error' in data:
                return Response(data, status=status.HTTP_404_NOT_FOUND)
            
            return Response(data)
        
        except Exception as e:
            logger.error(f"Error generating progress visualization: {str(e)}")
            return Response(
                {'error': str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

class PhonemeAnalysisView(APIView):
    """Get phoneme analysis visualization"""
    authentication_classes = [PatientJWTAuthentication]
    permission_classes = [PatientOrUserAuthenticated]
    
    def get(self, request):
        patient_id = request.query_params.get('patient_id')
        
        if not patient_id:
            return Response(
                {'error': 'patient_id is required'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            data = visualization_service.get_phoneme_analysis_chart(patient_id)
            
            if 'error' in data:
                return Response(data, status=status.HTTP_404_NOT_FOUND)
            
            return Response(data)
        
        except Exception as e:
            logger.error(f"Error generating phoneme analysis: {str(e)}")
            return Response(
                {'error': str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

class SessionComparisonView(APIView):
    """Get session comparison visualization"""
    authentication_classes = [PatientJWTAuthentication]
    permission_classes = [PatientOrUserAuthenticated]
    
    def get(self, request):
        patient_id = request.query_params.get('patient_id')
        limit = int(request.query_params.get('limit', 10))
        
        if not patient_id:
            return Response(
                {'error': 'patient_id is required'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            data = visualization_service.get_session_comparison_chart(patient_id, limit)
            
            if 'error' in data:
                return Response(data, status=status.HTTP_404_NOT_FOUND)
            
            return Response(data)
        
        except Exception as e:
            logger.error(f"Error generating session comparison: {str(e)}")
            return Response(
                {'error': str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

class MLAnalysisVisualizationView(APIView):
    """Get ML analysis visualization"""
    authentication_classes = [PatientJWTAuthentication]
    permission_classes = [PatientOrUserAuthenticated]
    
    def get(self, request):
        patient_id = request.query_params.get('patient_id')
        limit = int(request.query_params.get('limit', 20))
        
        if not patient_id:
            return Response(
                {'error': 'patient_id is required'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            data = visualization_service.get_ml_analysis_visualization(patient_id, limit)
            
            if 'error' in data:
                return Response(data, status=status.HTTP_404_NOT_FOUND)
            
            return Response(data)
        
        except Exception as e:
            logger.error(f"Error generating ML analysis visualization: {str(e)}")
            return Response(
                {'error': str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

class ComprehensiveDashboardView(APIView):
    """Get comprehensive dashboard data"""
    authentication_classes = [PatientJWTAuthentication]
    permission_classes = [PatientOrUserAuthenticated]
    
    def get(self, request):
        patient_id = request.query_params.get('patient_id')
        
        if not patient_id:
            return Response(
                {'error': 'patient_id is required'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            data = visualization_service.get_comprehensive_dashboard_data(patient_id)
            return Response(data)
        
        except Exception as e:
            logger.error(f"Error generating comprehensive dashboard: {str(e)}")
            return Response(
                {'error': str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
