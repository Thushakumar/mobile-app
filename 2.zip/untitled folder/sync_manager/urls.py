# sync_manager/urls.py
from django.urls import path
from . import views

urlpatterns = [
    # Sync status endpoints
    path('status/', views.SyncStatusListView.as_view(), name='sync-status-list'),
    path('trigger/', views.SyncTriggerView.as_view(), name='sync-trigger'),
    path('stats/', views.sync_stats, name='sync-stats'),
    path('retry-failed/', views.retry_failed_syncs, name='retry-failed-syncs'),
    
    # Doctor feedback endpoints
    path('feedback/', views.DoctorFeedbackListView.as_view(), name='feedback-list'),
    path('feedback/<uuid:feedback_id>/', views.DoctorFeedbackDetailView.as_view(), name='feedback-detail'),
    path('feedback/mark-read/', views.FeedbackReadView.as_view(), name='feedback-mark-read'),
    
    # Real-time update endpoints
    path('updates/', views.RealTimeUpdateListView.as_view(), name='realtime-updates-list'),
    path('updates/mark-delivered/', views.mark_update_delivered, name='mark-update-delivered'),
    
    # Visualization endpoints
    path('visualization/progress/', views.ProgressVisualizationView.as_view(), name='visualization-progress'),
    path('visualization/phonemes/', views.PhonemeAnalysisView.as_view(), name='visualization-phonemes'),
    path('visualization/sessions/', views.SessionComparisonView.as_view(), name='visualization-sessions'),
    path('visualization/ml-analysis/', views.MLAnalysisVisualizationView.as_view(), name='visualization-ml-analysis'),
    path('visualization/dashboard/', views.ComprehensiveDashboardView.as_view(), name='visualization-dashboard'),
]
