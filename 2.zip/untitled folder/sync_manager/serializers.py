# sync_manager/serializers.py
from rest_framework import serializers
from .models import SyncStatus, DataSync, DoctorFeedback, RealTimeUpdate
from patients.serializers import PatientSerializer

class SyncStatusSerializer(serializers.ModelSerializer):
    patient_detail = PatientSerializer(source='patient', read_only=True)
    
    class Meta:
        model = SyncStatus
        fields = [
            'sync_id', 'sync_type', 'patient', 'patient_detail', 'status',
            'source_backend', 'target_backend', 'created_at', 'synced_at',
            'error_message', 'retry_count'
        ]
        read_only_fields = ['sync_id', 'created_at', 'synced_at']

class DataSyncSerializer(serializers.ModelSerializer):
    sync_status_detail = SyncStatusSerializer(source='sync_status', read_only=True)
    
    class Meta:
        model = DataSync
        fields = [
            'id', 'sync_status', 'sync_status_detail', 'original_data',
            'transformed_data', 'checksum', 'created_at'
        ]
        read_only_fields = ['created_at', 'checksum']

class DoctorFeedbackSerializer(serializers.ModelSerializer):
    patient_detail = PatientSerializer(source='patient', read_only=True)
    doctor_name = serializers.CharField(source='doctor.get_full_name', read_only=True)
    doctor_email = serializers.EmailField(source='doctor.email', read_only=True)
    
    class Meta:
        model = DoctorFeedback
        fields = [
            'feedback_id', 'patient', 'patient_detail', 'doctor', 'doctor_name', 'doctor_email',
            'feedback_type', 'priority', 'title', 'message', 'action_required',
            'due_date', 'is_read_by_patient', 'read_at', 'created_at', 'updated_at',
            'is_synced_to_mobile', 'synced_at'
        ]
        read_only_fields = ['feedback_id', 'created_at', 'updated_at', 'synced_at']

class DoctorFeedbackCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = DoctorFeedback
        fields = [
            'patient', 'feedback_type', 'priority', 'title', 'message',
            'action_required', 'due_date'
        ]

class RealTimeUpdateSerializer(serializers.ModelSerializer):
    patient_detail = PatientSerializer(source='patient', read_only=True)
    
    class Meta:
        model = RealTimeUpdate
        fields = [
            'update_id', 'patient', 'patient_detail', 'update_type', 'data',
            'notify_web', 'notify_mobile', 'web_delivered', 'web_delivered_at',
            'mobile_delivered', 'mobile_delivered_at', 'created_at', 'expires_at',
            'is_fully_delivered'
        ]
        read_only_fields = [
            'update_id', 'created_at', 'web_delivered_at', 'mobile_delivered_at',
            'is_fully_delivered'
        ]

class FeedbackReadUpdateSerializer(serializers.Serializer):
    """Serializer for marking feedback as read"""
    feedback_id = serializers.UUIDField()
    read_at = serializers.DateTimeField(required=False)

class SyncTriggerSerializer(serializers.Serializer):
    """Serializer for triggering manual sync"""
    sync_type = serializers.ChoiceField(choices=SyncStatus.SYNC_TYPES)
    patient_id = serializers.CharField()
    object_id = serializers.IntegerField(required=False)
    force_resync = serializers.BooleanField(default=False)
