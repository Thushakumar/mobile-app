# sync_manager/websockets.py
import json
import logging
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async
from django.utils import timezone
from .models import RealTimeUpdate, Patient

logger = logging.getLogger(__name__)

class RealTimeUpdateConsumer(AsyncWebsocketConsumer):
    """WebSocket consumer for real-time updates"""
    
    async def connect(self):
        """Accept WebSocket connection"""
        self.patient_id = self.scope['url_route']['kwargs']['patient_id']
        self.client_type = self.scope['url_route']['kwargs'].get('client_type', 'web')
        self.room_group_name = f'patient_{self.patient_id}_updates'
        
        # Verify patient exists
        patient_exists = await self.verify_patient_exists()
        if not patient_exists:
            await self.close()
            return
        
        # Join room group
        await self.channel_layer.group_add(
            self.room_group_name,
            self.channel_name
        )
        
        await self.accept()
        
        # Send any pending updates
        await self.send_pending_updates()
        
        logger.info(f"WebSocket connected for patient {self.patient_id} ({self.client_type})")
    
    async def disconnect(self, close_code):
        """Leave room group"""
        await self.channel_layer.group_discard(
            self.room_group_name,
            self.channel_name
        )
        
        logger.info(f"WebSocket disconnected for patient {self.patient_id}")
    
    async def receive(self, text_data):
        """Receive message from WebSocket"""
        try:
            data = json.loads(text_data)
            message_type = data.get('type')
            
            if message_type == 'mark_delivered':
                await self.handle_delivery_confirmation(data)
            elif message_type == 'heartbeat':
                await self.send(text_data=json.dumps({
                    'type': 'heartbeat_response',
                    'timestamp': timezone.now().isoformat()
                }))
            elif message_type == 'request_updates':
                await self.send_pending_updates()
            
        except json.JSONDecodeError:
            logger.error(f"Invalid JSON received from WebSocket: {text_data}")
        except Exception as e:
            logger.error(f"Error handling WebSocket message: {str(e)}")
    
    async def send_update(self, event):
        """Send update to WebSocket"""
        await self.send(text_data=json.dumps(event['data']))
    
    async def send_pending_updates(self):
        """Send all pending updates for this patient"""
        updates = await self.get_pending_updates()
        
        for update in updates:
            await self.send(text_data=json.dumps({
                'type': 'realtime_update',
                'update_id': str(update['update_id']),
                'update_type': update['update_type'],
                'data': update['data'],
                'created_at': update['created_at'],
                'patient_id': update['patient_id']
            }))
    
    async def handle_delivery_confirmation(self, data):
        """Handle delivery confirmation from client"""
        update_id = data.get('update_id')
        if update_id:
            await self.mark_update_delivered(update_id)
    
    @database_sync_to_async
    def verify_patient_exists(self):
        """Verify patient exists"""
        try:
            Patient.objects.get(patient_id=self.patient_id)
            return True
        except Patient.DoesNotExist:
            return False
    
    @database_sync_to_async
    def get_pending_updates(self):
        """Get pending updates for patient"""
        now = timezone.now()
        patient = Patient.objects.get(patient_id=self.patient_id)
        
        # Get updates that haven't been delivered to this client type
        if self.client_type == 'web':
            updates = RealTimeUpdate.objects.filter(
                patient=patient,
                notify_web=True,
                web_delivered=False,
                expires_at__gt=now
            ).order_by('-created_at')[:50]
        else:  # mobile
            updates = RealTimeUpdate.objects.filter(
                patient=patient,
                notify_mobile=True,
                mobile_delivered=False,
                expires_at__gt=now
            ).order_by('-created_at')[:50]
        
        return [
            {
                'update_id': str(update.update_id),
                'update_type': update.update_type,
                'data': update.data,
                'created_at': update.created_at.isoformat(),
                'patient_id': update.patient.patient_id
            }
            for update in updates
        ]
    
    @database_sync_to_async
    def mark_update_delivered(self, update_id):
        """Mark update as delivered"""
        try:
            update = RealTimeUpdate.objects.get(update_id=update_id)
            now = timezone.now()
            
            if self.client_type == 'web':
                update.web_delivered = True
                update.web_delivered_at = now
            else:  # mobile
                update.mobile_delivered = True
                update.mobile_delivered_at = now
            
            update.save()
            logger.info(f"Marked update {update_id} as delivered to {self.client_type}")
            
        except RealTimeUpdate.DoesNotExist:
            logger.error(f"Update {update_id} not found for delivery confirmation")

class NotificationConsumer(AsyncWebsocketConsumer):
    """WebSocket consumer for general notifications"""
    
    async def connect(self):
        """Accept WebSocket connection for notifications"""
        self.user_id = self.scope['user'].id if self.scope['user'].is_authenticated else None
        
        if not self.user_id:
            await self.close()
            return
        
        self.room_group_name = f'user_{self.user_id}_notifications'
        
        # Join room group
        await self.channel_layer.group_add(
            self.room_group_name,
            self.channel_name
        )
        
        await self.accept()
        logger.info(f"Notification WebSocket connected for user {self.user_id}")
    
    async def disconnect(self, close_code):
        """Leave room group"""
        if hasattr(self, 'room_group_name'):
            await self.channel_layer.group_discard(
                self.room_group_name,
                self.channel_name
            )
        
        logger.info(f"Notification WebSocket disconnected for user {self.user_id}")
    
    async def receive(self, text_data):
        """Receive message from WebSocket"""
        try:
            data = json.loads(text_data)
            message_type = data.get('type')
            
            if message_type == 'heartbeat':
                await self.send(text_data=json.dumps({
                    'type': 'heartbeat_response',
                    'timestamp': timezone.now().isoformat()
                }))
            
        except json.JSONDecodeError:
            logger.error(f"Invalid JSON received from notification WebSocket: {text_data}")
    
    async def send_notification(self, event):
        """Send notification to WebSocket"""
        await self.send(text_data=json.dumps(event['data']))
