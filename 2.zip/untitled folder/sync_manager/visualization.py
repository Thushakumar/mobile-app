# sync_manager/visualization.py
import json
import numpy as np
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
from django.db.models import Avg, Count, Q
from django.utils import timezone

from patients.models import Patient
from progress.models import Progress, SessionHistory
from mobile_therapy.models import MobileProgress, MobileSessionHistory, VideoSubmission

class VisualizationService:
    """Service for generating graphical data visualizations"""
    
    def __init__(self):
        self.color_scheme = {
            'primary': '#3B82F6',      # Blue
            'secondary': '#10B981',    # Green
            'accent': '#F59E0B',       # Amber
            'danger': '#EF4444',       # Red
            'warning': '#F97316',      # Orange
            'info': '#06B6D4',         # Cyan
            'success': '#22C55E',      # Green
        }
    
    def get_progress_chart_data(self, patient_id: str, timeframe: str = '30d') -> Dict[str, Any]:
        """Generate progress chart data for a patient"""
        try:
            patient = Patient.objects.get(patient_id=patient_id)
            
            # Calculate date range
            end_date = timezone.now().date()
            if timeframe == '7d':
                start_date = end_date - timedelta(days=7)
                date_format = '%Y-%m-%d'
                group_by = 'day'
            elif timeframe == '30d':
                start_date = end_date - timedelta(days=30)
                date_format = '%Y-%m-%d'
                group_by = 'day'
            elif timeframe == '3m':
                start_date = end_date - timedelta(days=90)
                date_format = '%Y-W%U'  # Year-Week format
                group_by = 'week'
            else:  # 1y
                start_date = end_date - timedelta(days=365)
                date_format = '%Y-%m'
                group_by = 'month'
            
            # Get progress data
            progress_data = Progress.objects.filter(
                patient=patient,
                date__gte=start_date,
                date__lte=end_date
            ).order_by('date', 'time')
            
            # Group data by time period
            grouped_data = {}
            for progress in progress_data:
                if group_by == 'day':
                    key = progress.date.strftime(date_format)
                elif group_by == 'week':
                    key = progress.date.strftime(date_format)
                else:  # month
                    key = progress.date.strftime(date_format)
                
                if key not in grouped_data:
                    grouped_data[key] = {
                        'accuracy_sum': 0,
                        'count': 0,
                        'best_accuracy': 0,
                        'words': set(),
                        'chapters': set()
                    }
                
                grouped_data[key]['accuracy_sum'] += progress.accuracy
                grouped_data[key]['count'] += 1
                grouped_data[key]['best_accuracy'] = max(grouped_data[key]['best_accuracy'], progress.accuracy)
                grouped_data[key]['words'].add(progress.word.word)
                grouped_data[key]['chapters'].add(progress.word.chapter.name)
            
            # Format for chart
            chart_data = []
            labels = []
            
            for key in sorted(grouped_data.keys()):
                data = grouped_data[key]
                avg_accuracy = data['accuracy_sum'] / data['count'] if data['count'] > 0 else 0
                
                chart_data.append({
                    'date': key,
                    'average_accuracy': round(avg_accuracy, 1),
                    'best_accuracy': data['best_accuracy'],
                    'total_trials': data['count'],
                    'words_practiced': len(data['words']),
                    'chapters_practiced': len(data['chapters'])
                })
                labels.append(key)
            
            return {
                'chart_data': chart_data,
                'labels': labels,
                'timeframe': timeframe,
                'summary': {
                    'total_sessions': len(chart_data),
                    'average_accuracy': round(np.mean([d['average_accuracy'] for d in chart_data]) if chart_data else 0, 1),
                    'best_session': max(chart_data, key=lambda x: x['average_accuracy']) if chart_data else None,
                    'improvement_trend': self._calculate_trend([d['average_accuracy'] for d in chart_data])
                }
            }
        
        except Patient.DoesNotExist:
            return {'error': 'Patient not found'}
        except Exception as e:
            return {'error': str(e)}
    
    def get_phoneme_analysis_chart(self, patient_id: str) -> Dict[str, Any]:
        """Generate phoneme-specific analysis chart"""
        try:
            patient = Patient.objects.get(patient_id=patient_id)
            
            # Get progress grouped by chapter (phoneme)
            from chapters.models import Chapter
            chapters = Chapter.objects.all().order_by('chapter_number')
            
            chart_data = []
            
            for chapter in chapters:
                progress_records = Progress.objects.filter(
                    patient=patient,
                    word__chapter=chapter
                ).order_by('-date', '-time')
                
                if not progress_records.exists():
                    continue
                
                # Calculate statistics
                accuracies = [p.accuracy for p in progress_records]
                word_count = progress_records.values('word').distinct().count()
                total_attempts = progress_records.count()
                
                # Determine proficiency level
                avg_accuracy = np.mean(accuracies)
                if avg_accuracy >= 90:
                    proficiency = 'Mastered'
                    color = self.color_scheme['success']
                elif avg_accuracy >= 70:
                    proficiency = 'Proficient'
                    color = self.color_scheme['primary']
                elif avg_accuracy >= 50:
                    proficiency = 'Developing'
                    color = self.color_scheme['warning']
                else:
                    proficiency = 'Needs Work'
                    color = self.color_scheme['danger']
                
                chart_data.append({
                    'phoneme': f'/{chapter.name[0].lower()}/',
                    'chapter_name': chapter.name,
                    'average_accuracy': round(avg_accuracy, 1),
                    'best_accuracy': max(accuracies),
                    'worst_accuracy': min(accuracies),
                    'total_attempts': total_attempts,
                    'words_practiced': word_count,
                    'proficiency_level': proficiency,
                    'color': color,
                    'improvement': self._calculate_trend(accuracies[-10:])  # Last 10 attempts
                })
            
            return {
                'chart_data': chart_data,
                'summary': {
                    'total_phonemes_practiced': len(chart_data),
                    'mastered_count': len([d for d in chart_data if d['proficiency_level'] == 'Mastered']),
                    'proficient_count': len([d for d in chart_data if d['proficiency_level'] == 'Proficient']),
                    'developing_count': len([d for d in chart_data if d['proficiency_level'] == 'Developing']),
                    'needs_work_count': len([d for d in chart_data if d['proficiency_level'] == 'Needs Work']),
                    'overall_accuracy': round(np.mean([d['average_accuracy'] for d in chart_data]) if chart_data else 0, 1)
                }
            }
        
        except Patient.DoesNotExist:
            return {'error': 'Patient not found'}
        except Exception as e:
            return {'error': str(e)}
    
    def get_session_comparison_chart(self, patient_id: str, limit: int = 10) -> Dict[str, Any]:
        """Generate session comparison chart"""
        try:
            patient = Patient.objects.get(patient_id=patient_id)
            
            # Get recent sessions
            sessions = SessionHistory.objects.filter(
                patient=patient
            ).order_by('-date')[:limit]
            
            chart_data = []
            
            for session in reversed(sessions):  # Reverse to show chronological order
                # Get progress data for this session date
                session_progress = Progress.objects.filter(
                    patient=patient,
                    date=session.date
                )
                
                phonemes_practiced = set()
                words_count = 0
                
                for progress in session_progress:
                    phonemes_practiced.add(f'/{progress.word.chapter.name[0].lower()}/')
                    words_count += 1
                
                chart_data.append({
                    'date': session.date.strftime('%Y-%m-%d'),
                    'duration': session.duration,
                    'accuracy': session.score,
                    'words_attempted': words_count,
                    'phonemes_practiced': len(phonemes_practiced),
                    'phonemes_list': list(phonemes_practiced)
                })
            
            # Calculate session-to-session improvement
            for i in range(1, len(chart_data)):
                prev_accuracy = chart_data[i-1]['accuracy']
                curr_accuracy = chart_data[i]['accuracy']
                chart_data[i]['improvement'] = round(curr_accuracy - prev_accuracy, 1)
            
            if chart_data:
                chart_data[0]['improvement'] = 0  # First session has no previous comparison
            
            return {
                'chart_data': chart_data,
                'summary': {
                    'total_sessions': len(chart_data),
                    'average_accuracy': round(np.mean([d['accuracy'] for d in chart_data]) if chart_data else 0, 1),
                    'average_duration': self._calculate_average_duration([d['duration'] for d in chart_data]),
                    'consistency_score': self._calculate_consistency([d['accuracy'] for d in chart_data]),
                    'best_session': max(chart_data, key=lambda x: x['accuracy']) if chart_data else None,
                    'recent_trend': self._calculate_trend([d['accuracy'] for d in chart_data[-5:]])  # Last 5 sessions
                }
            }
        
        except Patient.DoesNotExist:
            return {'error': 'Patient not found'}
        except Exception as e:
            return {'error': str(e)}
    
    def get_ml_analysis_visualization(self, patient_id: str, limit: int = 20) -> Dict[str, Any]:
        """Generate ML analysis results visualization"""
        try:
            patient = Patient.objects.get(patient_id=patient_id)
            
            # Get video submissions with ML results
            video_submissions = VideoSubmission.objects.filter(
                patient=patient,
                ml_results__isnull=False
            ).order_by('-created_at')[:limit]
            
            chart_data = []
            
            for submission in reversed(video_submissions):  # Chronological order
                ml_results = submission.ml_results
                
                # Extract ML metrics (assuming standardized format)
                audio_score = ml_results.get('audio_analysis', {}).get('overall_score', 0)
                video_score = ml_results.get('video_analysis', {}).get('overall_score', 0)
                combined_score = ml_results.get('combined_analysis', {}).get('final_score', 0)
                
                chart_data.append({
                    'date': submission.created_at.strftime('%Y-%m-%d %H:%M'),
                    'word': submission.word.word if submission.word else 'Unknown',
                    'chapter': submission.word.chapter.name if submission.word else 'Unknown',
                    'audio_score': round(audio_score, 1),
                    'video_score': round(video_score, 1),
                    'combined_score': round(combined_score, 1),
                    'processing_time': ml_results.get('processing_time', 0),
                    'confidence': ml_results.get('confidence', 0)
                })
            
            # Calculate analytics
            if chart_data:
                audio_scores = [d['audio_score'] for d in chart_data]
                video_scores = [d['video_score'] for d in chart_data]
                combined_scores = [d['combined_score'] for d in chart_data]
                
                summary = {
                    'total_analyses': len(chart_data),
                    'average_audio_score': round(np.mean(audio_scores), 1),
                    'average_video_score': round(np.mean(video_scores), 1),
                    'average_combined_score': round(np.mean(combined_scores), 1),
                    'audio_trend': self._calculate_trend(audio_scores),
                    'video_trend': self._calculate_trend(video_scores),
                    'combined_trend': self._calculate_trend(combined_scores),
                    'best_performance': max(chart_data, key=lambda x: x['combined_score']),
                    'consistency': {
                        'audio': self._calculate_consistency(audio_scores),
                        'video': self._calculate_consistency(video_scores),
                        'combined': self._calculate_consistency(combined_scores)
                    }
                }
            else:
                summary = {
                    'total_analyses': 0,
                    'average_audio_score': 0,
                    'average_video_score': 0,
                    'average_combined_score': 0,
                    'audio_trend': 'no_data',
                    'video_trend': 'no_data',
                    'combined_trend': 'no_data',
                    'best_performance': None,
                    'consistency': {'audio': 0, 'video': 0, 'combined': 0}
                }
            
            return {
                'chart_data': chart_data,
                'summary': summary
            }
        
        except Patient.DoesNotExist:
            return {'error': 'Patient not found'}
        except Exception as e:
            return {'error': str(e)}
    
    def get_comprehensive_dashboard_data(self, patient_id: str) -> Dict[str, Any]:
        """Generate comprehensive dashboard data"""
        return {
            'progress_chart': self.get_progress_chart_data(patient_id, '30d'),
            'phoneme_analysis': self.get_phoneme_analysis_chart(patient_id),
            'session_comparison': self.get_session_comparison_chart(patient_id),
            'ml_analysis': self.get_ml_analysis_visualization(patient_id),
            'generated_at': timezone.now().isoformat()
        }
    
    def _calculate_trend(self, values: List[float]) -> str:
        """Calculate trend direction from a list of values"""
        if len(values) < 2:
            return 'no_data'
        
        # Simple linear regression to determine trend
        x = np.arange(len(values))
        y = np.array(values)
        
        # Calculate slope
        n = len(values)
        slope = (n * np.sum(x * y) - np.sum(x) * np.sum(y)) / (n * np.sum(x**2) - (np.sum(x))**2)
        
        if slope > 0.5:
            return 'improving'
        elif slope < -0.5:
            return 'declining'
        else:
            return 'stable'
    
    def _calculate_consistency(self, values: List[float]) -> float:
        """Calculate consistency score (lower coefficient of variation = higher consistency)"""
        if not values or len(values) < 2:
            return 0.0
        
        mean_val = np.mean(values)
        if mean_val == 0:
            return 0.0
        
        std_val = np.std(values)
        cv = std_val / mean_val  # Coefficient of variation
        
        # Convert to consistency score (0-100, higher is better)
        consistency_score = max(0, 100 - (cv * 100))
        return round(consistency_score, 1)
    
    def _calculate_average_duration(self, durations: List[str]) -> str:
        """Calculate average duration from duration strings"""
        if not durations:
            return "00:00:00"
        
        total_seconds = 0
        count = 0
        
        for duration_str in durations:
            try:
                # Parse duration string (assuming HH:MM:SS format)
                parts = duration_str.split(':')
                if len(parts) == 3:
                    hours, minutes, seconds = map(int, parts)
                    total_seconds += hours * 3600 + minutes * 60 + seconds
                    count += 1
            except:
                continue
        
        if count == 0:
            return "00:00:00"
        
        avg_seconds = total_seconds // count
        hours = avg_seconds // 3600
        minutes = (avg_seconds % 3600) // 60
        seconds = avg_seconds % 60
        
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"

# Global visualization service instance
visualization_service = VisualizationService()
