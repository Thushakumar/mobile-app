import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'dart:io';
import '../models/chapter.dart';
import '../models/word.dart';
import '../services/api_service.dart';
import '../services/ml_analysis_service.dart';
import '../providers/auth_provider.dart';
import 'package:provider/provider.dart';

class VideoPreviewScreen extends StatefulWidget {
  final String videoPath;
  final Chapter chapter;
  
  // New structure
  final Word? word;
  final String? wordText;
  final bool isIndividualPractice;
  final List<Word>? sessionWords;
  
  // Legacy support
  final String? wordToSpeak;
  final int wordIndex;
  final int totalWords;

  const VideoPreviewScreen({
    super.key,
    required this.videoPath,
    required this.chapter,
    this.word,
    this.wordText,
    this.isIndividualPractice = false,
    this.sessionWords,
    this.wordToSpeak,
    required this.wordIndex,
    required this.totalWords,
  });

  @override
  State<VideoPreviewScreen> createState() => _VideoPreviewScreenState();
}

class _VideoPreviewScreenState extends State<VideoPreviewScreen> {
  VideoPlayerController? _controller;
  final MLAnalysisService _mlService = MLAnalysisService();
  
  bool _isPlayerInitialized = false;
  bool _isUploading = false;
  bool _isAnalyzing = false;
  double _uploadProgress = 0.0;
  String? _error;
  
  // ML Analysis results
  MLAnalysisResult? _analysisResult;
  int? _videoSubmissionId;
  
  String get currentWordText {
    return widget.wordText ?? widget.wordToSpeak ?? '';
  }
  
  Word? get currentWord {
    return widget.word;
  }

  @override
  void initState() {
    super.initState();
    _initializeVideoPlayer();
  }

  Future<void> _initializeVideoPlayer() async {
    try {
      final file = File(widget.videoPath);
      if (!await file.exists()) {
        setState(() {
          _error = 'Video file not found';
        });
        return;
      }

      _controller = VideoPlayerController.file(file);
      await _controller!.initialize();
      
      setState(() {
        _isPlayerInitialized = true;
      });
    } catch (e) {
      setState(() {
        _error = 'Failed to load video: $e';
      });
    }
  }

  Future<void> _submitVideo() async {
    if (_controller == null || _isUploading) return;

    setState(() {
      _isUploading = true;
      _uploadProgress = 0.0;
      _error = null;
    });

    try {
      final authProvider = Provider.of<AuthProvider>(context, listen: false);
      
      // Debug current patient state
      print('=== DEBUG: Current patient state ===');
      print('Patient object: ${authProvider.patient}');
      print('Patient ID: ${authProvider.patient?.patientId}');
      
      // DEBUG: If no patient data, set test patient
      if (authProvider.patient == null) {
        print('=== DEBUG: No patient data, setting test patient ===');
        authProvider.setTestPatient();
        print('=== DEBUG: Test patient set, checking again ===');
        print('Patient object after set: ${authProvider.patient}');
        print('Patient ID after set: ${authProvider.patient?.patientId}');
      }
      
      if (authProvider.patient == null) {
        throw Exception('No patient data available after attempting to set test patient');
      }
      
      // Verify patient ID is not empty
      final patientId = authProvider.patient!.patientId;
      if (patientId.isEmpty) {
        print('=== DEBUG: Patient ID is empty, creating new test patient with ID ===');
        authProvider.setTestPatient();
        final newPatientId = authProvider.patient?.patientId ?? '';
        if (newPatientId.isEmpty) {
          throw Exception('Unable to create valid patient data - patient ID remains empty');
        }
      }
      
      if (authProvider.patient == null) {
        throw Exception('No patient data available');
      }

      // Debug logging
      print('=== DEBUG: VideoPreviewScreen submitVideo ===');
      print('Patient ID: ${authProvider.patient!.patientId}');
      print('Patient ID type: ${authProvider.patient!.patientId.runtimeType}');
      print('Chapter ID: ${widget.chapter.id}');
      print('Chapter ID type: ${widget.chapter.id.runtimeType}');
      print('Current word text: $currentWordText');
      print('Current word text type: ${currentWordText.runtimeType}');
      print('Video path: ${widget.videoPath}');
      print('Video file exists: ${await File(widget.videoPath).exists()}');

      // Step 1: Upload video
      setState(() {
        _uploadProgress = 0.2;
      });

      // Final debug check before API call
      print('=== DEBUG: About to call API with these parameters ===');
      print('patientId parameter: "${authProvider.patient!.patientId}"');
      print('chapterId parameter: ${widget.chapter.id}');
      print('wordText parameter: "$currentWordText"');
      print('videoPath parameter: "${widget.videoPath}"');

      final result = await ApiService.submitVideo(
        patientId: authProvider.patient!.patientId,
        chapterId: widget.chapter.id,
        wordText: currentWordText,
        videoPath: widget.videoPath,
      );

      if (!result['success']) {
        throw Exception(result['error'] ?? result['message'] ?? 'Upload failed');
      }

      // Step 2: Get video submission ID for ML analysis
      final videoData = result['data'] as Map<String, dynamic>?;
      final videoSubmissionId = videoData?['id'] as int?;
      if (videoSubmissionId == null) {
        throw Exception('No video submission ID received');
      }

      setState(() {
        _videoSubmissionId = videoSubmissionId;
        _uploadProgress = 0.5;
        _isAnalyzing = true;
      });

      // Step 3: Check ML service health
      final healthStatus = await _mlService.checkHealth();
      if (healthStatus == null || !MLHealthStatus.fromJson(healthStatus).isHealthy) {
        print('Warning: ML service not healthy, skipping analysis');
        _showSuccessDialog(skipAnalysis: true);
        return;
      }

      setState(() {
        _uploadProgress = 0.7;
      });

      // Step 4: Trigger ML analysis
      final analysisResult = await _mlService.analyzeVideo(videoSubmissionId);
      if (analysisResult == null || !analysisResult['success']) {
        print('Warning: ML analysis failed, showing success without analysis');
        _showSuccessDialog(skipAnalysis: true);
        return;
      }

      setState(() {
        _uploadProgress = 0.9;
      });

      // Step 5: Poll for results if analysis was triggered successfully
      final finalResult = await _mlService.pollForResults(
        videoSubmissionId: videoSubmissionId,
        timeout: const Duration(minutes: 2),
      );

      setState(() {
        _uploadProgress = 1.0;
        _isAnalyzing = false;
        _analysisResult = finalResult != null ? MLAnalysisResult.fromJson(finalResult) : null;
      });

      if (mounted) {
        _showSuccessDialog(analysisResult: _analysisResult);
      }

    } catch (e) {
      setState(() {
        _error = 'Upload failed: $e';
        _isUploading = false;
        _isAnalyzing = false;
        _uploadProgress = 0.0;
      });
      
      // Print detailed error for debugging
      print('Video submission error: $e');
      print('Stack trace: ${StackTrace.current}');
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Upload failed: ${e.toString().length > 100 ? e.toString().substring(0, 100) + "..." : e}'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 5),
            action: SnackBarAction(
              label: 'Retry',
              textColor: Colors.white,
              onPressed: _submitVideo,
            ),
          ),
        );
      }
    }
  }

  void _showSuccessDialog({MLAnalysisResult? analysisResult, bool skipAnalysis = false}) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.check_circle, color: Colors.green, size: 28),
            SizedBox(width: 12),
            Text('Video Submitted!'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Your video has been successfully submitted.'),
            if (skipAnalysis) ...[
              const SizedBox(height: 12),
              const Text(
                'Note: Analysis service is currently unavailable.',
                style: TextStyle(color: Colors.orange, fontSize: 12),
              ),
            ] else if (analysisResult != null) ...[
              const SizedBox(height: 16),
              const Divider(),
              const Text(
                'Analysis Results:',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              if (analysisResult.success) ...[
                _buildAnalysisResultRow('Predicted Word:', analysisResult.predictedClass ?? 'Unknown'),
                _buildAnalysisResultRow('Target Word:', currentWordText),
                if (analysisResult.accuracyScore != null)
                  _buildAnalysisResultRow('Accuracy:', '${(analysisResult.accuracyScore! * 100).toStringAsFixed(1)}%'),
                if (analysisResult.confidenceScore != null)
                  _buildAnalysisResultRow('Confidence:', '${(analysisResult.confidenceScore! * 100).toStringAsFixed(1)}%'),
                const SizedBox(height: 8),
                _buildAccuracyIndicator(analysisResult.accuracyScore ?? 0.0),
              ] else ...[
                Text(
                  'Analysis failed: ${analysisResult.error ?? "Unknown error"}',
                  style: const TextStyle(color: Colors.red),
                ),
              ]
            ] else ...[
              const SizedBox(height: 12),
              const Row(
                children: [
                  SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
                  SizedBox(width: 8),
                  Text('Processing analysis...'),
                ],
              ),
            ],
          ],
        ),
        actions: [
          if (widget.wordIndex < widget.totalWords - 1)
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close dialog
                Navigator.of(context).pop(); // Go back to recording
                // Navigate to next word (this would be handled by parent)
              },
              child: const Text('Next Word'),
            ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop(); // Close dialog
              Navigator.of(context).pop(); // Go back to recording
            },
            child: Text(widget.wordIndex < widget.totalWords - 1 ? 'Retry' : 'Finish'),
          ),
        ],
      ),
    );
  }

  Widget _buildAnalysisResultRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 100,
            child: Text(
              label,
              style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 12),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAccuracyIndicator(double accuracy) {
    Color color;
    String message;
    IconData icon;
    
    if (accuracy >= 0.8) {
      color = Colors.green;
      message = 'Excellent!';
      icon = Icons.star;
    } else if (accuracy >= 0.6) {
      color = Colors.orange;
      message = 'Good job!';
      icon = Icons.thumb_up;
    } else {
      color = Colors.red;
      message = 'Keep practicing!';
      icon = Icons.refresh;
    }
    
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 16),
          const SizedBox(width: 8),
          Text(
            message,
            style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 12),
          ),
        ],
      ),
    );
  }

  void _retakeVideo() {
    Navigator.pop(context); // Go back to recording screen
  }

  String _formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    String minutes = twoDigits(duration.inMinutes);
    String seconds = twoDigits(duration.inSeconds.remainder(60));
    return '$minutes:$seconds';
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: _isUploading ? null : () => Navigator.pop(context),
        ),
        title: Text(
          'Preview - $currentWordText',
          style: const TextStyle(color: Colors.white, fontSize: 16),
        ),
        centerTitle: true,
      ),
      body: _error != null
          ? _buildErrorView()
          : !_isPlayerInitialized
              ? const Center(
                  child: CircularProgressIndicator(color: Colors.white),
                )
              : _buildPreviewView(),
    );
  }

  Widget _buildErrorView() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(
            Icons.error_outline,
            color: Colors.red,
            size: 64,
          ),
          const SizedBox(height: 16),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32),
            child: Text(
              _error!,
              style: const TextStyle(color: Colors.white, fontSize: 16),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(height: 24),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton.icon(
                onPressed: _retakeVideo,
                icon: const Icon(Icons.videocam),
                label: const Text('Retake'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                ),
              ),
              const SizedBox(width: 16),
              ElevatedButton.icon(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.close),
                label: const Text('Cancel'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red,
                  foregroundColor: Colors.white,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildPreviewView() {
    return Column(
      children: [
        // Progress indicator
        Container(
          padding: const EdgeInsets.all(16),
          child: LinearProgressIndicator(
            value: (widget.wordIndex + 1) / widget.totalWords,
            backgroundColor: Colors.white.withOpacity(0.3),
            valueColor: const AlwaysStoppedAnimation<Color>(Colors.blue),
          ),
        ),
        
        // Word info
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
          child: Text(
            'Preview: "$currentWordText"',
            style: const TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),

        // Video player
        Expanded(
          child: Container(
            margin: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: Colors.white.withOpacity(0.3),
                width: 1,
              ),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  AspectRatio(
                    aspectRatio: _controller!.value.aspectRatio,
                    child: VideoPlayer(_controller!),
                  ),
                  
                  // Play/pause controls
                  if (!_controller!.value.isPlaying)
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          _controller!.play();
                        });
                      },
                      child: Container(
                        width: 80,
                        height: 80,
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.7),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.play_arrow,
                          color: Colors.white,
                          size: 40,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),

        // Video info
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.access_time, color: Colors.white70, size: 16),
              const SizedBox(width: 8),
              Text(
                'Duration: ${_formatDuration(_controller!.value.duration)}',
                style: const TextStyle(color: Colors.white70, fontSize: 14),
              ),
            ],
          ),
        ),

        // Upload progress
        if (_isUploading) ...[
          Container(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                Text(
                  _getProgressMessage(),
                  style: const TextStyle(color: Colors.white, fontSize: 16),
                ),
                const SizedBox(height: 12),
                LinearProgressIndicator(
                  value: _uploadProgress,
                  backgroundColor: Colors.white.withOpacity(0.3),
                  valueColor: AlwaysStoppedAnimation<Color>(
                    _isAnalyzing ? Colors.blue : Colors.green
                  ),
                ),
              ],
            ),
          ),
        ],

        // Action buttons
        Container(
          padding: const EdgeInsets.all(24),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              // Retake button
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: _isUploading ? null : _retakeVideo,
                  icon: const Icon(Icons.videocam),
                  label: const Text('Retake'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.orange,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                ),
              ),
              
              const SizedBox(width: 16),
              
              // Submit button
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: _isUploading ? null : _submitVideo,
                  icon: _isUploading 
                      ? const SizedBox(
                          width: 16, 
                          height: 16,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                          ),
                        )
                      : const Icon(Icons.check),
                  label: Text(_isUploading ? 'Uploading...' : 'Submit'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  String _getProgressMessage() {
    if (_uploadProgress <= 0.5) {
      return 'Uploading video... ${(_uploadProgress * 100).toInt()}%';
    } else if (_isAnalyzing) {
      return 'Analyzing speech patterns... ${(_uploadProgress * 100).toInt()}%';
    } else if (_uploadProgress >= 1.0) {
      return 'Processing complete!';
    } else {
      return 'Processing... ${(_uploadProgress * 100).toInt()}%';
    }
  }
}
