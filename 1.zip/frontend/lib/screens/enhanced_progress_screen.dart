import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../services/api_service.dart';

class EnhancedProgressScreen extends StatefulWidget {
  const EnhancedProgressScreen({super.key});

  @override
  State<EnhancedProgressScreen> createState() => _EnhancedProgressScreenState();
}

class _EnhancedProgressScreenState extends State<EnhancedProgressScreen> with TickerProviderStateMixin {
  bool _isLoading = true;
  String? _error;
  Map<String, dynamic>? _progressData;
  List<Map<String, dynamic>> _sessionHistory = [];
  
  late TabController _tabController;
  late AnimationController _chartAnimationController;
  late Animation<double> _chartAnimation;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _chartAnimationController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );
    _chartAnimation = CurvedAnimation(
      parent: _chartAnimationController,
      curve: Curves.easeInOut,
    );
    _loadProgressData();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _chartAnimationController.dispose();
    super.dispose();
  }

  Future<void> _loadProgressData() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final progressResult = await ApiService.getProgress();
      final historyResult = await ApiService.getSessionHistory();

      if (progressResult['success'] && historyResult['success']) {
        setState(() {
          _progressData = progressResult['data'];
          _sessionHistory = List<Map<String, dynamic>>.from(historyResult['data']);
          _isLoading = false;
        });
        _chartAnimationController.forward();
      } else {
        // Fallback to sample data if backend fails
        await Future.delayed(const Duration(seconds: 1));
        
        setState(() {
          _progressData = {
            'total_sessions': 15,
            'completed_sessions': 12,
            'average_score': 78.5,
            'improvement_percentage': 23.5,
            'streak_days': 5,
            'total_words_practiced': 240,
            'accuracy_rate': 85.2,
            'weekly_progress': [
              {'day': 'Mon', 'score': 65.0, 'sessions': 2},
              {'day': 'Tue', 'score': 72.0, 'sessions': 3},
              {'day': 'Wed', 'score': 78.0, 'sessions': 2},
              {'day': 'Thu', 'score': 75.0, 'sessions': 1},
              {'day': 'Fri', 'score': 82.0, 'sessions': 4},
              {'day': 'Sat', 'score': 85.0, 'sessions': 2},
              {'day': 'Sun', 'score': 79.0, 'sessions': 1},
            ],
            'chapter_progress': [
              {
                'name': 'Chapter 1: Basic Sounds',
                'progress': 95.0,
                'completed_sessions': 5,
                'total_sessions': 5,
              },
              {
                'name': 'Chapter 2: Vowel Sounds',
                'progress': 80.0,
                'completed_sessions': 4,
                'total_sessions': 5,
              },
              {
                'name': 'Chapter 3: Consonants',
                'progress': 60.0,
                'completed_sessions': 3,
                'total_sessions': 5,
              },
            ],
          };
          
          _sessionHistory = [
            {
              'chapter_name': 'Chapter 1: Basic Sounds',
              'session_score': 85.0,
              'words_completed': 20,
              'completed_at': '2025-08-19T10:30:00Z',
              'status': 'completed',
            },
            {
              'chapter_name': 'Chapter 2: Vowel Sounds',
              'session_score': 92.0,
              'words_completed': 18,
              'completed_at': '2025-08-18T14:15:00Z',
              'status': 'completed',
            },
            {
              'chapter_name': 'Chapter 1: Basic Sounds',
              'session_score': 78.0,
              'words_completed': 20,
              'completed_at': '2025-08-17T16:45:00Z',
              'status': 'completed',
            },
          ];
          _isLoading = false;
        });
        _chartAnimationController.forward();
      }
    } catch (e) {
      setState(() {
        _error = e.toString();
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Progress Analytics'),
        backgroundColor: Colors.purple.shade600,
        foregroundColor: Colors.white,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadProgressData,
          ),
        ],
        bottom: _isLoading || _error != null ? null : TabBar(
          controller: _tabController,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white70,
          indicatorColor: Colors.white,
          tabs: const [
            Tab(icon: Icon(Icons.analytics), text: 'Overview'),
            Tab(icon: Icon(Icons.trending_up), text: 'Charts'),
            Tab(icon: Icon(Icons.history), text: 'History'),
          ],
        ),
      ),
      body: _isLoading
          ? const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 16),
                  Text('Loading your progress...'),
                ],
              ),
            )
          : _error != null
              ? _buildErrorState()
              : TabBarView(
                  controller: _tabController,
                  children: [
                    _buildOverviewTab(),
                    _buildChartsTab(),
                    _buildHistoryTab(),
                  ],
                ),
    );
  }

  Widget _buildErrorState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(
            Icons.error_outline,
            size: 64,
            color: Colors.red,
          ),
          const SizedBox(height: 16),
          Text(
            'Error: $_error',
            style: const TextStyle(fontSize: 16),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: _loadProgressData,
            child: const Text('Retry'),
          ),
        ],
      ),
    );
  }

  Widget _buildOverviewTab() {
    return RefreshIndicator(
      onRefresh: _loadProgressData,
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildStatsCards(),
            const SizedBox(height: 24),
            _buildChapterProgress(),
            const SizedBox(height: 24),
            _buildAchievements(),
          ],
        ),
      ),
    );
  }

  Widget _buildChartsTab() {
    return RefreshIndicator(
      onRefresh: _loadProgressData,
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Weekly Performance',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            _buildWeeklyChart(),
            const SizedBox(height: 24),
            const Text(
              'Session Scores Trend',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            _buildSessionScoresChart(),
          ],
        ),
      ),
    );
  }

  Widget _buildHistoryTab() {
    return RefreshIndicator(
      onRefresh: _loadProgressData,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              children: [
                const Text(
                  'Recent Sessions',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                Text(
                  '${_sessionHistory.length} sessions',
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.grey.shade600,
                  ),
                ),
              ],
            ),
          ),
          Expanded(child: _buildSessionHistoryList()),
        ],
      ),
    );
  }

  Widget _buildStatsCards() {
    final totalSessions = _progressData!['total_sessions'] ?? 0;
    final completedSessions = _progressData!['completed_sessions'] ?? 0;
    final averageScore = _progressData!['average_score'] ?? 0.0;
    final wordsCompleted = _progressData!['total_words_practiced'] ?? 0;
    final streakDays = _progressData!['streak_days'] ?? 0;
    final improvement = _progressData!['improvement_percentage'] ?? 0.0;

    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: _buildStatCard(
                icon: Icons.analytics,
                title: 'Avg Score',
                value: '${averageScore.toStringAsFixed(1)}%',
                color: Colors.blue,
                trend: improvement > 0 ? '+${improvement.toStringAsFixed(1)}%' : '${improvement.toStringAsFixed(1)}%',
                trendColor: improvement > 0 ? Colors.green : Colors.red,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _buildStatCard(
                icon: Icons.check_circle,
                title: 'Sessions',
                value: '$completedSessions',
                color: Colors.green,
                subtitle: 'of $totalSessions',
                subtitleColor: Colors.grey.shade600,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: _buildStatCard(
                icon: Icons.record_voice_over,
                title: 'Words',
                value: '$wordsCompleted',
                color: Colors.orange,
                subtitle: 'practiced',
                subtitleColor: Colors.grey.shade600,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _buildStatCard(
                icon: Icons.local_fire_department,
                title: 'Streak',
                value: '$streakDays',
                color: Colors.red,
                subtitle: 'days',
                subtitleColor: Colors.grey.shade600,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildStatCard({
    required IconData icon,
    required String title,
    required String value,
    required Color color,
    String? subtitle,
    Color? subtitleColor,
    String? trend,
    Color? trendColor,
  }) {
    return Card(
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(icon, color: color, size: 20),
                ),
                const Spacer(),
                if (trend != null)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: trendColor?.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      trend,
                      style: TextStyle(
                        color: trendColor,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              title,
              style: const TextStyle(
                fontSize: 14,
                color: Colors.grey,
              ),
            ),
            const SizedBox(height: 4),
            Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  value,
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                if (subtitle != null) ...[
                  const SizedBox(width: 4),
                  Text(
                    subtitle,
                    style: TextStyle(
                      fontSize: 14,
                      color: subtitleColor ?? Colors.grey,
                    ),
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildChapterProgress() {
    final chapters = _progressData!['chapter_progress'] as List<dynamic>? ?? [];
    
    return Card(
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.book, color: Colors.indigo, size: 24),
                const SizedBox(width: 8),
                const Text(
                  'Chapter Progress',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            ...chapters.map((chapter) => _buildChapterProgressItem(chapter)).toList(),
          ],
        ),
      ),
    );
  }

  Widget _buildChapterProgressItem(Map<String, dynamic> chapter) {
    final progress = (chapter['progress'] ?? 0.0) as double;
    final completedSessions = chapter['completed_sessions'] ?? 0;
    final totalSessions = chapter['total_sessions'] ?? 0;
    final name = chapter['name'] ?? 'Unknown Chapter';

    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Text(
                  name,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
              Text(
                '$completedSessions/$totalSessions',
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey.shade600,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          LinearProgressIndicator(
            value: progress / 100,
            backgroundColor: Colors.grey.shade300,
            valueColor: AlwaysStoppedAnimation<Color>(
              progress >= 80 ? Colors.green : progress >= 50 ? Colors.orange : Colors.red,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            '${progress.toStringAsFixed(1)}% complete',
            style: TextStyle(
              fontSize: 12,
              color: Colors.grey.shade600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAchievements() {
    return Card(
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.emoji_events, color: Colors.amber, size: 24),
                const SizedBox(width: 8),
                const Text(
                  'Achievements',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                _buildAchievementBadge(
                  icon: Icons.star,
                  label: 'First Chapter',
                  earned: true,
                ),
                const SizedBox(width: 12),
                _buildAchievementBadge(
                  icon: Icons.local_fire_department,
                  label: '5 Day Streak',
                  earned: true,
                ),
                const SizedBox(width: 12),
                _buildAchievementBadge(
                  icon: Icons.grade,
                  label: 'High Scorer',
                  earned: false,
                ),
                const SizedBox(width: 12),
                _buildAchievementBadge(
                  icon: Icons.trending_up,
                  label: 'Improving',
                  earned: true,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAchievementBadge({
    required IconData icon,
    required String label,
    required bool earned,
  }) {
    return Expanded(
      child: Column(
        children: [
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              color: earned ? Colors.amber : Colors.grey.shade300,
              shape: BoxShape.circle,
              boxShadow: earned ? [
                BoxShadow(
                  color: Colors.amber.withOpacity(0.3),
                  blurRadius: 8,
                  spreadRadius: 2,
                ),
              ] : null,
            ),
            child: Icon(
              icon,
              color: earned ? Colors.white : Colors.grey.shade600,
              size: 24,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            style: TextStyle(
              fontSize: 12,
              color: earned ? Colors.black : Colors.grey.shade600,
              fontWeight: earned ? FontWeight.bold : FontWeight.normal,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildWeeklyChart() {
    final weeklyData = _progressData!['weekly_progress'] as List<dynamic>? ?? [];
    
    return Card(
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: SizedBox(
          height: 200,
          child: AnimatedBuilder(
            animation: _chartAnimation,
            builder: (context, child) {
              return BarChart(
                BarChartData(
                  alignment: BarChartAlignment.spaceAround,
                  maxY: 100,
                  barTouchData: BarTouchData(enabled: true),
                  titlesData: FlTitlesData(
                    show: true,
                    bottomTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        getTitlesWidget: (double value, TitleMeta meta) {
                          if (value.toInt() < weeklyData.length) {
                            return Text(
                              weeklyData[value.toInt()]['day'] ?? '',
                              style: const TextStyle(fontSize: 12),
                            );
                          }
                          return const Text('');
                        },
                      ),
                    ),
                    leftTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        reservedSize: 30,
                        getTitlesWidget: (double value, TitleMeta meta) {
                          return Text(
                            '${value.toInt()}',
                            style: const TextStyle(fontSize: 10),
                          );
                        },
                      ),
                    ),
                    topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                    rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  ),
                  borderData: FlBorderData(show: false),
                  barGroups: weeklyData.asMap().entries.map((entry) {
                    final score = (entry.value['score'] ?? 0.0) as double;
                    return BarChartGroupData(
                      x: entry.key,
                      barRods: [
                        BarChartRodData(
                          toY: score * _chartAnimation.value,
                          color: _getScoreColor(score),
                          width: 16,
                          borderRadius: const BorderRadius.vertical(top: Radius.circular(4)),
                        ),
                      ],
                    );
                  }).toList(),
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildSessionScoresChart() {
    return Card(
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: SizedBox(
          height: 200,
          child: AnimatedBuilder(
            animation: _chartAnimation,
            builder: (context, child) {
              return LineChart(
                LineChartData(
                  gridData: FlGridData(show: true),
                  titlesData: FlTitlesData(
                    bottomTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        reservedSize: 30,
                        getTitlesWidget: (double value, TitleMeta meta) {
                          final sessionIndex = value.toInt();
                          if (sessionIndex < _sessionHistory.length) {
                            return Text(
                              'S${sessionIndex + 1}',
                              style: const TextStyle(fontSize: 10),
                            );
                          }
                          return const Text('');
                        },
                      ),
                    ),
                    leftTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        reservedSize: 30,
                        getTitlesWidget: (double value, TitleMeta meta) {
                          return Text(
                            '${value.toInt()}',
                            style: const TextStyle(fontSize: 10),
                          );
                        },
                      ),
                    ),
                    topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                    rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  ),
                  borderData: FlBorderData(show: true),
                  minX: 0,
                  maxX: _sessionHistory.length - 1.0,
                  minY: 0,
                  maxY: 100,
                  lineBarsData: [
                    LineChartBarData(
                      spots: _sessionHistory.asMap().entries.map((entry) {
                        final score = (entry.value['session_score'] ?? 0.0) as double;
                        return FlSpot(entry.key.toDouble(), score * _chartAnimation.value);
                      }).toList(),
                      isCurved: true,
                      color: Colors.purple.shade600,
                      barWidth: 3,
                      isStrokeCapRound: true,
                      belowBarData: BarAreaData(
                        show: true,
                        color: Colors.purple.shade600.withOpacity(0.1),
                      ),
                      dotData: FlDotData(
                        show: true,
                        getDotPainter: (spot, percent, barData, index) {
                          return FlDotCirclePainter(
                            radius: 4,
                            color: Colors.white,
                            strokeWidth: 2,
                            strokeColor: Colors.purple.shade600,
                          );
                        },
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildSessionHistoryList() {
    if (_sessionHistory.isEmpty) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.history, size: 64, color: Colors.grey),
            SizedBox(height: 16),
            Text(
              'No sessions completed yet',
              style: TextStyle(fontSize: 16, color: Colors.grey),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      itemCount: _sessionHistory.length,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      itemBuilder: (context, index) {
        final session = _sessionHistory[index];
        return _buildSessionHistoryItem(session);
      },
    );
  }

  Widget _buildSessionHistoryItem(Map<String, dynamic> session) {
    final chapterName = session['chapter_name'] ?? 'Unknown Chapter';
    final score = (session['session_score'] ?? 0.0) as double;
    final wordsCompleted = session['words_completed'] ?? 0;
    final completedAt = session['completed_at'] ?? '';
    final status = session['status'] ?? 'unknown';
    
    // Format date
    DateTime? dateTime;
    try {
      dateTime = DateTime.parse(completedAt);
    } catch (e) {
      // Handle parsing error
    }
    
    final formattedDate = dateTime != null 
        ? '${dateTime.day}/${dateTime.month}/${dateTime.year}'
        : 'Unknown date';
    
    final formattedTime = dateTime != null 
        ? '${dateTime.hour.toString().padLeft(2, '0')}:${dateTime.minute.toString().padLeft(2, '0')}'
        : '';

    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            color: _getScoreColor(score).withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                '${score.toInt()}',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: _getScoreColor(score),
                ),
              ),
              Text(
                'pts',
                style: TextStyle(
                  fontSize: 10,
                  color: _getScoreColor(score),
                ),
              ),
            ],
          ),
        ),
        title: Text(
          chapterName,
          style: const TextStyle(fontWeight: FontWeight.w500),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('$wordsCompleted words completed'),
            Text('$formattedDate $formattedTime'),
          ],
        ),
        trailing: Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: status == 'completed' ? Colors.green.withOpacity(0.1) : Colors.orange.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Text(
            status.toUpperCase(),
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.bold,
              color: status == 'completed' ? Colors.green : Colors.orange,
            ),
          ),
        ),
      ),
    );
  }

  Color _getScoreColor(double score) {
    if (score >= 80) return Colors.green;
    if (score >= 60) return Colors.orange;
    return Colors.red;
  }
}
