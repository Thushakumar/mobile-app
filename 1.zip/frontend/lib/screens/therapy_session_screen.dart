import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:camera/camera.dart';
import '../models/chapter.dart';
import '../models/therapy_session.dart';
import '../services/api_service.dart';
import '../services/video_recording_service.dart';
import '../providers/auth_provider.dart';
import 'video_recording_screen.dart';

class TherapySessionScreen extends StatefulWidget {
  final Chapter chapter;

  const TherapySessionScreen({
    super.key,
    required this.chapter,
  });

  @override
  State<TherapySessionScreen> createState() => _TherapySessionScreenState();
}

class _TherapySessionScreenState extends State<TherapySessionScreen>
    with SingleTickerProviderStateMixin {
  TherapySession? _currentSession;
  Map<String, dynamic>? _currentWord;
  bool _isLoading = true;
  bool _isLoadingWord = false;
  String? _error;
  
  late AnimationController _animationController;
  late Animation<double> _progressAnimation;
  
  // Video recording
  final VideoRecordingService _videoService = VideoRecordingService();
  bool _isCameraInitialized = false;
  bool _isRecording = false;
  String? _currentVideoPath;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _progressAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));
    
    _initializeSession();
    _initializeCamera();
  }

  Future<void> _initializeCamera() async {
    try {
      final initialized = await _videoService.initialize();
      setState(() {
        _isCameraInitialized = initialized;
      });
      if (!initialized) {
        _showError('Camera initialization failed. Video recording will not be available.');
      }
    } catch (e) {
      setState(() {
        _isCameraInitialized = false;
      });
      _showError('Camera error: $e');
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    _videoService.dispose();
    super.dispose();
  }

  Future<void> _initializeSession() async {
    try {
      final authProvider = Provider.of<AuthProvider>(context, listen: false);
      
      if (authProvider.patient == null) {
        setState(() {
          _error = 'No patient data available';
          _isLoading = false;
        });
        return;
      }
      
      final session = await ApiService.createTherapySession(
        patientId: authProvider.patient!.id, // Keep as int since API expects patient id as int
        chapterId: widget.chapter.id,
      );
      
      if (session['success']) {
        setState(() {
          _currentSession = TherapySession.fromJson(session['data']);
          _isLoading = false;
        });
        
        await _loadCurrentWord();
        _animationController.forward();
      } else {
        setState(() {
          _error = session['error'] ?? 'Failed to create session';
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _error = e.toString();
        _isLoading = false;
      });
    }
  }

  Future<void> _loadCurrentWord() async {
    if (_currentSession == null) return;
    
    setState(() {
      _isLoadingWord = true;
    });

    try {
      final result = await ApiService.getCurrentWord(_currentSession!.id);
      
      if (result['success']) {
        setState(() {
          _currentWord = result['data'];
          _isLoadingWord = false;
        });
      } else {
        setState(() {
          _error = result['error'] ?? 'Failed to load word';
          _isLoadingWord = false;
        });
      }
    } catch (e) {
      setState(() {
        _error = e.toString();
        _isLoadingWord = false;
      });
    }
  }

  Future<void> _nextWord() async {
    if (_currentSession == null || _isLoadingWord) return;

    // Check if this is the last word
    bool isLastWord = (_currentWord?['position'] ?? 0) >= (_currentSession!.totalWords - 1);
    
    if (isLastWord) {
      await _completeSession();
      return;
    }

    setState(() {
      _isLoadingWord = true;
    });

    try {
      final result = await ApiService.nextWord(_currentSession!.id);
      
      if (result['success']) {
        setState(() {
          _currentWord = result['data'];
          _isLoadingWord = false;
        });
      } else {
        setState(() {
          _error = result['error'] ?? 'Failed to load next word';
          _isLoadingWord = false;
        });
      }
    } catch (e) {
      setState(() {
        _error = e.toString();
        _isLoadingWord = false;
      });
    }
  }

  Future<void> _previousWord() async {
    if (_currentSession == null || _isLoadingWord) return;
    
    // Check if this is the first word
    if ((_currentWord?['position'] ?? 0) <= 0) return;

    setState(() {
      _isLoadingWord = true;
    });

    try {
      final result = await ApiService.previousWord(_currentSession!.id);
      
      if (result['success']) {
        setState(() {
          _currentWord = result['data'];
          _isLoadingWord = false;
        });
      } else {
        setState(() {
          _error = result['error'] ?? 'Failed to load previous word';
          _isLoadingWord = false;
        });
      }
    } catch (e) {
      setState(() {
        _error = e.toString();
        _isLoadingWord = false;
      });
    }
  }

  Future<void> _completeSession() async {
    if (_currentSession == null) return;

    try {
      final result = await ApiService.completeSession(_currentSession!.id);
      
      if (result['success']) {
        if (mounted) {
          _showCompletionDialog();
        }
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Error completing session: ${result['error']}'),
              backgroundColor: Colors.red,
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error completing session: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  void _showCompletionDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Text('Session Complete!'),
        content: const Text('Congratulations! You have completed this therapy session.'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop(); // Close dialog
              Navigator.of(context).pop(); // Go back to chapters
            },
            child: const Text('Continue'),
          ),
        ],
      ),
    );
  }

  Future<void> _launchVideoRecording() async {
    if (_currentWord == null) {
      _showError('No word available for recording');
      return;
    }

    if (_currentSession == null) {
      _showError('No active session');
      return;
    }

    try {
      // Get the word text and current progress
      String wordToSpeak = _currentWord!['word'] ?? 'unknown';
      int totalWords = _currentSession!.totalWords ?? 10; // Default fallback
      int currentWordIndex = _currentSession!.wordsCompleted ?? 0; // Current progress
      
      // Navigate to video recording screen
      final result = await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => VideoRecordingScreen(
            chapter: widget.chapter,
            wordToSpeak: wordToSpeak,
            wordIndex: currentWordIndex,
            totalWords: totalWords,
          ),
        ),
      );

      // If recording was successful, load the next word
      if (result == true) {
        await _loadCurrentWord();
      }
    } catch (e) {
      _showError('Failed to launch video recording: $e');
    }
  }

  Future<void> _toggleRecording() async {
    // Launch the new dedicated video recording screen
    await _launchVideoRecording();
  }

  Future<void> _startRecording() async {
    try {
      final path = await _videoService.startRecording();
      if (path != null) {
        setState(() {
          _isRecording = true;
          _currentVideoPath = path;
        });
      } else {
        _showError('Failed to start recording');
      }
    } catch (e) {
      _showError('Recording error: $e');
    }
  }

  Future<void> _stopRecording() async {
    try {
      final path = await _videoService.stopRecording();
      setState(() {
        _isRecording = false;
      });
      
      if (path != null && _currentSession != null && _currentWord != null) {
        _currentVideoPath = path;
        
        // Upload video to server
        _showSuccess('Recording saved. Uploading...');
        
        final uploadResult = await ApiService.uploadVideoSubmission(
          sessionId: _currentSession!.id,
          videoPath: path,
          word: _currentWord!['word'] ?? 'unknown',
        );
        
        if (uploadResult['success']) {
          _showSuccess('Video uploaded successfully!');
        } else {
          _showError('Upload failed: ${uploadResult['error']}');
        }
      } else {
        _showError('Failed to save recording');
      }
    } catch (e) {
      setState(() {
        _isRecording = false;
      });
      _showError('Recording error: $e');
    }
  }

  void _showError(String message) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void _showSuccess(String message) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: Colors.green,
        ),
      );
    }
  }

  Widget _buildCameraPreview() {
    if (!_isCameraInitialized || _videoService.controller == null) {
      return Container(
        height: 200,
        decoration: BoxDecoration(
          color: Colors.grey.shade300,
          borderRadius: BorderRadius.circular(12),
        ),
        child: const Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.camera_alt, size: 48, color: Colors.grey),
              SizedBox(height: 8),
              Text('Camera not available', style: TextStyle(color: Colors.grey)),
            ],
          ),
        ),
      );
    }

    return Container(
      height: 200,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: _isRecording ? Colors.red : Colors.grey.shade300,
          width: 3,
        ),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(9),
        child: CameraPreview(_videoService.controller!),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return Scaffold(
        appBar: AppBar(
          title: Text(widget.chapter.name),
          backgroundColor: Colors.blue.shade600,
          foregroundColor: Colors.white,
        ),
        body: const Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    if (_error != null) {
      return Scaffold(
        appBar: AppBar(
          title: Text(widget.chapter.name),
          backgroundColor: Colors.blue.shade600,
          foregroundColor: Colors.white,
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.error_outline,
                size: 64,
                color: Colors.red,
              ),
              const SizedBox(height: 16),
              Text(
                'Error: $_error',
                style: const TextStyle(fontSize: 16),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    _error = null;
                    _isLoading = true;
                  });
                  _initializeSession();
                },
                child: const Text('Retry'),
              ),
            ],
          ),
        ),
      );
    }

    if (_currentSession == null || _currentWord == null) {
      return Scaffold(
        appBar: AppBar(
          title: Text(widget.chapter.name),
          backgroundColor: Colors.blue.shade600,
          foregroundColor: Colors.white,
        ),
        body: const Center(
          child: Text('No session data available'),
        ),
      );
    }

    final progress = (_currentWord!['position'] + 1) / _currentSession!.totalWords;
    final isFirstWord = (_currentWord?['position'] ?? 0) <= 0;
    final isLastWord = (_currentWord?['position'] ?? 0) >= (_currentSession!.totalWords - 1);

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.chapter.name),
        backgroundColor: Colors.blue.shade600,
        foregroundColor: Colors.white,
        elevation: 0,
        actions: [
          if (_currentSession != null)
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Center(
                child: Text(
                  '${_currentWord!['position'] + 1}/${_currentSession!.totalWords}',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
        ],
      ),
      body: Column(
        children: [
          // Progress Bar
          Container(
            height: 8,
            color: Colors.blue.shade600,
            child: LinearProgressIndicator(
              value: progress,
              backgroundColor: Colors.blue.shade200,
              valueColor: AlwaysStoppedAnimation<Color>(Colors.yellow.shade600),
            ),
          ),
          
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  // Word Display Card
                  Expanded(
                    child: Card(
                      elevation: 8,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(32),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [Colors.blue.shade50, Colors.white],
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                          ),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            // Camera Preview
                            _buildCameraPreview(),
                            
                            const SizedBox(height: 24),
                            
                            // Word Text
                            Text(
                              _currentWord!['word'] ?? 'No word',
                              style: TextStyle(
                                fontSize: 32,
                                fontWeight: FontWeight.bold,
                                color: Colors.blue.shade800,
                                letterSpacing: 1,
                              ),
                              textAlign: TextAlign.center,
                            ),
                            
                            const SizedBox(height: 16),
                            
                            // Instructions
                            Text(
                              _isRecording 
                                  ? 'Recording... Speak the word clearly'
                                  : 'Tap record and speak this word clearly',
                              style: TextStyle(
                                fontSize: 16,
                                color: _isRecording ? Colors.red.shade600 : Colors.grey.shade600,
                                fontStyle: FontStyle.italic,
                                fontWeight: _isRecording ? FontWeight.w600 : FontWeight.normal,
                              ),
                              textAlign: TextAlign.center,
                            ),
                            
                            const SizedBox(height: 24),
                            
                            // Record Button
                            GestureDetector(
                              onTap: _toggleRecording,
                              child: AnimatedContainer(
                                duration: const Duration(milliseconds: 200),
                                padding: EdgeInsets.all(_isRecording ? 20 : 16),
                                decoration: BoxDecoration(
                                  color: _isRecording ? Colors.red.shade500 : Colors.red.shade100,
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: _isRecording ? Colors.red.shade700 : Colors.red.shade300,
                                    width: 3,
                                  ),
                                  boxShadow: _isRecording ? [
                                    BoxShadow(
                                      color: Colors.red.withOpacity(0.3),
                                      blurRadius: 10,
                                      spreadRadius: 2,
                                    ),
                                  ] : null,
                                ),
                                child: Icon(
                                  _isRecording ? Icons.radio_button_checked : Icons.videocam,
                                  size: 48,
                                  color: _isRecording ? Colors.white : Colors.red.shade600,
                                ),
                              ),
                            ),
                            
                            const SizedBox(height: 16),
                            
                            Text(
                              _isRecording ? 'Recording active' : 'Tap to record video',
                              style: TextStyle(
                                fontSize: 14,
                                color: _isRecording ? Colors.red.shade600 : Colors.grey.shade500,
                                fontWeight: _isRecording ? FontWeight.w600 : FontWeight.normal,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  
                  const SizedBox(height: 16),
                  
                  // Navigation Buttons
                  Row(
                    children: [
                      // Previous Button
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: isFirstWord || _isLoadingWord ? null : _previousWord,
                          icon: const Icon(Icons.arrow_back),
                          label: const Text('Previous'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.grey.shade600,
                            foregroundColor: Colors.white,
                            disabledBackgroundColor: Colors.grey.shade300,
                            padding: const EdgeInsets.symmetric(vertical: 16),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                        ),
                      ),
                      
                      const SizedBox(width: 16),
                      
                      // Next/Complete Button
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: _isLoadingWord ? null : _nextWord,
                          icon: _isLoadingWord 
                              ? const SizedBox(
                                  height: 20,
                                  width: 20,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                                  ),
                                )
                              : Icon(isLastWord ? Icons.check : Icons.arrow_forward),
                          label: Text(isLastWord ? 'Complete' : 'Next'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blue.shade600,
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(vertical: 16),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
