import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'dart:io';
import '../services/video_recording_service.dart';
import '../models/chapter.dart';
import '../models/word.dart';
import 'video_preview_screen.dart';

class VideoRecordingScreen extends StatefulWidget {
  final Chapter chapter;
  
  // For individual word practice
  final Word? word;
  final bool isIndividualPractice;
  
  // For session practice (multiple words)
  final List<Word>? words;
  
  // Legacy support
  final String? wordToSpeak;
  final int? wordIndex;
  final int? totalWords;

  const VideoRecordingScreen({
    super.key,
    required this.chapter,
    this.word,
    this.isIndividualPractice = false,
    this.words,
    this.wordToSpeak,
    this.wordIndex,
    this.totalWords,
  });

  @override
  State<VideoRecordingScreen> createState() => _VideoRecordingScreenState();
}

class _VideoRecordingScreenState extends State<VideoRecordingScreen>
    with TickerProviderStateMixin {
  final VideoRecordingService _videoService = VideoRecordingService();
  
  bool _isCameraInitialized = false;
  bool _isRecording = false;
  bool _isLoading = true;
  String? _error;
  
  late AnimationController _recordingAnimationController;
  late AnimationController _pulseAnimationController;
  late Animation<double> _scaleAnimation;
  late Animation<Color?> _colorAnimation;
  
  DateTime? _recordingStartTime;
  Duration _recordingDuration = Duration.zero;
  
  // Current word tracking for session practice
  int _currentWordIndex = 0;
  List<Word> _sessionWords = [];
  
  @override
  void initState() {
    super.initState();
    _setupSessionWords();
    _setupAnimations();
    _initializeCamera();
  }
  
  void _setupSessionWords() {
    if (widget.isIndividualPractice && widget.word != null) {
      _sessionWords = [widget.word!];
      _currentWordIndex = 0;
    } else if (widget.words != null) {
      _sessionWords = widget.words!;
      _currentWordIndex = 0;
    } else {
      // Legacy support
      _sessionWords = [];
      _currentWordIndex = widget.wordIndex ?? 0;
    }
  }
  
  Word? get currentWord {
    if (_sessionWords.isNotEmpty && _currentWordIndex < _sessionWords.length) {
      return _sessionWords[_currentWordIndex];
    }
    return null;
  }
  
  String get currentWordText {
    if (currentWord != null) {
      return currentWord!.word;
    }
    return widget.wordToSpeak ?? '';
  }
  
  int get totalWordsCount {
    if (_sessionWords.isNotEmpty) {
      return _sessionWords.length;
    }
    return widget.totalWords ?? 1;
  }
  
  int get currentWordNumber {
    return _currentWordIndex + 1;
  }

  void _setupAnimations() {
    _recordingAnimationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    
    _pulseAnimationController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );
    
    _scaleAnimation = Tween<double>(
      begin: 1.0,
      end: 1.2,
    ).animate(CurvedAnimation(
      parent: _pulseAnimationController,
      curve: Curves.easeInOut,
    ));
    
    _colorAnimation = ColorTween(
      begin: Colors.red,
      end: Colors.red.withOpacity(0.5),
    ).animate(CurvedAnimation(
      parent: _pulseAnimationController,
      curve: Curves.easeInOut,
    ));
  }

  Future<void> _initializeCamera() async {
    try {
      setState(() {
        _isLoading = true;
        _error = null;
      });
      
      final initialized = await _videoService.initialize();
      
      setState(() {
        _isCameraInitialized = initialized;
        _isLoading = false;
      });
      
      if (!initialized) {
        setState(() {
          _error = 'Failed to initialize camera. Please check permissions and try again.';
        });
      }
    } catch (e) {
      setState(() {
        _isCameraInitialized = false;
        _isLoading = false;
        _error = 'Camera error: $e';
      });
    }
  }

  Future<void> _toggleRecording() async {
    if (!_isCameraInitialized) return;
    
    try {
      if (_isRecording) {
        // Stop recording
        final videoPath = await _videoService.stopRecording();
        _pulseAnimationController.stop();
        _recordingAnimationController.reverse();
        
        setState(() {
          _isRecording = false;
        });
        
        if (videoPath != null && mounted) {
          // Navigate to preview screen
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => VideoPreviewScreen(
                videoPath: videoPath,
                chapter: widget.chapter,
                word: currentWord,
                wordText: currentWordText,
                wordIndex: _currentWordIndex,
                totalWords: totalWordsCount,
                isIndividualPractice: widget.isIndividualPractice,
                sessionWords: _sessionWords,
              ),
            ),
          );
        } else {
          // Failed to stop recording, try to reset camera
          setState(() {
            _error = 'Failed to stop recording. Resetting camera...';
            _isCameraInitialized = false;
          });
          await _resetCamera();
        }
      } else {
        // Start recording
        setState(() {
          _recordingStartTime = DateTime.now();
        });
        
        final result = await _videoService.startRecording();
        
        if (result != null) {
          _recordingAnimationController.forward();
          _pulseAnimationController.repeat(reverse: true);
          
          setState(() {
            _isRecording = true;
          });
          
          // Update duration timer
          _updateRecordingDuration();
        } else {
          // Failed to start recording, try to reset camera
          setState(() {
            _error = 'Failed to start recording. Resetting camera...';
            _isCameraInitialized = false;
          });
          await _resetCamera();
        }
      }
    } catch (e) {
      setState(() {
        _error = 'Recording error: $e. Resetting camera...';
        _isRecording = false;
        _isCameraInitialized = false;
      });
      await _resetCamera();
    }
  }

  Future<void> _resetCamera() async {
    try {
      setState(() {
        _isLoading = true;
        _error = null;
      });
      
      final success = await _videoService.reset();
      
      setState(() {
        _isCameraInitialized = success;
        _isLoading = false;
      });
      
      if (!success) {
        setState(() {
          _error = 'Failed to reset camera. Please restart the app.';
        });
      }
    } catch (e) {
      setState(() {
        _isCameraInitialized = false;
        _isLoading = false;
        _error = 'Camera reset error: $e';
      });
    }
  }

  void _updateRecordingDuration() {
    if (_isRecording && _recordingStartTime != null) {
      setState(() {
        _recordingDuration = DateTime.now().difference(_recordingStartTime!);
      });
      
      // Schedule next update
      Future.delayed(const Duration(milliseconds: 100), () {
        if (mounted && _isRecording) {
          _updateRecordingDuration();
        }
      });
    }
  }

  String _formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    String minutes = twoDigits(duration.inMinutes);
    String seconds = twoDigits(duration.inSeconds.remainder(60));
    return '$minutes:$seconds';
  }

  @override
  void dispose() {
    _recordingAnimationController.dispose();
    _pulseAnimationController.dispose();
    _videoService.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.close, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          widget.isIndividualPractice 
              ? 'Practice: ${currentWordText}'
              : 'Word $currentWordNumber of $totalWordsCount',
          style: const TextStyle(color: Colors.white, fontSize: 16),
        ),
        centerTitle: true,
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: Colors.white),
            )
          : _error != null
              ? _buildErrorView()
              : _buildRecordingView(),
    );
  }

  Widget _buildErrorView() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(
            Icons.error_outline,
            color: Colors.red,
            size: 64,
          ),
          const SizedBox(height: 16),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32),
            child: Text(
              _error!,
              style: const TextStyle(color: Colors.white, fontSize: 16),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(height: 24),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton.icon(
                onPressed: _initializeCamera,
                icon: const Icon(Icons.refresh),
                label: const Text('Retry'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                ),
              ),
              const SizedBox(width: 16),
              ElevatedButton.icon(
                onPressed: _resetCamera,
                icon: const Icon(Icons.camera_alt),
                label: const Text('Reset Camera'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.orange,
                  foregroundColor: Colors.white,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildRecordingView() {
    if (!_isCameraInitialized || _videoService.controller == null) {
      return const Center(
        child: Text(
          'Camera not available',
          style: TextStyle(color: Colors.white, fontSize: 16),
        ),
      );
    }

    return Column(
      children: [
        // Progress indicator
        if (!widget.isIndividualPractice)
          Container(
            padding: const EdgeInsets.all(16),
            child: LinearProgressIndicator(
              value: currentWordNumber / totalWordsCount,
              backgroundColor: Colors.white.withOpacity(0.3),
              valueColor: const AlwaysStoppedAnimation<Color>(Colors.blue),
            ),
          ),
        
        // Word to speak
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
          child: Column(
            children: [
              Text(
                widget.isIndividualPractice 
                    ? 'Practice this word:'
                    : 'Speak this word clearly:',
                style: const TextStyle(
                  color: Colors.white70,
                  fontSize: 16,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                currentWordText,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                ),
              ),
              if (!widget.isIndividualPractice && currentWord != null)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(
                    'Word ${currentWord!.order}',
                    style: const TextStyle(
                      color: Colors.white60,
                      fontSize: 14,
                    ),
                  ),
                ),
            ],
          ),
        ),
        
        // Camera preview
        Expanded(
          child: Container(
            margin: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: _isRecording ? Colors.red : Colors.white.withOpacity(0.3),
                width: _isRecording ? 3 : 1,
              ),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: CameraPreview(_videoService.controller!),
            ),
          ),
        ),
        
        // Recording duration
        if (_isRecording)
          Container(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                AnimatedBuilder(
                  animation: _colorAnimation,
                  builder: (context, child) {
                    return Container(
                      width: 12,
                      height: 12,
                      decoration: BoxDecoration(
                        color: _colorAnimation.value,
                        shape: BoxShape.circle,
                      ),
                    );
                  },
                ),
                const SizedBox(width: 8),
                Text(
                  _formatDuration(_recordingDuration),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        
        // Recording controls
        Container(
          padding: const EdgeInsets.all(32),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              // Cancel/Skip button
              IconButton(
                onPressed: _isRecording ? null : () => Navigator.pop(context),
                icon: const Icon(
                  Icons.skip_next,
                  size: 32,
                  color: Colors.white70,
                ),
              ),
              
              // Record button
              AnimatedBuilder(
                animation: _scaleAnimation,
                builder: (context, child) {
                  return Transform.scale(
                    scale: _isRecording ? _scaleAnimation.value : 1.0,
                    child: GestureDetector(
                      onTap: _toggleRecording,
                      child: Container(
                        width: 80,
                        height: 80,
                        decoration: BoxDecoration(
                          color: _isRecording ? Colors.red : Colors.white,
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: Colors.white,
                            width: 4,
                          ),
                        ),
                        child: Icon(
                          _isRecording ? Icons.stop : Icons.fiber_manual_record,
                          size: 32,
                          color: _isRecording ? Colors.white : Colors.red,
                        ),
                      ),
                    ),
                  );
                },
              ),
              
              // Instructions button
              IconButton(
                onPressed: _isRecording
                    ? null
                    : () => _showInstructionsDialog(),
                icon: const Icon(
                  Icons.help_outline,
                  size: 32,
                  color: Colors.white70,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  void _showInstructionsDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Recording Instructions'),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('• Position your face in the camera frame'),
            Text('• Speak the word clearly and naturally'),
            Text('• Keep recording between 2-5 seconds'),
            Text('• Ensure good lighting'),
            Text('• Avoid background noise'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Got it'),
          ),
        ],
      ),
    );
  }
}
