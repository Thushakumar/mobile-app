// lib/screens/feedback/feedback_detail_screen.dart
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../models/feedback_models.dart';
import '../../services/feedback_service.dart';

class FeedbackDetailScreen extends StatefulWidget {
  final DoctorFeedback feedback;

  const FeedbackDetailScreen({
    Key? key,
    required this.feedback,
  }) : super(key: key);

  @override
  State<FeedbackDetailScreen> createState() => _FeedbackDetailScreenState();
}

class _FeedbackDetailScreenState extends State<FeedbackDetailScreen> {
  final FeedbackService _feedbackService = FeedbackService();
  late DoctorFeedback _feedback;
  bool _isMarkingAsRead = false;

  @override
  void initState() {
    super.initState();
    _feedback = widget.feedback;
    
    // Mark as read if not already read
    if (!_feedback.isReadByPatient) {
      _markAsRead();
    }
  }

  Future<void> _markAsRead() async {
    setState(() {
      _isMarkingAsRead = true;
    });

    try {
      final success = await _feedbackService.markFeedbackAsRead(
        feedbackId: _feedback.feedbackId,
      );

      if (success && mounted) {
        setState(() {
          _feedback = DoctorFeedback(
            feedbackId: _feedback.feedbackId,
            patientId: _feedback.patientId,
            doctorName: _feedback.doctorName,
            doctorEmail: _feedback.doctorEmail,
            feedbackType: _feedback.feedbackType,
            priority: _feedback.priority,
            title: _feedback.title,
            message: _feedback.message,
            actionRequired: _feedback.actionRequired,
            dueDate: _feedback.dueDate,
            isReadByPatient: true,
            readAt: DateTime.now(),
            createdAt: _feedback.createdAt,
            updatedAt: _feedback.updatedAt,
          );
        });
      }
    } catch (e) {
      print('Error marking feedback as read: $e');
    } finally {
      setState(() {
        _isMarkingAsRead = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: const Text('Message Details'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
        actions: [
          if (_isMarkingAsRead)
            const Padding(
              padding: EdgeInsets.all(16),
              child: SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(strokeWidth: 2),
              ),
            ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildFeedbackCard(),
            const SizedBox(height: 24),
            if (_feedback.actionRequired) _buildActionSection(),
          ],
        ),
      ),
    );
  }

  Widget _buildFeedbackCard() {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header with priority and type
          Row(
            children: [
              _buildPriorityBadge(),
              const Spacer(),
              _buildTypeBadge(),
            ],
          ),
          const SizedBox(height: 16),

          // Title
          Text(
            _feedback.title,
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Color(0xFF1A1A1A),
              height: 1.3,
            ),
          ),
          const SizedBox(height: 16),

          // Doctor info
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.blue.withOpacity(0.05),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: Colors.blue.withOpacity(0.1),
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: Colors.blue.withOpacity(0.1),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    Icons.medical_services,
                    color: Colors.blue,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _feedback.doctorName,
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF1A1A1A),
                        ),
                      ),
                      Text(
                        _feedback.doctorEmail,
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),

          // Message content
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.grey.withOpacity(0.03),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: Colors.grey.withOpacity(0.1),
              ),
            ),
            child: Text(
              _feedback.message,
              style: const TextStyle(
                fontSize: 16,
                color: Color(0xFF2A2A2A),
                height: 1.6,
              ),
            ),
          ),
          const SizedBox(height: 20),

          // Timestamps
          _buildTimestamps(),
        ],
      ),
    );
  }

  Widget _buildPriorityBadge() {
    Color color;
    IconData icon;
    String text = _feedback.priorityDisplayText;

    switch (_feedback.priority) {
      case 'urgent':
        color = Colors.red;
        icon = Icons.priority_high;
        break;
      case 'high':
        color = Colors.orange;
        icon = Icons.keyboard_arrow_up;
        break;
      case 'medium':
        color = Colors.blue;
        icon = Icons.remove;
        break;
      case 'low':
        color = Colors.grey;
        icon = Icons.keyboard_arrow_down;
        break;
      default:
        color = Colors.grey;
        icon = Icons.help_outline;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: color),
          const SizedBox(width: 6),
          Text(
            text,
            style: TextStyle(
              fontSize: 12,
              color: color,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTypeBadge() {
    Color color;
    IconData icon;
    String text = _feedback.typeDisplayText;

    switch (_feedback.feedbackType) {
      case 'progress':
        color = Colors.green;
        icon = Icons.trending_up;
        break;
      case 'recommendation':
        color = Colors.amber;
        icon = Icons.lightbulb_outline;
        break;
      case 'goal':
        color = Colors.purple;
        icon = Icons.flag_outlined;
        break;
      case 'note':
        color = Colors.blue;
        icon = Icons.note_outlined;
        break;
      default:
        color = Colors.grey;
        icon = Icons.message_outlined;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: color),
          const SizedBox(width: 6),
          Text(
            text,
            style: TextStyle(
              fontSize: 12,
              color: color,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTimestamps() {
    return Column(
      children: [
        Row(
          children: [
            Icon(
              Icons.schedule,
              size: 16,
              color: Colors.grey[600],
            ),
            const SizedBox(width: 6),
            Text(
              'Created: ${DateFormat('MMM dd, yyyy \'at\' h:mm a').format(_feedback.createdAt)}',
              style: TextStyle(
                fontSize: 12,
                color: Colors.grey[600],
              ),
            ),
          ],
        ),
        if (_feedback.isReadByPatient && _feedback.readAt != null) ...[
          const SizedBox(height: 4),
          Row(
            children: [
              Icon(
                Icons.check_circle,
                size: 16,
                color: Colors.green[600],
              ),
              const SizedBox(width: 6),
              Text(
                'Read: ${DateFormat('MMM dd, yyyy \'at\' h:mm a').format(_feedback.readAt!)}',
                style: TextStyle(
                  fontSize: 12,
                  color: Colors.green[600],
                ),
              ),
            ],
          ),
        ],
      ],
    );
  }

  Widget _buildActionSection() {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.orange.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.assignment_late,
                  color: Colors.orange,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              const Text(
                'Action Required',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF1A1A1A),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          if (_feedback.dueDate != null) ...[
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _feedback.isOverdue
                    ? Colors.red.withOpacity(0.05)
                    : _feedback.isDueSoon
                        ? Colors.orange.withOpacity(0.05)
                        : Colors.blue.withOpacity(0.05),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: _feedback.isOverdue
                      ? Colors.red.withOpacity(0.2)
                      : _feedback.isDueSoon
                          ? Colors.orange.withOpacity(0.2)
                          : Colors.blue.withOpacity(0.2),
                ),
              ),
              child: Row(
                children: [
                  Icon(
                    _feedback.isOverdue
                        ? Icons.error
                        : _feedback.isDueSoon
                            ? Icons.warning
                            : Icons.schedule,
                    color: _feedback.isOverdue
                        ? Colors.red
                        : _feedback.isDueSoon
                            ? Colors.orange
                            : Colors.blue,
                    size: 20,
                  ),
                  const SizedBox(width: 8),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _feedback.isOverdue
                            ? 'Overdue!'
                            : _feedback.isDueSoon
                                ? 'Due Soon'
                                : 'Due Date',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: _feedback.isOverdue
                              ? Colors.red
                              : _feedback.isDueSoon
                                  ? Colors.orange
                                  : Colors.blue,
                        ),
                      ),
                      Text(
                        DateFormat('EEEE, MMM dd, yyyy').format(_feedback.dueDate!),
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                          color: _feedback.isOverdue
                              ? Colors.red[700]
                              : _feedback.isDueSoon
                                  ? Colors.orange[700]
                                  : Colors.blue[700],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
          ],

          // Action buttons
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () {
                    // TODO: Implement contact doctor functionality
                    _showContactDoctorDialog();
                  },
                  icon: const Icon(Icons.phone),
                  label: const Text('Contact Doctor'),
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    side: BorderSide(color: Theme.of(context).primaryColor),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () {
                    // TODO: Implement mark as completed functionality
                    _showMarkCompletedDialog();
                  },
                  icon: const Icon(Icons.check),
                  label: const Text('Mark Complete'),
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    backgroundColor: Colors.green,
                    foregroundColor: Colors.white,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _showContactDoctorDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Contact Doctor'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Contact ${_feedback.doctorName} regarding this message?'),
            const SizedBox(height: 16),
            Row(
              children: [
                Icon(Icons.email, color: Colors.grey[600]),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    _feedback.doctorEmail,
                    style: const TextStyle(fontWeight: FontWeight.w500),
                  ),
                ),
              ],
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              // TODO: Implement actual contact functionality
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Contact feature coming soon!'),
                ),
              );
            },
            child: const Text('Contact'),
          ),
        ],
      ),
    );
  }

  void _showMarkCompletedDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Mark as Completed'),
        content: const Text(
          'Are you sure you want to mark this action item as completed? '
          'This will notify your doctor that you have addressed their feedback.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              // TODO: Implement mark completed functionality
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Marked as completed!'),
                  backgroundColor: Colors.green,
                ),
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.green,
              foregroundColor: Colors.white,
            ),
            child: const Text('Mark Complete'),
          ),
        ],
      ),
    );
  }
}
