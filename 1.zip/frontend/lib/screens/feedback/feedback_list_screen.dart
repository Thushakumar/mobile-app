// lib/screens/feedback/feedback_list_screen.dart
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../services/feedback_service.dart';
import '../../models/feedback_models.dart';
import '../../models/auth_models.dart';
import 'feedback_detail_screen.dart';

class FeedbackListScreen extends StatefulWidget {
  const FeedbackListScreen({Key? key}) : super(key: key);

  @override
  State<FeedbackListScreen> createState() => _FeedbackListScreenState();
}

class _FeedbackListScreenState extends State<FeedbackListScreen> with SingleTickerProviderStateMixin {
  final FeedbackService _feedbackService = FeedbackService();
  late TabController _tabController;
  
  List<DoctorFeedback> _allFeedback = [];
  List<DoctorFeedback> _unreadFeedback = [];
  List<DoctorFeedback> _actionRequiredFeedback = [];
  
  bool _isLoading = true;
  String? _error;
  FeedbackStats? _stats;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _loadFeedback();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadFeedback() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final user = await AuthStorage.getCurrentUser();
      if (user?.patientId == null) {
        throw Exception('Patient ID not found');
      }

      // Load all feedback
      final allFeedback = await _feedbackService.getPatientFeedback(
        patientId: user!.patientId!,
      );

      // Load unread feedback
      final unreadFeedback = await _feedbackService.getPatientFeedback(
        patientId: user.patientId!,
        unreadOnly: true,
      );

      // Filter action required feedback
      final actionRequiredFeedback = allFeedback
          .where((feedback) => feedback.actionRequired)
          .toList();

      // Load stats
      final stats = await _feedbackService.getFeedbackStats(
        patientId: user.patientId!,
      );

      setState(() {
        _allFeedback = allFeedback;
        _unreadFeedback = unreadFeedback;
        _actionRequiredFeedback = actionRequiredFeedback;
        _stats = stats;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: const Text('Doctor Messages'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(100),
          child: Column(
            children: [
              if (_stats != null) _buildStatsBar(),
              TabBar(
                controller: _tabController,
                labelColor: Theme.of(context).primaryColor,
                unselectedLabelColor: Colors.grey[600],
                indicatorColor: Theme.of(context).primaryColor,
                tabs: [
                  Tab(
                    text: 'All (${_allFeedback.length})',
                    icon: const Icon(Icons.list_alt),
                  ),
                  Tab(
                    text: 'Unread (${_unreadFeedback.length})',
                    icon: const Icon(Icons.mark_email_unread),
                  ),
                  Tab(
                    text: 'Action Required (${_actionRequiredFeedback.length})',
                    icon: const Icon(Icons.assignment_late),
                  ),
                ],
              ),
            ],
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadFeedback,
          ),
        ],
      ),
      body: _buildBody(),
    );
  }

  Widget _buildStatsBar() {
    if (_stats == null) return const SizedBox.shrink();

    return Container(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Expanded(
            child: _buildStatCard(
              'Unread',
              _stats!.unreadCount.toString(),
              Icons.mark_email_unread,
              Colors.blue,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _buildStatCard(
              'Due Soon',
              _stats!.dueSoonCount.toString(),
              Icons.schedule,
              Colors.orange,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _buildStatCard(
              'Overdue',
              _stats!.overdueCount.toString(),
              Icons.warning,
              Colors.red,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard(String title, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(height: 4),
          Text(
            value,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
          Text(
            title,
            style: TextStyle(
              fontSize: 12,
              color: color.withOpacity(0.8),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(),
      );
    }

    if (_error != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.error_outline,
              size: 64,
              color: Colors.grey[400],
            ),
            const SizedBox(height: 16),
            Text(
              'Error loading feedback',
              style: TextStyle(
                fontSize: 18,
                color: Colors.grey[600],
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              _error!,
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[500],
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _loadFeedback,
              child: const Text('Try Again'),
            ),
          ],
        ),
      );
    }

    return TabBarView(
      controller: _tabController,
      children: [
        _buildFeedbackList(_allFeedback),
        _buildFeedbackList(_unreadFeedback),
        _buildFeedbackList(_actionRequiredFeedback),
      ],
    );
  }

  Widget _buildFeedbackList(List<DoctorFeedback> feedbacks) {
    if (feedbacks.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.inbox,
              size: 64,
              color: Colors.grey[400],
            ),
            const SizedBox(height: 16),
            Text(
              'No messages found',
              style: TextStyle(
                fontSize: 18,
                color: Colors.grey[600],
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Your doctor hasn\'t sent any messages yet',
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[500],
              ),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _loadFeedback,
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: feedbacks.length,
        itemBuilder: (context, index) {
          final feedback = feedbacks[index];
          return _buildFeedbackCard(feedback);
        },
      ),
    );
  }

  Widget _buildFeedbackCard(DoctorFeedback feedback) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
        border: feedback.isReadByPatient 
            ? null 
            : Border.all(
                color: Theme.of(context).primaryColor.withOpacity(0.3),
                width: 2,
              ),
      ),
      child: InkWell(
        onTap: () => _openFeedbackDetail(feedback),
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  _buildPriorityIndicator(feedback.priority),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      feedback.title,
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: feedback.isReadByPatient 
                            ? FontWeight.w500 
                            : FontWeight.bold,
                        color: Colors.grey[800],
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  if (!feedback.isReadByPatient)
                    Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        color: Theme.of(context).primaryColor,
                        shape: BoxShape.circle,
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                feedback.message,
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey[600],
                  height: 1.4,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  _buildTypeChip(feedback.feedbackType),
                  const Spacer(),
                  if (feedback.actionRequired && feedback.dueDate != null)
                    _buildDueDateChip(feedback),
                  Text(
                    DateFormat('MMM dd, yyyy').format(feedback.createdAt),
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey[500],
                    ),
                  ),
                ],
              ),
              if (feedback.actionRequired && feedback.dueDate != null)
                const SizedBox(height: 8),
              if (feedback.actionRequired && feedback.dueDate != null)
                Row(
                  children: [
                    Icon(
                      Icons.assignment_late,
                      size: 16,
                      color: feedback.isOverdue 
                          ? Colors.red 
                          : feedback.isDueSoon 
                              ? Colors.orange 
                              : Colors.grey[600],
                    ),
                    const SizedBox(width: 4),
                    Text(
                      'Due: ${DateFormat('MMM dd, yyyy').format(feedback.dueDate!)}',
                      style: TextStyle(
                        fontSize: 12,
                        color: feedback.isOverdue 
                            ? Colors.red 
                            : feedback.isDueSoon 
                                ? Colors.orange 
                                : Colors.grey[600],
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPriorityIndicator(String priority) {
    Color color;
    switch (priority) {
      case 'urgent':
        color = Colors.red;
        break;
      case 'high':
        color = Colors.orange;
        break;
      case 'medium':
        color = Colors.blue;
        break;
      case 'low':
        color = Colors.grey;
        break;
      default:
        color = Colors.grey;
    }

    return Container(
      width: 4,
      height: 16,
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(2),
      ),
    );
  }

  Widget _buildTypeChip(String type) {
    IconData icon;
    Color color;

    switch (type) {
      case 'progress':
        icon = Icons.trending_up;
        color = Colors.green;
        break;
      case 'recommendation':
        icon = Icons.lightbulb;
        color = Colors.amber;
        break;
      case 'goal':
        icon = Icons.flag;
        color = Colors.purple;
        break;
      case 'note':
        icon = Icons.note;
        color = Colors.blue;
        break;
      default:
        icon = Icons.message;
        color = Colors.grey;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12, color: color),
          const SizedBox(width: 4),
          Text(
            type.toUpperCase(),
            style: TextStyle(
              fontSize: 10,
              color: color,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDueDateChip(DoctorFeedback feedback) {
    Color color;
    String text;

    if (feedback.isOverdue) {
      color = Colors.red;
      text = 'OVERDUE';
    } else if (feedback.isDueSoon) {
      color = Colors.orange;
      text = 'DUE SOON';
    } else {
      return const SizedBox.shrink();
    }

    return Container(
      margin: const EdgeInsets.only(right: 8),
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(0.5)),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 10,
          color: color,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  void _openFeedbackDetail(DoctorFeedback feedback) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => FeedbackDetailScreen(feedback: feedback),
      ),
    ).then((_) {
      // Refresh the list when returning from detail screen
      _loadFeedback();
    });
  }
}
