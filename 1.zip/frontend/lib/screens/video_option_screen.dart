import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import '../models/chapter.dart';
import '../models/word.dart';
import 'video_recording_screen.dart';
import 'video_preview_screen.dart';

class VideoOptionScreen extends StatefulWidget {
  final Chapter chapter;
  final Word? word;
  final String? wordText;
  final bool isIndividualPractice;
  final List<Word>? sessionWords;
  final int wordIndex;
  final int totalWords;

  const VideoOptionScreen({
    super.key,
    required this.chapter,
    this.word,
    this.wordText,
    this.isIndividualPractice = false,
    this.sessionWords,
    required this.wordIndex,
    required this.totalWords,
  });

  @override
  State<VideoOptionScreen> createState() => _VideoOptionScreenState();
}

class _VideoOptionScreenState extends State<VideoOptionScreen> {
  bool _isLoading = false;

  String get currentWordText {
    return widget.wordText ?? widget.word?.word ?? '';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          widget.isIndividualPractice 
              ? 'Practice: $currentWordText'
              : 'Word ${widget.wordIndex + 1} of ${widget.totalWords}',
          style: const TextStyle(color: Colors.white, fontSize: 16),
        ),
        centerTitle: true,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Colors.black,
              Colors.blue.shade900.withOpacity(0.3),
            ],
          ),
        ),
        child: _isLoading 
            ? const Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CircularProgressIndicator(color: Colors.white),
                    SizedBox(height: 16),
                    Text(
                      'Processing video...',
                      style: TextStyle(color: Colors.white, fontSize: 16),
                    ),
                  ],
                ),
              )
            : Column(
                children: [
                  // Word display
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
                    child: Column(
                      children: [
                        Text(
                          widget.isIndividualPractice 
                              ? 'Practice this word:'
                              : 'Speak this word clearly:',
                          style: const TextStyle(
                            color: Colors.white70,
                            fontSize: 18,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 16),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                              color: Colors.blue.shade400.withOpacity(0.5),
                              width: 2,
                            ),
                          ),
                          child: Text(
                            currentWordText,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 36,
                              fontWeight: FontWeight.bold,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Instructions
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 24),
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.blue.shade800.withOpacity(0.3),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: Colors.blue.shade400.withOpacity(0.3),
                      ),
                    ),
                    child: const Row(
                      children: [
                        Icon(
                          Icons.info_outline,
                          color: Colors.blue,
                          size: 24,
                        ),
                        SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            'Choose how you want to provide your video for analysis',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  const Spacer(),

                  // Options
                  Container(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      children: [
                        // Record new video option
                        Container(
                          width: double.infinity,
                          margin: const EdgeInsets.only(bottom: 16),
                          child: ElevatedButton.icon(
                            onPressed: _recordNewVideo,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.red,
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(vertical: 20),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(16),
                              ),
                              elevation: 4,
                            ),
                            icon: const Icon(Icons.videocam, size: 28),
                            label: const Text(
                              'Record New Video',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ),

                        // Upload existing video option
                        Container(
                          width: double.infinity,
                          child: ElevatedButton.icon(
                            onPressed: _uploadExistingVideo,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.blue.shade600,
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(vertical: 20),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(16),
                              ),
                              elevation: 4,
                            ),
                            icon: const Icon(Icons.upload_file, size: 28),
                            label: const Text(
                              'Upload Existing Video',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 32),
                ],
              ),
      ),
    );
  }

  void _recordNewVideo() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => VideoRecordingScreen(
          chapter: widget.chapter,
          word: widget.word,
          isIndividualPractice: widget.isIndividualPractice,
          words: widget.sessionWords,
          wordToSpeak: currentWordText,
          wordIndex: widget.wordIndex,
          totalWords: widget.totalWords,
        ),
      ),
    );
  }

  Future<void> _uploadExistingVideo() async {
    setState(() {
      _isLoading = true;
    });

    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.video,
        allowMultiple: false,
      );

      if (result != null && result.files.single.path != null) {
        final videoPath = result.files.single.path!;
        
        // Navigate to video preview screen with uploaded video
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => VideoPreviewScreen(
              videoPath: videoPath,
              chapter: widget.chapter,
              word: widget.word,
              wordText: widget.wordText ?? currentWordText,
              isIndividualPractice: widget.isIndividualPractice,
              sessionWords: widget.sessionWords,
              wordIndex: widget.wordIndex,
              totalWords: widget.totalWords,
            ),
          ),
        );
      } else {
        setState(() {
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error selecting video: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }
}
