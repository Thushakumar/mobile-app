import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class MLAnalysisService {
  static const String baseUrl = 'http://10.0.2.2:8001/api/ml';  // Use Android emulator IP
  static const _storage = FlutterSecureStorage();
  
  /// Get authentication token from storage (same as ApiService)
  Future<String?> _getToken() async {
    return await _storage.read(key: 'access_token');
  }
  
  /// Get common headers for API requests (same as ApiService)
  Future<Map<String, String>> _getHeaders() async {
    final token = await _getToken();
    final headers = {
      'Content-Type': 'application/json',
    };
    
    if (token != null) {
      headers['Authorization'] = 'Bearer $token';
    }
    
    return headers;
  }
  
  /// Check if ML analysis service is healthy and ready
  Future<Map<String, dynamic>?> checkHealth() async {
    try {
      print('=== DEBUG: ML Health Check ===');
      final token = await _getToken();
      print('Access token available: ${token != null}');
      if (token != null) {
        print('Token length: ${token.length}');
      }
      
      final headers = await _getHeaders();
      print('Request headers: $headers');
      print('Health check URL: $baseUrl/health/');
      
      final response = await http.get(
        Uri.parse('$baseUrl/health/'),
        headers: headers,
      );
      
      print('Health check response status: ${response.statusCode}');
      print('Health check response body: ${response.body}');
      
      if (response.statusCode == 200) {
        final responseData = json.decode(response.body);
        print('Health check successful: $responseData');
        return responseData;
      } else {
        print('ML Health check failed: ${response.statusCode} ${response.body}');
        return null;
      }
    } catch (e) {
      print('Error checking ML health: $e');
      return null;
    }
  }
  
  /// Trigger ML analysis for a video submission
  Future<Map<String, dynamic>?> analyzeVideo(int videoSubmissionId) async {
    print('🔬 ML Analysis: Starting analysis for video submission ID: $videoSubmissionId');
    
    try {
      final headers = await _getHeaders();
      print('🔬 ML Analysis: Headers prepared');
      
      final url = '$baseUrl/analyze/$videoSubmissionId/';
      print('🔬 ML Analysis: Requesting URL: $url');
      
      final response = await http.post(
        Uri.parse(url),
        headers: headers,
      );
      
      print('🔬 ML Analysis: Response status: ${response.statusCode}');
      print('🔬 ML Analysis: Response body: ${response.body}');
      
      if (response.statusCode == 200) {
        final result = json.decode(response.body);
        print('🔬 ML Analysis: Successfully analyzed video');
        return result;
      } else {
        print('🔬 ML Analysis: Video analysis failed: ${response.statusCode}');
        return json.decode(response.body);
      }
    } catch (e) {
      print('🔬 ML Analysis: Error analyzing video: $e');
      return {
        'success': false,
        'error': 'Network error: $e'
      };
    }
  }
  
  /// Get analysis status for a video submission
  Future<Map<String, dynamic>?> getAnalysisStatus(int videoSubmissionId) async {
    try {
      final headers = await _getHeaders();
      final response = await http.get(
        Uri.parse('$baseUrl/status/$videoSubmissionId/'),
        headers: headers,
      );
      
      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        print('Get analysis status failed: ${response.statusCode} ${response.body}');
        return null;
      }
    } catch (e) {
      print('Error getting analysis status: $e');
      return null;
    }
  }
  
  /// Poll for analysis results with timeout
  Future<Map<String, dynamic>?> pollForResults({
    required int videoSubmissionId,
    Duration timeout = const Duration(minutes: 5),
    Duration pollInterval = const Duration(seconds: 2),
  }) async {
    final endTime = DateTime.now().add(timeout);
    
    while (DateTime.now().isBefore(endTime)) {
      final status = await getAnalysisStatus(videoSubmissionId);
      
      if (status != null) {
        final isAnalyzed = status['is_analyzed'] ?? false;
        
        if (isAnalyzed) {
          // Analysis completed
          return status;
        }
        
        // Check for failures
        final statusField = status['status'] ?? '';
        if (statusField == 'failed') {
          return {
            'success': false,
            'error': 'Analysis failed',
            'details': status
          };
        }
      }
      
      // Wait before polling again
      await Future.delayed(pollInterval);
    }
    
    // Timeout reached
    return {
      'success': false,
      'error': 'Analysis timeout',
      'timeout': true
    };
  }
  
  /// Submit video and analyze (complete flow)
  Future<Map<String, dynamic>?> submitAndAnalyzeVideo({
    required File videoFile,
    required int sessionId,
    required int wordId,
    bool waitForResults = true,
  }) async {
    try {
      // First upload the video (this would typically be done through your existing video upload service)
      // For now, we'll assume the video is already uploaded and we have a video_submission_id
      
      // This is a placeholder - you'll need to integrate with your existing video upload flow
      print('Video submission and analysis flow would be implemented here');
      print('Video file: ${videoFile.path}');
      print('Session ID: $sessionId');
      print('Word ID: $wordId');
      print('Wait for results: $waitForResults');
      
      return {
        'success': false,
        'error': 'Not implemented - integrate with video upload flow'
      };
      
    } catch (e) {
      print('Error in submit and analyze: $e');
      return {
        'success': false,
        'error': 'Error: $e'
      };
    }
  }
}

// Models for ML analysis results
class MLAnalysisResult {
  final bool success;
  final String? predictedClass;
  final double? confidenceScore;
  final double? accuracyScore;
  final Map<String, double>? confidenceScores;
  final String? error;
  final DateTime? processedAt;
  
  MLAnalysisResult({
    required this.success,
    this.predictedClass,
    this.confidenceScore,
    this.accuracyScore,
    this.confidenceScores,
    this.error,
    this.processedAt,
  });
  
  factory MLAnalysisResult.fromJson(Map<String, dynamic> json) {
    return MLAnalysisResult(
      success: json['success'] ?? false,
      predictedClass: json['predicted_class'],
      confidenceScore: json['confidence_score']?.toDouble(),
      accuracyScore: json['accuracy_score']?.toDouble(),
      confidenceScores: json['confidence_scores'] != null 
        ? Map<String, double>.from(json['confidence_scores'])
        : null,
      error: json['error'],
      processedAt: json['processed_at'] != null 
        ? DateTime.parse(json['processed_at'])
        : null,
    );
  }
  
  Map<String, dynamic> toJson() {
    return {
      'success': success,
      'predicted_class': predictedClass,
      'confidence_score': confidenceScore,
      'accuracy_score': accuracyScore,
      'confidence_scores': confidenceScores,
      'error': error,
      'processed_at': processedAt?.toIso8601String(),
    };
  }
}

class MLHealthStatus {
  final String status; // 'healthy', 'partial', 'unhealthy'
  final Map<String, bool> modelsLoaded;
  final String? error;
  final String? mlModelsDir;
  
  MLHealthStatus({
    required this.status,
    required this.modelsLoaded,
    this.error,
    this.mlModelsDir,
  });
  
  factory MLHealthStatus.fromJson(Map<String, dynamic> json) {
    return MLHealthStatus(
      status: json['status'] ?? 'unknown',
      modelsLoaded: json['models_loaded'] != null 
        ? Map<String, bool>.from(json['models_loaded'])
        : {},
      error: json['error'],
      mlModelsDir: json['ml_models_dir'],
    );
  }
  
  bool get isHealthy => status == 'healthy';
  bool get isPartiallyHealthy => status == 'partial';
  bool get isUnhealthy => status == 'unhealthy';
}
