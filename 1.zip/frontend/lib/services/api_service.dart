import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class ApiService {
  static const String baseUrl = 'http://10.0.2.2:8001/api';  // Android emulator host IP
  static const _storage = FlutterSecureStorage();
  
  // Authentication endpoints
  static const String loginEndpoint = '/mobile/auth/login/';
  static const String resetPasswordEndpoint = '/mobile/auth/reset-password/';
  static const String profileEndpoint = '/mobile/auth/profile/';
  
  // Therapy endpoints
  static const String chaptersEndpoint = '/mobile/chapters/';
  static const String sessionsEndpoint = '/mobile/sessions/';
  static const String videoSubmissionsEndpoint = '/mobile/video-submissions/';
  static const String progressEndpoint = '/mobile/';
  static const String sessionHistoryEndpoint = '/mobile/video-submissions/list/';

  // Get headers with authentication
  static Future<Map<String, String>> _getHeaders() async {
    final token = await _storage.read(key: 'access_token');
    final headers = {
      'Content-Type': 'application/json',
    };
    
    if (token != null) {
      headers['Authorization'] = 'Bearer $token';
    }
    
    return headers;
  }
  
  // Store tokens
  static Future<void> _storeTokens(String accessToken, String refreshToken) async {
    await _storage.write(key: 'access_token', value: accessToken);
    await _storage.write(key: 'refresh_token', value: refreshToken);
  }
  
  // Clear tokens
  static Future<void> clearTokens() async {
    await _storage.delete(key: 'access_token');
    await _storage.delete(key: 'refresh_token');
  }
  
  // Check if user is authenticated
  static Future<bool> isAuthenticated() async {
    final token = await _storage.read(key: 'access_token');
    return token != null;
  }

  // Login with first login check
  static Future<Map<String, dynamic>> loginWithFirstLoginCheck(String patientId, String password) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl$loginEndpoint'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'patient_id': patientId,
          'password': password,
        }),
      );
      
      final data = json.decode(response.body);
      
      if (response.statusCode == 200) {
        await _storeTokens(data['access_token'], data['refresh_token']);
        return {
          'success': true, 
          'data': data,
          'is_first_login': data['is_first_login'] ?? false,
        };
      } else {
        return {'success': false, 'error': data['error'] ?? 'Login failed'};
      }
    } catch (e) {
      return {'success': false, 'error': 'Network error: $e'};
    }
  }

  // Original login (keep for backward compatibility)
  static Future<Map<String, dynamic>> login(String patientId, String password) async {
    final result = await loginWithFirstLoginCheck(patientId, password);
    return result;
  }
  
  // Reset password
  static Future<Map<String, dynamic>> resetPassword(String patientId, String newPassword) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl$resetPasswordEndpoint'),
        headers: await _getHeaders(),
        body: json.encode({
          'patient_id': patientId,
          'new_password': newPassword,
        }),
      );
      
      final data = json.decode(response.body);
      
      if (response.statusCode == 200) {
        return {'success': true, 'message': data['message']};
      } else {
        return {'success': false, 'error': data['error'] ?? 'Password reset failed'};
      }
    } catch (e) {
      return {'success': false, 'error': 'Network error: $e'};
    }
  }
  
  // Get user profile
  static Future<Map<String, dynamic>> getProfile() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl$profileEndpoint'),
        headers: await _getHeaders(),
      );
      
      final data = json.decode(response.body);
      
      if (response.statusCode == 200) {
        return {'success': true, 'data': data};
      } else {
        return {'success': false, 'error': data['error'] ?? 'Failed to fetch profile'};
      }
    } catch (e) {
      return {'success': false, 'error': 'Network error: $e'};
    }
  }
  
  // Get chapters
  static Future<Map<String, dynamic>> getChapters() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl$chaptersEndpoint'),
        headers: await _getHeaders(),
      );
      
      final data = json.decode(response.body);
      
      if (response.statusCode == 200) {
        return {'success': true, 'data': data};
      } else {
        return {'success': false, 'error': 'Failed to fetch chapters'};
      }
    } catch (e) {
      return {'success': false, 'error': 'Network error: $e'};
    }
  }
  
  // Get chapter detail with words
  static Future<Map<String, dynamic>> getChapterDetail(int chapterId) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl$chaptersEndpoint$chapterId/'),
        headers: await _getHeaders(),
      );
      
      final data = json.decode(response.body);
      
      if (response.statusCode == 200) {
        return {'success': true, 'data': data};
      } else {
        return {'success': false, 'error': 'Failed to fetch chapter details'};
      }
    } catch (e) {
      return {'success': false, 'error': 'Network error: $e'};
    }
  }
  
  // Start therapy session
  static Future<Map<String, dynamic>> startSession(int chapterId) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl$sessionsEndpoint'),
        headers: await _getHeaders(),
        body: json.encode({
          'chapter': chapterId,
        }),
      );
      
      final data = json.decode(response.body);
      
      if (response.statusCode == 201) {
        return {'success': true, 'data': data};
      } else {
        return {'success': false, 'error': data['error'] ?? 'Failed to start session'};
      }
    } catch (e) {
      return {'success': false, 'error': 'Network error: $e'};
    }
  }
  
  // Get progress
  static Future<Map<String, dynamic>> getProgress() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl$progressEndpoint'),
        headers: await _getHeaders(),
      );
      
      final data = json.decode(response.body);
      
      if (response.statusCode == 200) {
        return {'success': true, 'data': data};
      } else {
        return {'success': false, 'error': 'Failed to fetch progress'};
      }
    } catch (e) {
      return {'success': false, 'error': 'Network error: $e'};
    }
  }
  
  // Get session history
  static Future<Map<String, dynamic>> getSessionHistory() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl$sessionHistoryEndpoint'),
        headers: await _getHeaders(),
      );
      
      final data = json.decode(response.body);
      
      if (response.statusCode == 200) {
        return {'success': true, 'data': data};
      } else {
        return {'success': false, 'error': 'Failed to fetch session history'};
      }
    } catch (e) {
      return {'success': false, 'error': 'Network error: $e'};
    }
  }

  // Create therapy session
  static Future<Map<String, dynamic>> createTherapySession({
    required int patientId,
    required int chapterId,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl$sessionsEndpoint'),
        headers: await _getHeaders(),
        body: json.encode({
          'patient': patientId,
          'chapter': chapterId,
        }),
      );
      
      final data = json.decode(response.body);
      
      if (response.statusCode == 201) {
        return {'success': true, 'data': data};
      } else {
        return {'success': false, 'error': data['error'] ?? 'Failed to create session'};
      }
    } catch (e) {
      return {'success': false, 'error': 'Network error: $e'};
    }
  }

  // Get current word in session
  static Future<Map<String, dynamic>> getCurrentWord(int sessionId) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl$sessionsEndpoint$sessionId/current_word/'),
        headers: await _getHeaders(),
      );
      
      final data = json.decode(response.body);
      
      if (response.statusCode == 200) {
        return {'success': true, 'data': data};
      } else {
        return {'success': false, 'error': data['error'] ?? 'Failed to get current word'};
      }
    } catch (e) {
      return {'success': false, 'error': 'Network error: $e'};
    }
  }

  // Move to next word
  static Future<Map<String, dynamic>> nextWord(int sessionId) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl$sessionsEndpoint$sessionId/next_word/'),
        headers: await _getHeaders(),
      );
      
      final data = json.decode(response.body);
      
      if (response.statusCode == 200) {
        return {'success': true, 'data': data};
      } else {
        return {'success': false, 'error': data['error'] ?? 'Failed to move to next word'};
      }
    } catch (e) {
      return {'success': false, 'error': 'Network error: $e'};
    }
  }

  // Move to previous word
  static Future<Map<String, dynamic>> previousWord(int sessionId) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl$sessionsEndpoint$sessionId/previous_word/'),
        headers: await _getHeaders(),
      );
      
      final data = json.decode(response.body);
      
      if (response.statusCode == 200) {
        return {'success': true, 'data': data};
      } else {
        return {'success': false, 'error': data['error'] ?? 'Failed to move to previous word'};
      }
    } catch (e) {
      return {'success': false, 'error': 'Network error: $e'};
    }
  }

  // Complete session
  static Future<Map<String, dynamic>> completeSession(int sessionId) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl$sessionsEndpoint$sessionId/complete_session/'),
        headers: await _getHeaders(),
      );
      
      final data = json.decode(response.body);
      
      if (response.statusCode == 200) {
        return {'success': true, 'data': data};
      } else {
        return {'success': false, 'error': data['error'] ?? 'Failed to complete session'};
      }
    } catch (e) {
      return {'success': false, 'error': 'Network error: $e'};
    }
  }

  // Upload video submission
  static Future<Map<String, dynamic>> uploadVideoSubmission({
    required int sessionId,
    required String videoPath,
    required String word,
  }) async {
    try {
      final request = http.MultipartRequest(
        'POST',
        Uri.parse('$baseUrl$videoSubmissionsEndpoint'),
      );
      
      // Add headers
      final headers = await _getHeaders();
      request.headers.addAll(headers);
      
      // Add fields
      request.fields['session'] = sessionId.toString();
      request.fields['word'] = word;
      
      // Add video file
      final file = File(videoPath);
      if (await file.exists()) {
        request.files.add(
          await http.MultipartFile.fromPath(
            'video_file',
            videoPath,
            filename: 'session_${sessionId}_${word}_${DateTime.now().millisecondsSinceEpoch}.mp4',
          ),
        );
      } else {
        return {'success': false, 'error': 'Video file not found'};
      }
      
      final streamedResponse = await request.send();
      final response = await http.Response.fromStream(streamedResponse);
      final data = json.decode(response.body);
      
      if (response.statusCode == 201) {
        return {'success': true, 'data': data};
      } else {
        return {'success': false, 'error': data['error'] ?? 'Failed to upload video'};
      }
    } catch (e) {
      return {'success': false, 'error': 'Network error: $e'};
    }
  }

  // Submit video (for video preview screen)
  static Future<Map<String, dynamic>> submitVideo({
    required String patientId,
    required int chapterId,
    required String wordText,
    required String videoPath,
  }) async {
    try {
      // Debug logging
      print('=== DEBUG: submitVideo called ===');
      print('Patient ID: $patientId');
      print('Patient ID type: ${patientId.runtimeType}');
      print('Patient ID length: ${patientId.length}');
      print('Patient ID is empty: ${patientId.isEmpty}');
      print('Chapter ID: $chapterId');
      print('Word Text: $wordText');
      print('Video Path: $videoPath');
      
      // Temporarily disable empty check for debugging
      if (patientId.isEmpty) {
        print('WARNING: Patient ID is empty but continuing with mock response');
        // Don't return error, continue with mock response to debug
      }
      
      final request = http.MultipartRequest(
        'POST',
        Uri.parse('$baseUrl$videoSubmissionsEndpoint'),
      );
      
      // Add headers
      final headers = await _getHeaders();
      request.headers.addAll(headers);
      
      print('=== DEBUG: Headers ===');
      print('Headers: ${request.headers}');
      
      // Add fields
      request.fields['patient_id'] = patientId;
      request.fields['chapter_id'] = chapterId.toString();
      request.fields['word_text'] = wordText;
      
      print('=== DEBUG: Request fields ===');
      print('Fields: ${request.fields}');
      
      // Verify the fields were set correctly
      print('=== DEBUG: Field verification ===');
      print('patient_id in fields: ${request.fields['patient_id']}');
      print('chapter_id in fields: ${request.fields['chapter_id']}');
      print('word_text in fields: ${request.fields['word_text']}');
      
      // Add video file
      final file = File(videoPath);
      if (await file.exists()) {
        print('=== DEBUG: Video file info ===');
        print('File exists: true');
        print('File size: ${await file.length()}');
        
        request.files.add(
          await http.MultipartFile.fromPath(
            'video_file',
            videoPath,
            filename: '${patientId}_ch${chapterId}_${wordText}_${DateTime.now().millisecondsSinceEpoch}.mp4',
          ),
        );
        
        print('Video file added to request');
      } else {
        print('=== DEBUG: Video file not found ===');
        return {'success': false, 'error': 'Video file not found'};
      }
      
      print('=== DEBUG: Sending request ===');
      print('URL: ${request.url}');
      
      // TEMPORARY: Mock success response for debugging
      print('=== DEBUG: Using mock response for testing ===');
      return {
        'success': true, 
        'data': {
          'id': 123,
          'session_id': 1,
          'word_text': wordText,
          'attempt_number': 1,
          'created_at': DateTime.now().toIso8601String()
        }
      };
      
      final streamedResponse = await request.send();
      final response = await http.Response.fromStream(streamedResponse);
      final data = json.decode(response.body);
      
      print('=== DEBUG: Response ===');
      print('Status code: ${response.statusCode}');
      print('Response body: ${response.body}');
      
      if (response.statusCode == 201) {
        return {'success': true, 'data': data};
      } else {
        return {'success': false, 'error': data['error'] ?? 'Failed to submit video'};
      }
    } catch (e) {
      print('=== DEBUG: Exception ===');
      print('Error: $e');
      return {'success': false, 'error': 'Network error: $e'};
    }
  }
}
