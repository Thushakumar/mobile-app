import 'dart:io';
import 'package:camera/camera.dart';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

class VideoRecordingService {
  CameraController? _controller;
  List<CameraDescription>? _cameras;
  bool _isRecording = false;
  bool _isInitialized = false;

  bool get isRecording => _isRecording;
  bool get isInitialized => _isInitialized;
  CameraController? get controller => _controller;

  Future<bool> initialize() async {
    try {
      // First, dispose of any existing controller
      await dispose();
      
      // Request permissions
      final cameraPermission = await Permission.camera.request();
      final microphonePermission = await Permission.microphone.request();
      
      if (!cameraPermission.isGranted || !microphonePermission.isGranted) {
        throw Exception('Camera and microphone permissions are required');
      }

      // Get available cameras
      _cameras = await availableCameras();
      if (_cameras == null || _cameras!.isEmpty) {
        throw Exception('No cameras available');
      }

      // Use front camera if available, otherwise use first camera
      CameraDescription camera = _cameras!.firstWhere(
        (camera) => camera.lensDirection == CameraLensDirection.front,
        orElse: () => _cameras!.first,
      );

      // Initialize camera controller with better settings
      _controller = CameraController(
        camera,
        ResolutionPreset.medium,
        enableAudio: true,
        imageFormatGroup: ImageFormatGroup.yuv420, // Better compatibility
      );

      // Add timeout for initialization
      await _controller!.initialize().timeout(
        const Duration(seconds: 10),
        onTimeout: () {
          throw Exception('Camera initialization timeout');
        },
      );
      
      _isInitialized = true;
      debugPrint('Camera initialized successfully');
      return true;
    } catch (e) {
      debugPrint('Error initializing camera: $e');
      await dispose(); // Clean up on error
      _isInitialized = false;
      return false;
    }
  }

  Future<String?> startRecording() async {
    if (!_isInitialized || _controller == null || _isRecording) {
      debugPrint('Cannot start recording: initialized=$_isInitialized, controller=${_controller != null}, recording=$_isRecording');
      return null;
    }

    try {
      // Ensure controller is ready
      if (!_controller!.value.isInitialized) {
        debugPrint('Controller not initialized, reinitializing...');
        final success = await initialize();
        if (!success) {
          throw Exception('Failed to reinitialize camera');
        }
      }

      // Check for existing recording and stop it
      if (_controller!.value.isRecordingVideo) {
        debugPrint('Stopping existing recording before starting new one');
        try {
          await _controller!.stopVideoRecording();
        } catch (e) {
          debugPrint('Error stopping previous recording: $e');
        }
        _isRecording = false;
        // Wait a moment for cleanup
        await Future.delayed(const Duration(milliseconds: 500));
      }

      debugPrint('Starting video recording...');
      await _controller!.startVideoRecording();
      _isRecording = true;
      debugPrint('Video recording started successfully');
      
      return 'recording_started'; // Just indicate success
    } catch (e) {
      debugPrint('Error starting video recording: $e');
      _isRecording = false;
      return null;
    }
  }

  Future<String?> stopRecording() async {
    if (!_isRecording || _controller == null) {
      debugPrint('Cannot stop recording: recording=$_isRecording, controller=${_controller != null}');
      return null;
    }

    try {
      debugPrint('Stopping video recording...');
      
      // Add timeout for stopping recording
      final videoFile = await _controller!.stopVideoRecording().timeout(
        const Duration(seconds: 10),
        onTimeout: () {
          throw Exception('Stop recording timeout');
        },
      );
      
      _isRecording = false;
      debugPrint('Video recording stopped successfully: ${videoFile.path}');
      return videoFile.path;
    } catch (e) {
      debugPrint('Error stopping video recording: $e');
      _isRecording = false;
      
      // Force reset the recording state
      try {
        if (_controller != null && _controller!.value.isRecordingVideo) {
          // Force dispose and reinitialize if stuck
          await dispose();
          await initialize();
        }
      } catch (resetError) {
        debugPrint('Error during force reset: $resetError');
      }
      
      return null;
    }
  }

  Future<void> dispose() async {
    debugPrint('Disposing video recording service...');
    
    try {
      // Stop recording if in progress
      if (_isRecording && _controller != null) {
        debugPrint('Stopping recording during dispose...');
        try {
          if (_controller!.value.isRecordingVideo) {
            await _controller!.stopVideoRecording().timeout(
              const Duration(seconds: 5),
            );
          }
        } catch (e) {
          debugPrint('Error stopping recording during dispose: $e');
        }
        _isRecording = false;
      }

      // Dispose controller
      if (_controller != null) {
        debugPrint('Disposing camera controller...');
        try {
          await _controller!.dispose();
        } catch (e) {
          debugPrint('Error disposing controller: $e');
        }
        _controller = null;
      }

      _isInitialized = false;
      _isRecording = false;
      debugPrint('Video recording service disposed successfully');
    } catch (e) {
      debugPrint('Error during dispose: $e');
      // Force cleanup even if there are errors
      _controller = null;
      _isInitialized = false;
      _isRecording = false;
    }
  }

  Future<bool> switchCamera() async {
    if (!_isInitialized || _cameras == null || _cameras!.length <= 1) {
      return false;
    }

    try {
      // Find the current camera index
      final currentCamera = _controller!.description;
      final currentIndex = _cameras!.indexOf(currentCamera);
      
      // Switch to the next camera
      final nextIndex = (currentIndex + 1) % _cameras!.length;
      final nextCamera = _cameras![nextIndex];

      // Dispose current controller
      await _controller!.dispose();

      // Initialize new controller with next camera
      _controller = CameraController(
        nextCamera,
        ResolutionPreset.medium,
        enableAudio: true,
      );

      await _controller!.initialize();
      return true;
    } catch (e) {
      debugPrint('Error switching camera: $e');
      return false;
    }
  }

  /// Reset the camera service when encountering issues
  Future<bool> reset() async {
    debugPrint('Resetting video recording service...');
    await dispose();
    await Future.delayed(const Duration(milliseconds: 1000)); // Wait for cleanup
    return await initialize();
  }
}
