// lib/services/feedback_service.dart
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/api_config.dart';
import '../models/auth_models.dart';
import '../models/feedback_models.dart';

class FeedbackService {
  static const String baseUrl = ApiConfig.baseUrl;

  // Get doctor feedback for patient
  Future<List<DoctorFeedback>> getPatientFeedback({
    required String patientId,
    String? feedbackType,
    bool unreadOnly = false,
  }) async {
    try {
      final Map<String, String> queryParams = {
        'patient_id': patientId,
        if (feedbackType != null) 'type': feedbackType,
        if (unreadOnly) 'unread_only': 'true',
      };

      final uri = Uri.parse('$baseUrl/api/sync/feedback/')
          .replace(queryParameters: queryParams);
      
      final response = await http.get(
        uri,
        headers: await _getAuthHeaders(),
      );

      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        return data.map((json) => DoctorFeedback.fromJson(json)).toList();
      } else {
        throw Exception('Failed to load feedback: ${response.statusCode}');
      }
    } catch (e) {
      print('Error getting patient feedback: $e');
      throw e;
    }
  }

  // Mark feedback as read
  Future<bool> markFeedbackAsRead({
    required String feedbackId,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api/sync/feedback/mark-read/'),
        headers: await _getAuthHeaders(),
        body: json.encode({
          'feedback_id': feedbackId,
          'read_at': DateTime.now().toIso8601String(),
        }),
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return data['success'] == true;
      } else {
        throw Exception('Failed to mark feedback as read: ${response.statusCode}');
      }
    } catch (e) {
      print('Error marking feedback as read: $e');
      return false;
    }
  }

  // Get feedback statistics
  Future<FeedbackStats> getFeedbackStats({
    required String patientId,
  }) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/sync/feedback/?patient_id=$patientId'),
        headers: await _getAuthHeaders(),
      );

      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        final feedbacks = data.map((json) => DoctorFeedback.fromJson(json)).toList();
        
        return FeedbackStats.fromFeedbackList(feedbacks);
      } else {
        throw Exception('Failed to load feedback stats: ${response.statusCode}');
      }
    } catch (e) {
      print('Error getting feedback stats: $e');
      throw e;
    }
  }

  // Real-time feedback updates
  Stream<DoctorFeedback> getFeedbackUpdates({
    required String patientId,
  }) async* {
    try {
      // This would typically use WebSocket connection
      // For now, we'll poll every 30 seconds
      while (true) {
        await Future.delayed(const Duration(seconds: 30));
        
        final feedbacks = await getPatientFeedback(
          patientId: patientId,
          unreadOnly: true,
        );
        
        for (final feedback in feedbacks) {
          yield feedback;
        }
      }
    } catch (e) {
      print('Error in feedback updates stream: $e');
    }
  }

  Future<Map<String, String>> _getAuthHeaders() async {
    final token = await AuthStorage.getToken();
    return {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };
  }
}
