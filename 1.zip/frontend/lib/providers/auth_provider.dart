import 'package:flutter/foundation.dart';
import '../services/api_service.dart';
import '../models/patient.dart';

class AuthProvider with ChangeNotifier {
  Patient? _patient;
  bool _isLoading = false;
  String? _error;

  Patient? get patient => _patient;
  bool get isLoading => _isLoading;
  String? get error => _error;
  bool get isAuthenticated => _patient != null;

  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  void _setError(String? error) {
    _error = error;
    notifyListeners();
  }

  // Login method with first login check
  Future<Map<String, dynamic>> loginWithFirstLoginCheck(String patientId, String password) async {
    _setLoading(true);
    _setError(null);

    try {
      final result = await ApiService.loginWithFirstLoginCheck(patientId, password);
      
      if (result['success']) {
        // Only fetch profile if not first login
        if (result['is_first_login'] != true) {
          await _fetchProfile();
        }
        _setLoading(false);
        return result;
      } else {
        _setError(result['error']);
        _setLoading(false);
        return result;
      }
    } catch (e) {
      _setError('Network error: $e');
      _setLoading(false);
      return {'success': false, 'error': 'Network error: $e'};
    }
  }

  // Original login method (keep for backward compatibility)
  Future<bool> login(String patientId, String password) async {
    final result = await loginWithFirstLoginCheck(patientId, password);
    return result['success'] == true;
  }

  // Fetch user profile
  Future<void> _fetchProfile() async {
    try {
      final result = await ApiService.getProfile();
      
      print('=== DEBUG: AuthProvider fetchProfile ===');
      print('Profile result: $result');
      
      if (result['success']) {
        print('Profile data: ${result['data']}');
        
        // Extract patient data from nested structure
        final patientData = result['data']['patient'];
        print('Patient data extracted: $patientData');
        
        _patient = Patient.fromJson(patientData);
        print('Created patient object: $_patient');
        print('Patient ID from object: ${_patient?.patientId}');
        notifyListeners();
      } else {
        print('Failed to fetch profile: ${result['error']}');
      }
    } catch (e) {
      print('Error fetching profile: $e');
    }
  }

  // Reset password
  Future<bool> resetPassword(String patientId, String newPassword) async {
    _setLoading(true);
    _setError(null);

    try {
      final result = await ApiService.resetPassword(patientId, newPassword);
      
      if (result['success']) {
        _setLoading(false);
        return true;
      } else {
        _setError(result['error']);
        _setLoading(false);
        return false;
      }
    } catch (e) {
      _setError('Network error: $e');
      _setLoading(false);
      return false;
    }
  }

  // Logout
  Future<void> logout() async {
    await ApiService.clearTokens();
    _patient = null;
    _error = null;
    notifyListeners();
  }

  // Check if user is already authenticated on app start
  Future<void> checkAuthStatus() async {
    if (await ApiService.isAuthenticated()) {
      await _fetchProfile();
    }
  }

  // Refresh profile (public method)
  Future<void> refreshProfile() async {
    await _fetchProfile();
  }

  // DEBUG: Set fake patient data for testing
  void setTestPatient() {
    print('=== DEBUG: Creating test patient ===');
    _patient = Patient(
      id: 999,
      fullName: 'Test Patient User',
      patientId: 'TEST_PATIENT_001',
      gender: 'Male',
      firstClinicDate: DateTime.now(),
    );
    notifyListeners();
    print('=== DEBUG: Test patient created ===');
    print('Patient ID: ${_patient?.patientId}');
    print('Patient ID length: ${_patient?.patientId.length}');
    print('Patient ID is empty: ${_patient?.patientId.isEmpty}');
    print('Full patient object: $_patient');
  }
}
