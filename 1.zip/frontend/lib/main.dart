import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/auth_provider.dart';
import 'screens/login_screen.dart';
import 'screens/home_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/enhanced_progress_screen.dart';
import 'screens/therapy_session_screen.dart';
import 'screens/chapter_detail_screen.dart';
import 'screens/password_reset_screen.dart';
import 'models/chapter.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => AuthProvider()),
      ],
      child: MaterialApp(
        title: 'NeuroSpeak',
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
          useMaterial3: true,
        ),
        home: const SplashScreen(),
        routes: {
          '/login': (context) => const LoginScreen(),
          '/home': (context) => const HomeScreen(),
          '/profile': (context) => const ProfileScreen(),
          '/progress': (context) => const EnhancedProgressScreen(),
          '/chapter-detail': (context) {
            final arguments = ModalRoute.of(context)?.settings.arguments;
            if (arguments is Chapter) {
              return ChapterDetailScreen(chapter: arguments);
            } else {
              // Return error screen if chapter data is invalid
              return Scaffold(
                appBar: AppBar(
                  title: const Text('Error'),
                  backgroundColor: Colors.red,
                  foregroundColor: Colors.white,
                ),
                body: const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.error_outline, size: 64, color: Colors.red),
                      SizedBox(height: 16),
                      Text(
                        'Chapter data is missing',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 8),
                      Text('Please go back and select a chapter'),
                    ],
                  ),
                ),
              );
            }
          },
          '/reset-password': (context) {
            final arguments = ModalRoute.of(context)?.settings.arguments;
            if (arguments is String) {
              return PasswordResetScreen(patientId: arguments);
            } else {
              // Return error screen if patient ID is missing
              return Scaffold(
                appBar: AppBar(
                  title: const Text('Error'),
                  backgroundColor: Colors.red,
                  foregroundColor: Colors.white,
                ),
                body: const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.error_outline, size: 64, color: Colors.red),
                      SizedBox(height: 16),
                      Text(
                        'Patient ID is missing',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 8),
                      Text('Please go back and try again'),
                    ],
                  ),
                ),
              );
            }
          },
          '/therapy-session': (context) {
            final arguments = ModalRoute.of(context)?.settings.arguments;
            if (arguments is Chapter) {
              return TherapySessionScreen(chapter: arguments);
            } else {
              // Return error screen if chapter data is invalid
              return Scaffold(
                appBar: AppBar(
                  title: const Text('Error'),
                  backgroundColor: Colors.red,
                  foregroundColor: Colors.white,
                ),
                body: const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.error_outline, size: 64, color: Colors.red),
                      SizedBox(height: 16),
                      Text(
                        'Chapter data is missing',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 8),
                      Text('Please go back and select a chapter'),
                    ],
                  ),
                ),
              );
            }
          },
        },
      ),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _checkAuthStatus();
  }

  Future<void> _checkAuthStatus() async {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    await authProvider.checkAuthStatus();
    
    if (mounted) {
      if (authProvider.isAuthenticated) {
        Navigator.of(context).pushReplacementNamed('/home');
      } else {
        Navigator.of(context).pushReplacementNamed('/login');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue.shade600,
      body: const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.psychology,
              size: 80,
              color: Colors.white,
            ),
            SizedBox(height: 16),
            Text(
              'NeuroSpeak',
              style: TextStyle(
                fontSize: 32,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            SizedBox(height: 8),
            Text(
              'Speech Therapy Mobile App',
              style: TextStyle(
                fontSize: 16,
                color: Colors.white70,
              ),
            ),
            SizedBox(height: 32),
            CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
            ),
          ],
        ),
      ),
    );
  }
}
