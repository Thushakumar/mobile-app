// lib/models/feedback_models.dart
class DoctorFeedback {
  final String feedbackId;
  final String patientId;
  final String doctorName;
  final String doctorEmail;
  final String feedbackType;
  final String priority;
  final String title;
  final String message;
  final bool actionRequired;
  final DateTime? dueDate;
  final bool isReadByPatient;
  final DateTime? readAt;
  final DateTime createdAt;
  final DateTime updatedAt;

  DoctorFeedback({
    required this.feedbackId,
    required this.patientId,
    required this.doctorName,
    required this.doctorEmail,
    required this.feedbackType,
    required this.priority,
    required this.title,
    required this.message,
    required this.actionRequired,
    this.dueDate,
    required this.isReadByPatient,
    this.readAt,
    required this.createdAt,
    required this.updatedAt,
  });

  factory DoctorFeedback.fromJson(Map<String, dynamic> json) {
    return DoctorFeedback(
      feedbackId: json['feedback_id'],
      patientId: json['patient'],
      doctorName: json['doctor_name'] ?? 'Unknown Doctor',
      doctorEmail: json['doctor_email'] ?? '',
      feedbackType: json['feedback_type'],
      priority: json['priority'],
      title: json['title'],
      message: json['message'],
      actionRequired: json['action_required'] ?? false,
      dueDate: json['due_date'] != null ? DateTime.parse(json['due_date']) : null,
      isReadByPatient: json['is_read_by_patient'] ?? false,
      readAt: json['read_at'] != null ? DateTime.parse(json['read_at']) : null,
      createdAt: DateTime.parse(json['created_at']),
      updatedAt: DateTime.parse(json['updated_at']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'feedback_id': feedbackId,
      'patient': patientId,
      'doctor_name': doctorName,
      'doctor_email': doctorEmail,
      'feedback_type': feedbackType,
      'priority': priority,
      'title': title,
      'message': message,
      'action_required': actionRequired,
      'due_date': dueDate?.toIso8601String(),
      'is_read_by_patient': isReadByPatient,
      'read_at': readAt?.toIso8601String(),
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
  }

  // Helper methods
  bool get isOverdue {
    if (dueDate == null || !actionRequired) return false;
    return DateTime.now().isAfter(dueDate!);
  }

  bool get isDueSoon {
    if (dueDate == null || !actionRequired) return false;
    final now = DateTime.now();
    final tomorrow = now.add(const Duration(days: 1));
    return dueDate!.isBefore(tomorrow) && dueDate!.isAfter(now);
  }

  String get priorityDisplayText {
    switch (priority) {
      case 'low':
        return 'Low Priority';
      case 'medium':
        return 'Medium Priority';
      case 'high':
        return 'High Priority';
      case 'urgent':
        return 'Urgent';
      default:
        return 'Unknown Priority';
    }
  }

  String get typeDisplayText {
    switch (feedbackType) {
      case 'progress':
        return 'Progress Update';
      case 'recommendation':
        return 'Exercise Recommendation';
      case 'goal':
        return 'Goal Setting';
      case 'note':
        return 'General Note';
      default:
        return 'Feedback';
    }
  }
}

class FeedbackStats {
  final int totalFeedback;
  final int unreadCount;
  final int actionRequiredCount;
  final int overdueCount;
  final int dueSoonCount;
  final Map<String, int> typeBreakdown;
  final Map<String, int> priorityBreakdown;

  FeedbackStats({
    required this.totalFeedback,
    required this.unreadCount,
    required this.actionRequiredCount,
    required this.overdueCount,
    required this.dueSoonCount,
    required this.typeBreakdown,
    required this.priorityBreakdown,
  });

  factory FeedbackStats.fromFeedbackList(List<DoctorFeedback> feedbacks) {
    final typeBreakdown = <String, int>{};
    final priorityBreakdown = <String, int>{};
    int unreadCount = 0;
    int actionRequiredCount = 0;
    int overdueCount = 0;
    int dueSoonCount = 0;

    for (final feedback in feedbacks) {
      // Type breakdown
      typeBreakdown[feedback.feedbackType] = 
          (typeBreakdown[feedback.feedbackType] ?? 0) + 1;
      
      // Priority breakdown
      priorityBreakdown[feedback.priority] = 
          (priorityBreakdown[feedback.priority] ?? 0) + 1;
      
      // Counts
      if (!feedback.isReadByPatient) unreadCount++;
      if (feedback.actionRequired) actionRequiredCount++;
      if (feedback.isOverdue) overdueCount++;
      if (feedback.isDueSoon) dueSoonCount++;
    }

    return FeedbackStats(
      totalFeedback: feedbacks.length,
      unreadCount: unreadCount,
      actionRequiredCount: actionRequiredCount,
      overdueCount: overdueCount,
      dueSoonCount: dueSoonCount,
      typeBreakdown: typeBreakdown,
      priorityBreakdown: priorityBreakdown,
    );
  }
}

class FeedbackNotification {
  final String id;
  final String title;
  final String body;
  final String type;
  final Map<String, dynamic> data;
  final DateTime timestamp;
  final bool isRead;

  FeedbackNotification({
    required this.id,
    required this.title,
    required this.body,
    required this.type,
    required this.data,
    required this.timestamp,
    required this.isRead,
  });

  factory FeedbackNotification.fromJson(Map<String, dynamic> json) {
    return FeedbackNotification(
      id: json['id'],
      title: json['title'],
      body: json['body'],
      type: json['type'],
      data: json['data'] ?? {},
      timestamp: DateTime.parse(json['timestamp']),
      isRead: json['is_read'] ?? false,
    );
  }
}
