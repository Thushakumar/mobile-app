class VideoSubmission {
  final int id;
  final int session;
  final int word;
  final String videoFile;
  final DateTime submittedAt;
  final bool isAnalyzed;
  final DateTime? analysisCompletedAt;
  final Map<String, dynamic>? analysisResult;
  final String? wordText;

  VideoSubmission({
    required this.id,
    required this.session,
    required this.word,
    required this.videoFile,
    required this.submittedAt,
    required this.isAnalyzed,
    this.analysisCompletedAt,
    this.analysisResult,
    this.wordText,
  });

  factory VideoSubmission.fromJson(Map<String, dynamic> json) {
    return VideoSubmission(
      id: json['id'],
      session: json['session'],
      word: json['word'],
      videoFile: json['video_file'],
      submittedAt: DateTime.parse(json['submitted_at']),
      isAnalyzed: json['is_analyzed'] ?? false,
      analysisCompletedAt: json['analysis_completed_at'] != null
          ? DateTime.parse(json['analysis_completed_at'])
          : null,
      analysisResult: json['analysis_result'],
      wordText: json['word_text'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'session': session,
      'word': word,
      'video_file': videoFile,
      'submitted_at': submittedAt.toIso8601String(),
      'is_analyzed': isAnalyzed,
      'analysis_completed_at': analysisCompletedAt?.toIso8601String(),
      'analysis_result': analysisResult,
      'word_text': wordText,
    };
  }
}
