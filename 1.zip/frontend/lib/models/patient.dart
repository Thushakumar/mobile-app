class Patient {
  final int id;
  final String fullName;
  final String patientId;
  final String gender;
  final DateTime? firstClinicDate;

  Patient({
    required this.id,
    required this.fullName,
    required this.patientId,
    required this.gender,
    this.firstClinicDate,
  });

  factory Patient.fromJson(Map<String, dynamic> json) {
    return Patient(
      id: json['id'] ?? 0,
      fullName: json['full_name'] ?? '',
      patientId: json['patient_id'] ?? '',
      gender: json['gender'] ?? '',
      firstClinicDate: json['first_clinic_date'] != null
          ? DateTime.parse(json['first_clinic_date'])
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'full_name': fullName,
      'patient_id': patientId,
      'gender': gender,
      'first_clinic_date': firstClinicDate?.toIso8601String(),
    };
  }

  @override
  String toString() {
    return 'Patient(id: $id, fullName: $fullName, patientId: $patientId, gender: $gender, firstClinicDate: $firstClinicDate)';
  }
}
