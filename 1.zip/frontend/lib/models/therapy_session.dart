class TherapySession {
  final int id;
  final int patient;
  final int chapter;
  final DateTime startedAt;
  final DateTime? completedAt;
  final bool isCompleted;
  final int currentWordIndex;
  final int totalWords;
  final double sessionScore;
  final int wordsCompleted;
  final String? patientName;
  final String? chapterName;

  TherapySession({
    required this.id,
    required this.patient,
    required this.chapter,
    required this.startedAt,
    this.completedAt,
    required this.isCompleted,
    required this.currentWordIndex,
    required this.totalWords,
    required this.sessionScore,
    required this.wordsCompleted,
    this.patientName,
    this.chapterName,
  });

  factory TherapySession.fromJson(Map<String, dynamic> json) {
    return TherapySession(
      id: json['id'],
      patient: json['patient'],
      chapter: json['chapter'],
      startedAt: DateTime.parse(json['started_at']),
      completedAt: json['completed_at'] != null
          ? DateTime.parse(json['completed_at'])
          : null,
      isCompleted: json['is_completed'] ?? false,
      currentWordIndex: json['current_word_index'] ?? 0,
      totalWords: json['total_words'] ?? 0,
      sessionScore: (json['session_score'] ?? 0.0).toDouble(),
      wordsCompleted: json['words_completed'] ?? 0,
      patientName: json['patient_name'],
      chapterName: json['chapter_name'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'patient': patient,
      'chapter': chapter,
      'started_at': startedAt.toIso8601String(),
      'completed_at': completedAt?.toIso8601String(),
      'is_completed': isCompleted,
      'current_word_index': currentWordIndex,
      'total_words': totalWords,
      'session_score': sessionScore,
      'words_completed': wordsCompleted,
      'patient_name': patientName,
      'chapter_name': chapterName,
    };
  }

  double get progressPercentage {
    if (totalWords == 0) return 0.0;
    return (currentWordIndex / totalWords) * 100.0;
  }
}
