class Word {
  final int id;
  final String word;
  final int order;

  Word({
    required this.id,
    required this.word,
    required this.order,
  });

  factory Word.fromJson(Map<String, dynamic> json) {
    return Word(
      id: json['id'] ?? 0,
      word: json['word'] ?? '',
      order: json['order'] ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'word': word,
      'order': order,
    };
  }
}
