import 'word.dart';

import 'word.dart';

class Chapter {
  final int id;
  final int chapterNumber;
  final String name;
  final List<Word>? words;

  Chapter({
    required this.id,
    required this.chapterNumber,
    required this.name,
    this.words,
  });

  factory Chapter.fromJson(Map<String, dynamic> json) {
    return Chapter(
      id: json['id'] ?? 0,
      chapterNumber: json['chapter_number'] ?? 0,
      name: json['name'] ?? '',
      words: json['words'] != null
          ? (json['words'] as List).map((w) => Word.fromJson(w)).toList()
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'chapter_number': chapterNumber,
      'name': name,
      'words': words?.map((w) => w.toJson()).toList(),
    };
  }
}
