#!/usr/bin/env python3
"""
Simple test backend to debug video upload issue
"""

from flask import Flask, request, jsonify
import os

app = Flask(__name__)

@app.route('/api/mobile/video-submissions/', methods=['POST'])
def test_video_upload():
    print("=== BACKEND DEBUG: Received video upload request ===")
    
    # Print all form data
    print("Form data:")
    for key, value in request.form.items():
        print(f"  {key}: {value}")
    
    # Print all files
    print("Files:")
    for key, file in request.files.items():
        print(f"  {key}: {file.filename}")
    
    # Print headers
    print("Headers:")
    for key, value in request.headers.items():
        print(f"  {key}: {value}")
    
    # Check required fields
    patient_id = request.form.get('patient_id')
    chapter_id = request.form.get('chapter_id')
    word_text = request.form.get('word_text')
    video_file = request.files.get('video_file')
    
    print(f"\nExtracted values:")
    print(f"  patient_id: {patient_id} (type: {type(patient_id)})")
    print(f"  chapter_id: {chapter_id} (type: {type(chapter_id)})")
    print(f"  word_text: {word_text} (type: {type(word_text)})")
    print(f"  video_file: {video_file}")
    
    # Check for missing fields
    missing_fields = []
    if not patient_id:
        missing_fields.append('patient_id')
    if not chapter_id:
        missing_fields.append('chapter_id')
    if not word_text:
        missing_fields.append('word_text')
    if not video_file:
        missing_fields.append('video_file')
    
    if missing_fields:
        error_msg = f'Missing required fields: {", ".join(missing_fields)}'
        print(f"ERROR: {error_msg}")
        return jsonify({'error': error_msg}), 400
    
    print("SUCCESS: All fields present")
    return jsonify({
        'id': 123,
        'session_id': 1,
        'word_text': word_text,
        'attempt_number': 1,
        'created_at': '2024-01-01T00:00:00Z'
    }), 201

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8001, debug=True)
