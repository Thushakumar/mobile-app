import 'patient.dart';

class AuthResponse {
  final String accessToken;
  final String refreshToken;
  final Patient user;
  final bool firstLogin;
  final String message;

  AuthResponse({
    required this.accessToken,
    required this.refreshToken,
    required this.user,
    required this.firstLogin,
    required this.message,
  });

  factory AuthResponse.fromJson(Map<String, dynamic> json) {
    return AuthResponse(
      accessToken: json['access_token'],
      refreshToken: json['refresh_token'],
      user: Patient.fromJson(json['user']),
      firstLogin: json['first_login'] ?? false,
      message: json['message'] ?? '',
    );
  }
}
