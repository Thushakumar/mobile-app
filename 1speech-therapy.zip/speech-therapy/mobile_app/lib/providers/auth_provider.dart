import 'package:flutter/foundation.dart';
import '../models/patient.dart';
import '../services/auth_service.dart';

class AuthProvider with ChangeNotifier {
  final AuthService _authService = AuthService();
  
  Patient? _user;
  bool _isLoading = false;
  String? _error;

  Patient? get user => _user;
  bool get isLoading => _isLoading;
  String? get error => _error;
  bool get isLoggedIn => _user != null;

  // Initialize auth state
  Future<void> initializeAuth() async {
    _isLoading = true;
    try {
      if (await _authService.isLoggedIn()) {
        _user = await _authService.getStoredUser();
        // Try to refresh the user profile
        try {
          _user = await _authService.getProfile();
        } catch (e) {
          // If profile fetch fails, user might need to login again
          await _logoutSilent();
          return;
        }
      }
    } catch (e) {
      _error = 'Failed to initialize authentication';
    } finally {
      _isLoading = false;
      notifyListeners(); // Only notify once at the end
    }
  }

  // Login
  Future<bool> login(String username, String password) async {
    _setLoading(true);
    _setError(null);

    try {
      final authResponse = await _authService.login(username, password);
      _user = authResponse.user;
      notifyListeners();
      return true;
    } catch (e) {
      _setError(e.toString().replaceFirst('Exception: ', ''));
      return false;
    } finally {
      _setLoading(false);
    }
  }

  // Reset password
  Future<bool> resetPassword(String newPassword, String confirmPassword) async {
    _setLoading(true);
    _setError(null);

    try {
      final success = await _authService.resetPassword(newPassword, confirmPassword);
      if (success && _user != null) {
        // Update user state to reflect first_login: false
        _user = Patient(
          id: _user!.id,
          username: _user!.username,
          firstName: _user!.firstName,
          lastName: _user!.lastName,
          email: _user!.email,
          firstLogin: false,
          createdAt: _user!.createdAt,
        );
        notifyListeners();
      }
      return success;
    } catch (e) {
      _setError(e.toString().replaceFirst('Exception: ', ''));
      return false;
    } finally {
      _setLoading(false);
    }
  }

  // Logout
  Future<void> logout() async {
    await _authService.logout();
    _user = null;
    _error = null;
    notifyListeners();
  }

  // Logout without notifying (for internal use during initialization)
  Future<void> _logoutSilent() async {
    await _authService.logout();
    _user = null;
    _error = null;
  }

  // Refresh user profile
  Future<void> refreshProfile() async {
    try {
      _user = await _authService.getProfile();
      notifyListeners();
    } catch (e) {
      _setError('Failed to refresh profile');
    }
  }

  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  void _setError(String? error) {
    _error = error;
    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}
