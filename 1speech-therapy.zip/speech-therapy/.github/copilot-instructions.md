<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->
- [x] Verify that the copilot-instructions.md file in the .github directory is created.

- [x] Clarify Project Requirements
	<!-- Speech therapy mobile application with Flutter frontend, Django backend, and PostgreSQL database for patient authentication system -->

- [x] Scaffold the Project
	<!-- Created Django backend with authentication app and Flutter mobile app with authentication screens -->

- [x] Customize the Project
	<!-- Implemented custom Patient model, authentication views, JWT tokens, Flutter screens with Provider state management -->

- [x] Install Required Extensions
	<!-- No specific extensions required for this project type -->

- [x] Compile the Project
	<!-- Django migrations applied successfully, Flutter dependencies installed -->

- [x] Create and Run Task
	<!-- Django server running on localhost:8000, Flutter app ready to run -->

- [x] Launch the Project
	<!-- Django server running successfully, Flutter app builds without critical errors -->

- [x] Ensure Documentation is Complete
	<!-- README.md created with comprehensive setup and usage instructions -->
