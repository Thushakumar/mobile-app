# Speech Therapy Mobile Application

A comprehensive speech therapy system with a Flutter mobile application for patients and a Django REST API backend.

## Project Overview

This project implements the authentication component of a speech therapy system with:
- **Mobile Application (Flutter)** - For patients only
- **Backend API (Django REST Framework)** - Authentication and data management
- **Database (SQLite for development)** - Patient data storage

### Key Features Implemented

✅ **Authentication System**
- Patient login with provided credentials
- Forced password reset on first login
- JWT token-based authentication
- Secure token storage and refresh

✅ **Mobile App Screens**
- Login screen with validation
- Password reset screen for first-time users
- Home dashboard with quick actions
- Profile screen with patient information
- Therapy session placeholder screen

✅ **Backend API**
- Custom Patient model extending Django User
- RESTful authentication endpoints
- JWT token management
- CORS configuration for mobile app

## Project Structure

```
speech-therapy/
├── backend/                    # Django REST API
│   ├── authentication/        # Authentication app
│   │   ├── models.py          # Patient model
│   │   ├── views.py           # API endpoints
│   │   ├── serializers.py     # Data serialization
│   │   └── urls.py            # URL routing
│   ├── speech_therapy_backend/ # Main Django project
│   ├── manage.py              # Django management script
│   ├── requirements.txt       # Python dependencies
│   └── .env                   # Environment variables
├── mobile_app/                # Flutter mobile application
│   ├── lib/
│   │   ├── models/            # Data models
│   │   ├── services/          # API services
│   │   ├── providers/         # State management
│   │   ├── screens/           # UI screens
│   │   └── main.dart          # App entry point
│   └── pubspec.yaml           # Flutter dependencies
└── README.md                  # This file
```

## Setup Instructions

### Prerequisites

- Python 3.8+ with pip
- Flutter SDK 3.6+
- Android Studio with Android emulator
- Git

### Backend Setup (Django)

1. **Navigate to backend directory:**
   ```bash
   cd backend
   ```

2. **Create and activate virtual environment:**
   ```bash
   python3 -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

4. **Run database migrations:**
   ```bash
   python manage.py makemigrations
   python manage.py migrate
   ```

5. **Create default test patient:**
   ```bash
   python manage.py create_default_patient
   ```

6. **Start the development server:**
   ```bash
   python manage.py runserver 0.0.0.0:8000
   ```

The backend API will be available at `http://localhost:8000/`

### Mobile App Setup (Flutter)

1. **Navigate to mobile app directory:**
   ```bash
   cd mobile_app
   ```

2. **Get Flutter dependencies:**
   ```bash
   flutter pub get
   ```

3. **Start Android emulator:**
   - Open Android Studio
   - Start an Android Virtual Device (AVD)

4. **Run the Flutter app:**
   ```bash
   flutter run
   ```

## API Endpoints

### Authentication

- **POST** `/api/auth/login/` - Patient login
- **POST** `/api/auth/reset-password/` - Reset password (requires auth)
- **GET** `/api/auth/profile/` - Get patient profile (requires auth)
- **POST** `/api/auth/refresh/` - Refresh JWT token

### Example API Usage

**Login Request:**
```json
POST /api/auth/login/
{
  "username": "patient1",
  "password": "temp123"
}
```

**Login Response:**
```json
{
  "access_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
  "refresh_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
  "user": {
    "id": 1,
    "username": "patient1",
    "first_name": "Test",
    "last_name": "Patient",
    "email": "patient1@example.com",
    "first_login": true,
    "created_at": "2025-08-11T05:00:00Z"
  },
  "first_login": true,
  "message": "Login successful"
}
```

## Test Credentials

Use these credentials to test the application:

- **Username:** `patient1`
- **Password:** `temp123`

On first login, you'll be redirected to reset your password.

## Mobile App Features

### Authentication Flow

1. **Splash Screen** - App initialization and auth state check
2. **Login Screen** - Patient authentication with test credentials shown
3. **Password Reset** - Mandatory on first login with validation
4. **Home Dashboard** - Welcome screen with quick actions
5. **Profile Screen** - Patient information display
6. **Therapy Session** - Placeholder for future ML features

### State Management

The app uses Provider pattern for state management:
- `AuthProvider` - Handles authentication state
- Persistent storage with SharedPreferences
- Automatic token refresh
- Error handling and loading states

## Development Notes

### Backend Configuration

- **Database:** SQLite (for development simplicity)
- **Authentication:** JWT tokens with refresh mechanism
- **CORS:** Configured for mobile app access
- **API Documentation:** RESTful endpoints with clear responses

### Mobile App Architecture

- **Routing:** GoRouter for navigation with auth guards
- **HTTP Client:** Standard http package for API calls
- **UI Framework:** Material Design 3
- **State Management:** Provider pattern
- **Storage:** SharedPreferences for token persistence

### Security Features

- JWT token-based authentication
- Secure token storage on device
- Automatic token refresh
- Password validation and confirmation
- API endpoint protection

## Future Enhancements

The current implementation provides a solid foundation for:

🔮 **Planned Features:**
- Video recording for lip movement exercises
- AI/ML model integration for speech analysis
- Progress tracking and analytics
- Session history and results
- Web dashboard for doctors/therapists
- PostgreSQL database integration
- Push notifications
- Offline mode support

## Troubleshooting

### Common Issues

1. **Backend server not accessible from emulator:**
   - Ensure Django is running on `0.0.0.0:8000`
   - Use `10.0.2.2:8000` for Android emulator
   - Check firewall settings

2. **Flutter dependencies issues:**
   ```bash
   flutter clean
   flutter pub get
   ```

3. **Android build issues:**
   - Check Java/Gradle compatibility
   - Update Android SDK if needed

4. **API connection errors:**
   - Verify backend server is running
   - Check network connectivity
   - Ensure CORS is properly configured

### Logs and Debugging

- **Django logs:** Available in terminal where server is running
- **Flutter logs:** Use `flutter logs` or check debug console
- **Network requests:** Enable network logging in Flutter app

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is for educational and development purposes.

---

**Note:** This is the authentication module implementation. The full therapy features with ML integration will be added in future iterations.
