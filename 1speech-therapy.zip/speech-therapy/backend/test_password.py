#!/usr/bin/env python3
import sqlite3
import hashlib
import os
import json

# Test different passwords with the stored hash
def test_passwords():
    db_path = os.path.join(os.path.dirname(__file__), 'db.sqlite3')
    
    print("=== PASSWORD TESTING ===")
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Get the stored password hash
        cursor.execute("SELECT username, password FROM patients WHERE username='patient1';")
        auth_data = cursor.fetchone()
        
        if auth_data:
            username, stored_hash = auth_data
            print(f"👤 Testing passwords for: {username}")
            print(f"🔐 Stored hash: {stored_hash[:50]}...")
            
            # Test common passwords
            test_passwords = [
                "temp123",           # Original password
                "newpassword123",    # Reset password
                "password123",       # Common password
                "testpassword"       # Alternative
            ]
            
            print("\n🔍 Testing passwords:")
            for pwd in test_passwords:
                print(f"   Testing '{pwd}': ", end="")
                
                # Django uses PBKDF2 with SHA256
                # Extract components from stored hash
                if stored_hash.startswith('pbkdf2_sha256$'):
                    algorithm, iterations, salt, hash_value = stored_hash.split('$')
                    
                    # Create test hash
                    import hashlib
                    test_hash = hashlib.pbkdf2_hmac('sha256', pwd.encode('utf-8'), salt.encode('utf-8'), int(iterations))
                    import base64
                    test_hash_b64 = base64.b64encode(test_hash).decode('ascii')
                    
                    if test_hash_b64 == hash_value:
                        print("✅ MATCH!")
                        print(f"   ✅ Current password is: '{pwd}'")
                        break
                    else:
                        print("❌ No match")
                else:
                    print("❌ Unknown hash format")
            
        conn.close()
        
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    test_passwords()
