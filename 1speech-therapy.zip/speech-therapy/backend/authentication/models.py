from django.contrib.auth.models import AbstractUser
from django.db import models


class Patient(AbstractUser):
    """
    Custom Patient model extending Django's User model
    """
    first_login = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return self.username
    
    class Meta:
        db_table = 'patients'
