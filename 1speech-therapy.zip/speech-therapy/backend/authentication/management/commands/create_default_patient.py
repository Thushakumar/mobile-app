from django.core.management.base import BaseCommand
from authentication.models import Patient


class Command(BaseCommand):
    help = 'Create a default patient for testing'

    def handle(self, *args, **options):
        # Check if patient already exists
        if Patient.objects.filter(username='patient1').exists():
            self.stdout.write(
                self.style.WARNING('Patient "patient1" already exists')
            )
            return

        # Create default patient
        patient = Patient.objects.create_user(
            username='patient1',
            password='temp123',
            first_name='Test',
            last_name='Patient',
            email='patient1@example.com',
            first_login=True
        )

        self.stdout.write(
            self.style.SUCCESS(
                f'Successfully created patient: {patient.username} with password: temp123'
            )
        )
