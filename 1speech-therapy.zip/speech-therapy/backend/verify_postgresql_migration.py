#!/usr/bin/env python3
"""
PostgreSQL Migration Verification Script
Verifies that the database has been successfully migrated from SQLite to PostgreSQL
"""

import os
import requests
import psycopg
import json
from datetime import datetime

def test_postgresql_direct():
    """Test direct PostgreSQL connection"""
    print("=== TESTING DIRECT POSTGRESQL CONNECTION ===")
    
    try:
        # Database connection parameters
        conn_params = {
            'host': 'localhost',
            'dbname': 'speech_therapy_db',
            'user': 'postgres',
            'password': 'Thusha1115',
            'port': 5432
        }
        
        with psycopg.connect(**conn_params) as conn:
            with conn.cursor() as cur:
                print("✅ PostgreSQL connection successful!")
                
                # Check if patients table exists
                cur.execute("SELECT COUNT(*) FROM information_schema.tables WHERE table_name = 'patients'")
                table_exists = cur.fetchone()[0]
                
                if table_exists:
                    print("✅ Patients table exists!")
                    
                    # Count patients
                    cur.execute("SELECT COUNT(*) FROM patients")
                    patient_count = cur.fetchone()[0]
                    print(f"📊 Total patients: {patient_count}")
                    
                    # Get patient details
                    cur.execute("SELECT id, username, email, first_login, date_joined FROM patients WHERE username = 'patient1'")
                    patient = cur.fetchone()
                    
                    if patient:
                        print("\n👤 PATIENT DETAILS:")
                        print(f"   🆔 ID: {patient[0]}")
                        print(f"   👤 Username: {patient[1]}")
                        print(f"   📧 Email: {patient[2]}")
                        print(f"   🔑 First login: {patient[3]}")
                        print(f"   📅 Date joined: {patient[4]}")
                    else:
                        print("❌ Patient 'patient1' not found!")
                else:
                    print("❌ Patients table does not exist!")
                    
    except Exception as e:
        print(f"❌ PostgreSQL connection failed: {e}")
        return False
    
    return True

def test_django_api():
    """Test Django API with PostgreSQL backend"""
    print("\n=== TESTING DJANGO API WITH POSTGRESQL ===")
    
    base_url = "http://localhost:8000"
    
    try:
        # Test login
        login_data = {
            "username": "patient1",
            "password": "temp123"
        }
        
        response = requests.post(f"{base_url}/api/auth/login/", 
                                json=login_data, 
                                headers={"Content-Type": "application/json"})
        
        if response.status_code == 200:
            print("✅ API login successful!")
            
            login_result = response.json()
            access_token = login_result.get('access_token')
            user_data = login_result.get('user')
            
            print(f"🔑 Token received: {access_token[:50]}...")
            print(f"👤 User: {user_data.get('username')}")
            print(f"📧 Email: {user_data.get('email')}")
            print(f"🔑 First login: {user_data.get('first_login')}")
            
            # Test profile endpoint
            headers = {"Authorization": f"Bearer {access_token}"}
            profile_response = requests.get(f"{base_url}/api/auth/profile/", headers=headers)
            
            if profile_response.status_code == 200:
                print("✅ Profile retrieval successful!")
                profile_data = profile_response.json()
                print(f"📋 Profile ID: {profile_data.get('id')}")
                print(f"📋 Created at: {profile_data.get('created_at')}")
            else:
                print(f"❌ Profile retrieval failed: {profile_response.status_code}")
                
        else:
            print(f"❌ API login failed: {response.status_code}")
            print(f"Response: {response.text}")
            return False
            
    except requests.exceptions.ConnectionError:
        print("❌ Cannot connect to Django server. Make sure it's running on http://localhost:8000")
        return False
    except Exception as e:
        print(f"❌ API test failed: {e}")
        return False
    
    return True

def check_database_files():
    """Check if old SQLite file exists and new PostgreSQL is being used"""
    print("\n=== CHECKING DATABASE CONFIGURATION ===")
    
    backend_dir = "/Users/shageethpratheepvaratharajan/speech-therapy/backend"
    sqlite_file = os.path.join(backend_dir, "db.sqlite3")
    
    if os.path.exists(sqlite_file):
        size = os.path.getsize(sqlite_file)
        print(f"ℹ️  SQLite file still exists: {sqlite_file} ({size} bytes)")
        print("💡 You can backup and remove this file since we're now using PostgreSQL")
    else:
        print("✅ No SQLite file found - clean migration!")
    
    # Check settings file
    settings_file = os.path.join(backend_dir, "speech_therapy_backend", "settings.py")
    if os.path.exists(settings_file):
        with open(settings_file, 'r') as f:
            content = f.read()
            if "postgresql" in content:
                print("✅ Settings configured for PostgreSQL")
            else:
                print("❌ Settings may not be configured for PostgreSQL")

def main():
    print("PostgreSQL Migration Verification")
    print("=" * 50)
    print(f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    # Run all tests
    db_test = test_postgresql_direct()
    api_test = test_django_api()
    check_database_files()
    
    print("\n" + "=" * 50)
    print("MIGRATION VERIFICATION SUMMARY")
    print("=" * 50)
    
    if db_test and api_test:
        print("🎉 MIGRATION SUCCESSFUL!")
        print("✅ PostgreSQL database is working correctly")
        print("✅ Django API is connected to PostgreSQL")
        print("✅ Patient authentication is functional")
        print("\n💡 Next steps:")
        print("   - Update mobile app if needed")
        print("   - Backup and remove old SQLite file")
        print("   - Test full end-to-end authentication flow")
    else:
        print("❌ MIGRATION ISSUES DETECTED")
        print("Please review the errors above and fix any issues.")

if __name__ == "__main__":
    main()
