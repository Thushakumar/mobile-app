#!/usr/bin/env python3
import sqlite3
import hashlib
import base64
import secrets
import os

def set_patient_password(new_password="temp123"):
    db_path = os.path.join(os.path.dirname(__file__), 'db.sqlite3')
    
    print("=== SETTING PATIENT PASSWORD ===")
    print(f"🔑 Setting password to: {new_password}")
    
    try:
        # Generate Django-compatible password hash
        iterations = 600000  # Django default
        salt = base64.b64encode(secrets.token_bytes(12)).decode('ascii')
        
        # Create PBKDF2 hash
        hash_value = hashlib.pbkdf2_hmac('sha256', new_password.encode('utf-8'), salt.encode('utf-8'), iterations)
        hash_b64 = base64.b64encode(hash_value).decode('ascii')
        
        # Format as Django password hash
        password_hash = f"pbkdf2_sha256${iterations}${salt}${hash_b64}"
        
        # Update database
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cursor.execute("UPDATE patients SET password = ? WHERE username = 'patient1';", (password_hash,))
        conn.commit()
        
        print("✅ Password updated successfully!")
        print(f"🔐 New hash: {password_hash[:50]}...")
        
        # Verify update
        cursor.execute("SELECT username, password FROM patients WHERE username='patient1';")
        result = cursor.fetchone()
        
        if result and result[1] == password_hash:
            print("✅ Password verification successful!")
        else:
            print("❌ Password verification failed!")
            
        conn.close()
        
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    set_patient_password("temp123")
