#!/usr/bin/env python3
import os

def reset_patient_password():
    db_path = os.path.join(os.path.dirname(__file__), 'db.sqlite3')
    
    print("=== RESETTING PATIENT FIRST_LOGIN FLAG ===")
    
    try:
        # For PostgreSQL, we'll use psycopg
        import psycopg
        
        conn_params = {
            'host': 'localhost',
            'dbname': 'speech_therapy_db',
            'user': 'postgres',
            'password': 'Thusha1115',
            'port': 5432
        }
        
        with psycopg.connect(**conn_params) as conn:
            with conn.cursor() as cursor:
                # Check current patient data
                cursor.execute("SELECT id, username, email, first_login FROM patients WHERE username='patient1';")
                patient = cursor.fetchone()
                
                if patient:
                    print(f"👤 Found patient: {patient[1]} (ID: {patient[0]})")
                    print(f"📧 Email: {patient[2]}")
                    print(f"🔑 Current first_login: {patient[3]}")
                    
                    # Reset first_login flag to True
                    cursor.execute("UPDATE patients SET first_login = true WHERE username = 'patient1';")
                    conn.commit()
                    
                    print("✅ Reset first_login flag to True")
                    print("💡 This means the user will be prompted to reset password on next login")
                    
                    # Verify the update
                    cursor.execute("SELECT first_login FROM patients WHERE username='patient1';")
                    new_flag = cursor.fetchone()[0]
                    print(f"✅ Verified first_login flag: {new_flag}")
                    
                else:
                    print("❌ Patient 'patient1' not found!")
                    
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    reset_patient_password()
