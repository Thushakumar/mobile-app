#!/usr/bin/env python3
import sqlite3
import os

# Path to the SQLite database
db_path = os.path.join(os.path.dirname(__file__), 'db.sqlite3')

print("=== DATABASE CONNECTION TEST ===")
print(f"Database file: {db_path}")
print(f"Database exists: {os.path.exists(db_path)}")

try:
    # Connect to SQLite database
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    print("✅ Database connection successful!")
    
    # Check if the patients table exists
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='patients';")
    table_exists = cursor.fetchone()
    
    if table_exists:
        print("✅ Patient table found!")
        
        # Count total patients
        cursor.execute("SELECT COUNT(*) FROM patients;")
        count = cursor.fetchone()[0]
        print(f"📊 Total patients: {count}")
        
        # Get patient details
        cursor.execute("SELECT id, username, email, first_login, date_joined, is_active FROM patients LIMIT 1;")
        patient = cursor.fetchone()
        
        if patient:
            print("\n👤 PATIENT PROFILE:")
            print(f"   🆔 ID: {patient[0]}")
            print(f"   👤 Username: {patient[1]}")
            print(f"   📧 Email: {patient[2]}")
            print(f"   🔑 First login: {patient[3]}")
            print(f"   📅 Date joined: {patient[4]}")
            print(f"   ✅ Active: {patient[5]}")
        else:
            print("❌ No patients found")
            
        # Check if patient can login (check password hash)
        cursor.execute("SELECT username, password FROM patients WHERE username='patient1';")
        auth_data = cursor.fetchone()
        if auth_data:
            print(f"\n🔐 Password hash exists for {auth_data[0]}: {'✅ Yes' if auth_data[1] else '❌ No'}")
            print(f"   Password hash: {auth_data[1][:50]}..." if len(auth_data[1]) > 50 else f"   Password hash: {auth_data[1]}")
        
    else:
        print("❌ Patient table not found!")
        print("Available tables:")
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = cursor.fetchall()
        for table in tables:
            print(f"   - {table[0]}")
    
    conn.close()
    
except Exception as e:
    print(f"❌ Database error: {e}")

print("\n=== TEST COMPLETED ===")
